(function(g) {
    var window = this;
    'use strict';
    var ZRh = function(w) {
            if (w instanceof g.Vl) return w;
            if (typeof w.Sx == "function") return w.Sx(!1);
            if (g.uh(w)) {
                var M = 0,
                    P = new g.Vl;
                P.next = function() {
                    for (;;) {
                        if (M >= w.length) return g.S4;
                        if (M in w) return g.m8(w[M++]);
                        M++
                    }
                };
                return P
            }
            throw Error("Not implemented");
        },
        SK$ = function(w, M, P) {
            if (g.uh(w)) g.tx(w, M, P);
            else
                for (w = ZRh(w);;) {
                    var u = w.next();
                    if (u.done) break;
                    M.call(P, u.value, void 0, w)
                }
        },
        i4 = function(w) {
            g.WG(w, "zx", Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ g.ca()).toString(36));
            return w
        },
        My = function(w, M, P) {
            Array.isArray(P) || (P = [String(P)]);
            g.KQM(w.X, M, P)
        },
        HR3 = function(w, M) {
            var P = [];
            SK$(M, function(u) {
                try {
                    var X = g.qB.prototype.L.call(this, u, !0)
                } catch (U) {
                    if (U == "Storage: Invalid value was encountered") return;
                    throw U;
                }
                X === void 0 ? P.push(u) : g.CYH(X) && P.push(u)
            }, w);
            return P
        },
        pia = function(w, M) {
            HR3(w, M).forEach(function(P) {
                g.qB.prototype.remove.call(this, P)
            }, w)
        },
        Fbc = function(w) {
            if (w.DO) {
                if (w.DO.locationOverrideToken) return {
                    locationOverrideToken: w.DO.locationOverrideToken
                };
                if (w.DO.latitudeE7 != null && w.DO.longitudeE7 != null) return {
                    latitudeE7: w.DO.latitudeE7,
                    longitudeE7: w.DO.longitudeE7
                }
            }
            return null
        },
        EhA = function(w, M) {
            g.o$(w, M) || w.push(M)
        },
        No$ = function(w) {
            var M = 0,
                P;
            for (P in w) M++;
            return M
        },
        V2h = function(w, M) {
            return g.cT(w, M)
        },
        mT$ = function(w) {
            try {
                return g.aF.JSON.parse(w)
            } catch (M) {}
            w = String(w);
            if (/^\s*$/.test(w) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(w.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + w + ")")
            } catch (M) {}
            throw Error("Invalid JSON string: " + w);
        },
        Pr = function(w) {
            if (g.aF.JSON) try {
                return g.aF.JSON.parse(w)
            } catch (M) {}
            return mT$(w)
        },
        ohc = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/channel/opened", g.iY("channel_type"))
        },
        GXp = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/channel/closed", g.iY("channel_type"))
        },
        yR4 = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/channel/message_received", g.iY("channel_type"))
        },
        DTV = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/channel/success")
        },
        qKE = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/channel/error", g.iY("channel_type"), g.iY("error_type"))
        },
        YKt = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
        },
        z$U = function() {
            var w = u4();
            this.B = w;
            w.fX("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
        },
        Tox = function(w, M, P, u) {
            var X = new g.ic(null);
            w && g.Mb(X, w);
            M && g.PG(X, M);
            P && g.uc(X, P);
            u && (X.L = u);
            return X
        },
        dTh = function(w, M) {
            return new g.xO(w, M)
        },
        XA = function(w, M) {
            return Object.prototype.hasOwnProperty.call(w, M)
        },
        lYE = function(w, M) {
            return w === M
        },
        $b = function(w, M) {
            this.L = {};
            this.B = [];
            this.LK = this.size = 0;
            var P = arguments.length;
            if (P > 1) {
                if (P % 2) throw Error("Uneven number of arguments");
                for (var u = 0; u < P; u += 2) this.set(arguments[u], arguments[u + 1])
            } else if (w)
                if (w instanceof $b)
                    for (P = w.oN(), u = 0; u < P.length; u++) this.set(P[u], w.get(P[u]));
                else
                    for (u in w) this.set(u, w[u])
        },
        Uj = function(w) {
            if (w.size != w.B.length) {
                for (var M = 0, P = 0; M < w.B.length;) {
                    var u = w.B[M];
                    XA(w.L, u) && (w.B[P++] = u);
                    M++
                }
                w.B.length = P
            }
            if (w.size != w.B.length) {
                M = {};
                for (u = P = 0; P < w.B.length;) {
                    var X = w.B[P];
                    XA(M, X) || (w.B[u++] = X, M[X] = 1);
                    P++
                }
                w.B.length = u
            }
        },
        fg = function(w) {
            this.name = this.id = "";
            this.clientName = "UNKNOWN_INTERFACE";
            this.app = "";
            this.type = "REMOTE_CONTROL";
            this.ownerObfuscatedGaiaId = this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.compatibleSenderThemes = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new $b;
            this.model = this.brand = "";
            this.year = 0;
            this.chipset = this.osVersion = this.os = "";
            this.mdxDialServerType = "MDX_DIAL_SERVER_TYPE_UNKNOWN";
            w && (this.id = w.id || w.name, this.name = w.name, this.clientName = w.clientName ? w.clientName.toUpperCase() : "UNKNOWN_INTERFACE",
                this.app = w.app, this.type = w.type || "REMOTE_CONTROL", this.username = w.user || "", this.avatar = w.userAvatarUri || "", this.obfuscatedGaiaId = w.obfuscatedGaiaId || "", this.ownerObfuscatedGaiaId = w.ownerObfuscatedGaiaId || "", this.theme = w.theme || "u", LbE(this, w.capabilities || ""), e$h(this, w.compatibleSenderThemes || ""), BoC(this, w.experiments || ""), this.brand = w.brand || "", this.model = w.model || "", this.year = w.year || 0, this.os = w.os || "", this.osVersion = w.osVersion || "", this.chipset = w.chipset || "", this.mdxDialServerType = w.mdxDialServerType ||
                "MDX_DIAL_SERVER_TYPE_UNKNOWN", w = w.deviceInfo) && (w = JSON.parse(w), this.brand = w.brand || "", this.model = w.model || "", this.year = w.year || 0, this.os = w.os || "", this.osVersion = w.osVersion || "", this.chipset = w.chipset || "", this.clientName = w.clientName ? w.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.mdxDialServerType = w.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN")
        },
        LbE = function(w, M) {
            w.capabilities.clear();
            g.DP(M.split(","), g.Wa(V2h, Qgj)).forEach(function(P) {
                w.capabilities.add(P)
            })
        },
        e$h = function(w, M) {
            w.compatibleSenderThemes.clear();
            g.DP(M.split(","), g.Wa(V2h, kXa)).forEach(function(P) {
                w.compatibleSenderThemes.add(P)
            })
        },
        BoC = function(w, M) {
            w.experiments.clear();
            M.split(",").forEach(function(P) {
                w.experiments.add(P)
            })
        },
        Wr = function(w) {
            w = w || {};
            this.name = w.name || "";
            this.id = w.id || w.screenId || "";
            this.token = w.token || w.loungeToken || "";
            this.uuid = w.uuid || w.dialId || "";
            this.idType = w.screenIdType || "normal"
        },
        h6 = function(w, M) {
            return !!M && (w.id == M || w.uuid == M)
        },
        R$$ = function(w) {
            return {
                name: w.name,
                screenId: w.id,
                loungeToken: w.token,
                dialId: w.uuid,
                screenIdType: w.idType
            }
        },
        nhp = function(w) {
            return new Wr(w)
        },
        PL3 = function(w) {
            return Array.isArray(w) ? g.EV(w, nhp) : []
        },
        cr = function(w) {
            return w ? '{name:"' + w.name + '",id:' + w.id.substr(0, 6) + "..,token:" + ((w.token ? ".." + w.token.slice(-6) : "-") + ",uuid:" + (w.uuid ? ".." + w.uuid.slice(-6) : "-") + ",idType:" + w.idType + "}") : "null"
        },
        uW3 = function(w) {
            return Array.isArray(w) ? "[" + g.EV(w, cr).join(",") + "]" : "null"
        },
        XFC = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
                function(w) {
                    var M = Math.random() * 16 | 0;
                    return (w == "x" ? M : M & 3 | 8).toString(16)
                })
        },
        $xE = function(w) {
            return g.EV(w, function(M) {
                return {
                    key: M.id,
                    name: M.name
                }
            })
        },
        Uxt = function(w, M) {
            return g.Nj(w, function(P) {
                return P || M ? !P != !M ? !1 : P.id == M.id : !0
            })
        },
        ZJ = function(w, M) {
            return g.Nj(w, function(P) {
                return h6(P, M)
            })
        },
        fKj = function() {
            var w = (0, g.YF)();
            w && pia(w, w.B.Sx(!0))
        },
        Sz = function() {
            var w = g.dH("yt-remote-connected-devices") || [];
            g.r3(w);
            return w
        },
        W54 = function(w) {
            if (w.length == 0) return [];
            var M = w[0].indexOf("#"),
                P = M == -1 ? w[0] : w[0].substring(0, M);
            return g.EV(w, function(u, X) {
                return X == 0 ? u : u.substring(P.length)
            })
        },
        hWc = function(w) {
            g.Tg("yt-remote-connected-devices", w, 86400)
        },
        Hr = function() {
            if (cDE) return cDE;
            var w = g.dH("yt-remote-device-id");
            w || (w = XFC(), g.Tg("yt-remote-device-id", w, 31536E3));
            for (var M = Sz(), P = 1, u = w; g.o$(M, u);) P++, u = w + "#" + P;
            return cDE = u
        },
        ZBt = function() {
            var w = Sz(),
                M = Hr();
            g.L0() && g.CC(w, M);
            w = W54(w);
            if (w.length == 0) try {
                g.BF("remote_sid")
            } catch (P) {} else try {
                g.LB("remote_sid", w.join(","), -1)
            } catch (P) {}
        },
        SLt = function() {
            return g.dH("yt-remote-session-browser-channel")
        },
        HBE = function() {
            return g.dH("yt-remote-local-screens") || []
        },
        pFx = function() {
            g.Tg("yt-remote-lounge-token-expiration", !0, 86400)
        },
        F5x = function(w) {
            w.length > 5 && (w = w.slice(w.length - 5));
            var M = g.EV(HBE(), function(u) {
                    return u.loungeToken
                }),
                P = g.EV(w, function(u) {
                    return u.loungeToken
                });
            g.Nq(P, function(u) {
                return !g.o$(M, u)
            }) && pFx();
            g.Tg("yt-remote-local-screens", w, 31536E3)
        },
        pg = function(w) {
            w || (g.lK("yt-remote-session-screen-id"), g.lK("yt-remote-session-video-id"));
            ZBt();
            w = Sz();
            g.D4(w, Hr());
            hWc(w)
        },
        ESt = function() {
            if (!FA) {
                var w = g.L_();
                w && (FA = new g.Gy(w))
            }
        },
        N$E = function() {
            ESt();
            return FA ? !!FA.get("yt-remote-use-staging-server") : !1
        },
        Ej = function(w, M) {
            g.jU[w] = !0;
            var P = g.Ji();
            P && P.publish.apply(P, arguments);
            g.jU[w] = !1
        },
        V9x = function() {},
        u4 = function() {
            if (!Ny) {
                Ny = new g.kv(new V9x);
                var w = g.EL("client_streamz_web_flush_count", -1);
                w !== -1 && (Ny.C = w)
            }
            return Ny
        },
        mxt = function() {
            var w = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            return w ? parseInt(w[1], 10) : 0
        },
        oSE = function(w) {
            return !!document.currentScript && (document.currentScript.src.indexOf("?" + w) != -1 || document.currentScript.src.indexOf("&" + w) != -1)
        },
        GZh = function() {
            return typeof window.__onGCastApiAvailable == "function" ? window.__onGCastApiAvailable : null
        },
        Vv = function(w) {
            w.length ? yDC(w.shift(), function() {
                Vv(w)
            }) : DxU()
        },
        qLE = function(w) {
            return "chrome-extension://" + w + "/cast_sender.js"
        },
        yDC = function(w, M, P) {
            var u = document.createElement("script");
            u.onerror = M;
            P && (u.onload = P);
            g.o7(u, g.Vb(w));
            (document.head || document.documentElement).appendChild(u)
        },
        YLt = function() {
            var w = mxt(),
                M = [];
            if (w > 1) {
                var P = w - 1;
                M.push("//www.gstatic.com/eureka/clank/" + w + "/cast_sender.js");
                M.push("//www.gstatic.com/eureka/clank/" + P + "/cast_sender.js")
            }
            return M
        },
        DxU = function() {
            var w = GZh();
            w && w(!1, "No cast extension found")
        },
        T$c = function() {
            if (zW4) {
                var w = 2,
                    M = GZh(),
                    P = function() {
                        w--;
                        w == 0 && M && M(!0)
                    };
                window.__onGCastApiAvailable = P;
                yDC("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", DxU, P)
            }
        },
        dxj = function() {
            T$c();
            var w = YLt();
            w.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            Vv(w)
        },
        L5U = function() {
            T$c();
            var w = YLt();
            w.push.apply(w, g.L(lK3.map(qLE)));
            w.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            Vv(w)
        },
        mN = function(w, M, P) {
            g.v.call(this);
            this.K = P != null ? (0, g.fC)(w, P) : w;
            this.Hb = M;
            this.G = (0, g.fC)(this.vE, this);
            this.B = !1;
            this.L = 0;
            this.C = this.jZ = null;
            this.X = []
        },
        oM = function() {},
        eWE = function() {
            g.Iu.call(this, "p")
        },
        B$h = function() {
            g.Iu.call(this, "o")
        },
        kZt = function() {
            return Q1E = Q1E || new g.WX
        },
        RW3 = function(w) {
            g.Iu.call(this, "serverreachability", w)
        },
        GA = function(w) {
            var M = kZt();
            M.dispatchEvent(new RW3(M, w))
        },
        nS3 = function(w) {
            g.Iu.call(this, "statevent", w)
        },
        yv = function(w) {
            var M = kZt();
            M.dispatchEvent(new nS3(M, w))
        },
        vSC = function(w, M, P, u) {
            g.Iu.call(this, "timingevent", w);
            this.size = M;
            this.rtt = P;
            this.retries = u
        },
        DJ = function(w, M) {
            if (typeof w !== "function") throw Error("Fn must not be null and must be a function");
            return g.aF.setTimeout(function() {
                w()
            }, M)
        },
        qy = function() {},
        Yb = function(w, M, P, u) {
            this.C = w;
            this.X = M;
            this.GE = P;
            this.hD = u || 1;
            this.bW = new g.HG(this);
            this.iW = 45E3;
            this.UO = null;
            this.K = !1;
            this.S = this.Yu = this.V = this.eL = this.mN = this.Z3 = this.B3 = null;
            this.Lu = [];
            this.B = null;
            this.j = 0;
            this.G = this.ys = null;
            this.cj = -1;
            this.xu = !1;
            this.jL = 0;
            this.t9 = null;
            this.M7 = this.OO = this.fg = this.Cu = !1;
            this.L = new s13
        },
        s13 = function() {
            this.C = null;
            this.B = "";
            this.L = !1
        },
        bBh = function(w, M, P) {
            w.eL = 1;
            w.V = i4(M.clone());
            w.S = P;
            w.Cu = !0;
            K5p(w, null)
        },
        K5p = function(w, M) {
            w.mN = Date.now();
            zA(w);
            w.Yu = w.V.clone();
            My(w.Yu, "t", w.hD);
            w.j = 0;
            var P = w.C.eL;
            w.L = new s13;
            w.B = IKV(w.C, P ? M : null, !w.S);
            w.jL > 0 && (w.t9 = new g.Cb((0, g.fC)(w.O4, w, w.B), w.jL));
            w.bW.listen(w.B, "readystatechange", w.m1);
            M = w.UO ? g.Fm(w.UO) : {};
            w.S ? (w.ys || (w.ys = "POST"), M["Content-Type"] = "application/x-www-form-urlencoded", w.B.send(w.Yu, w.ys, w.S, M)) : (w.ys = "GET", w.B.send(w.Yu, w.ys, null, M));
            GA(1)
        },
        gSE = function(w) {
            if (!AD$(w)) return g.Jn(w.B);
            var M = g.rb(w.B);
            if (M === "") return "";
            var P = "",
                u = M.length,
                X = g.An(w.B) == 4;
            if (!w.L.C) {
                if (typeof TextDecoder === "undefined") return TA(w), dF(w), "";
                w.L.C = new g.aF.TextDecoder
            }
            for (var U = 0; U < u; U++) w.L.L = !0, P += w.L.C.decode(M[U], {
                stream: !(X && U == u - 1)
            });
            M.length = 0;
            w.L.B += P;
            w.j = 0;
            return w.L.B
        },
        AD$ = function(w) {
            return w.B ? w.ys == "GET" && w.eL != 2 && w.C.Lx : !1
        },
        j1x = function(w, M) {
            var P = w.j,
                u = M.indexOf("\n", P);
            if (u == -1) return JDp;
            P = Number(M.substring(P, u));
            if (isNaN(P)) return rDa;
            u += 1;
            if (u + P > M.length) return JDp;
            M = M.slice(u, u + P);
            w.j = u + P;
            return M
        },
        zA = function(w) {
            w.Z3 = Date.now() + w.iW;
            CLj(w, w.iW)
        },
        CLj = function(w, M) {
            if (w.B3 != null) throw Error("WatchDog timer not null");
            w.B3 = DJ((0, g.fC)(w.Ei, w), M)
        },
        t9E = function(w) {
            w.B3 && (g.aF.clearTimeout(w.B3), w.B3 = null)
        },
        dF = function(w) {
            w.C.bF() || w.xu || xxt(w.C, w)
        },
        TA = function(w) {
            t9E(w);
            g.wR(w.t9);
            w.t9 = null;
            w.bW.removeAll();
            if (w.B) {
                var M = w.B;
                w.B = null;
                M.abort();
                M.dispose()
            }
        },
        Xn$ = function(w, M) {
            try {
                var P = w.C;
                if (P.AV != 0 && (P.B == w || OBA(P.L, w)))
                    if (!w.OO && OBA(P.L, w) && P.AV == 3) {
                        try {
                            var u = P.Kx.B.parse(M)
                        } catch (y) {
                            u = null
                        }
                        if (Array.isArray(u) && u.length == 3) {
                            var X = u;
                            if (X[0] == 0) a: {
                                if (!P.V) {
                                    if (P.B)
                                        if (P.B.mN + 3E3 < w.mN) l4(P), Lg(P);
                                        else break a;
                                    aKp(P);
                                    yv(18)
                                }
                            }
                            else P.SZ = X[1], 0 < P.SZ - P.t9 && X[2] < 37500 && P.OO && P.Lu == 0 && !P.B3 && (P.B3 = DJ((0, g.fC)(P.Rh, P), 6E3));
                            if (wnV(P.L) <= 1 && P.VE) {
                                try {
                                    P.VE()
                                } catch (y) {}
                                P.VE = void 0
                            }
                        } else ez(P, 11)
                    } else if ((w.OO || P.B == w) && l4(P), !g.lA(M))
                    for (X = P.Kx.B.parse(M), M = 0; M < X.length; M++) {
                        var U = X[M];
                        P.t9 = U[0];
                        U = U[1];
                        if (P.AV == 2)
                            if (U[0] == "c") {
                                P.X = U[1];
                                P.hD = U[2];
                                var f = U[3];
                                f != null && (P.g_ = f);
                                var h = U[5];
                                h != null && typeof h === "number" && h > 0 && (P.jL = 1.5 * h);
                                u = P;
                                var c = w.ma();
                                if (c) {
                                    var Z = g.j7(c, "X-Client-Wire-Protocol");
                                    if (Z) {
                                        var S = u.L;
                                        !S.B && (g.LE(Z, "spdy") || g.LE(Z, "quic") || g.LE(Z, "h2")) && (S.X = S.G, S.B = new Set, S.L && (i0c(S, S.L), S.L = null))
                                    }
                                    if (u.Cu) {
                                        var H = g.j7(c, "X-HTTP-Session-Id");
                                        H && (u.DO = H, g.WG(u.UO, u.Cu, H))
                                    }
                                }
                                P.AV = 3;
                                P.G && P.G.uj();
                                P.TE && (P.sb = Date.now() - w.mN);
                                u = P;
                                var p = w;
                                u.DX = Mh$(u, u.eL ? u.hD : null, u.GE);
                                if (p.OO) {
                                    PKV(u.L,
                                        p);
                                    var F = p,
                                        E = u.jL;
                                    E && F.setTimeout(E);
                                    F.B3 && (t9E(F), zA(F));
                                    u.B = p
                                } else urt(u);
                                P.C.length > 0 && Br(P)
                            } else U[0] != "stop" && U[0] != "close" || ez(P, 7);
                        else P.AV == 3 && (U[0] == "stop" || U[0] == "close" ? U[0] == "stop" ? ez(P, 7) : P.disconnect() : U[0] != "noop" && P.G && P.G.TB(U), P.Lu = 0)
                    }
                GA(4)
            } catch (y) {}
        },
        $ih = function(w, M) {
            this.B = w;
            this.map = M;
            this.context = null
        },
        UiE = function(w) {
            this.G = w || 10;
            g.aF.PerformanceNavigationTiming ? (w = g.aF.performance.getEntriesByType("navigation"), w = w.length > 0 && (w[0].nextHopProtocol == "hq" || w[0].nextHopProtocol == "h2")) : w = !!(g.aF.chrome && g.aF.chrome.loadTimes && g.aF.chrome.loadTimes() && g.aF.chrome.loadTimes().wasFetchedViaSpdy);
            this.X = w ? this.G : 1;
            this.B = null;
            this.X > 1 && (this.B = new Set);
            this.L = null;
            this.C = []
        },
        fqE = function(w) {
            return w.L ? !0 : w.B ? w.B.size >= w.X : !1
        },
        wnV = function(w) {
            return w.L ? 1 : w.B ? w.B.size : 0
        },
        OBA = function(w, M) {
            return w.L ? w.L == M : w.B ? w.B.has(M) : !1
        },
        i0c =
        function(w, M) {
            w.B ? w.B.add(M) : w.L = M
        },
        PKV = function(w, M) {
            w.L && w.L == M ? w.L = null : w.B && w.B.has(M) && w.B.delete(M)
        },
        Wua = function(w) {
            if (w.L != null) return w.C.concat(w.L.Lu);
            if (w.B != null && w.B.size !== 0) {
                var M = w.C;
                w = g.G(w.B.values());
                for (var P = w.next(); !P.done; P = w.next()) M = M.concat(P.value.Lu);
                return M
            }
            return g.LC(w.C)
        },
        hD4 = function(w, M) {
            var P = new qy;
            if (g.aF.Image) {
                var u = new Image;
                u.onload = g.Wa(Qv, P, "TestLoadImage: loaded", !0, M, u);
                u.onerror = g.Wa(Qv, P, "TestLoadImage: error", !1, M, u);
                u.onabort = g.Wa(Qv, P, "TestLoadImage: abort", !1, M, u);
                u.ontimeout = g.Wa(Qv, P, "TestLoadImage: timeout", !1, M, u);
                g.aF.setTimeout(function() {
                    if (u.ontimeout) u.ontimeout()
                }, 1E4);
                u.src = w
            } else M(!1)
        },
        cSV = function(w, M) {
            var P = new qy,
                u = new AbortController,
                X = setTimeout(function() {
                    u.abort();
                    Qv(P, "TestPingServer: timeout", !1, M)
                }, 1E4);
            fetch(w, {
                signal: u.signal
            }).then(function(U) {
                clearTimeout(X);
                U.ok ? Qv(P, "TestPingServer: ok", !0, M) : Qv(P, "TestPingServer: server error", !1, M)
            }).catch(function() {
                clearTimeout(X);
                Qv(P, "TestPingServer: error", !1, M)
            })
        },
        Qv = function(w, M, P, u, X) {
            try {
                X && (X.onload = null, X.onerror = null, X.onabort = null, X.ontimeout = null), u(P)
            } catch (U) {}
        },
        Z0E = function() {
            this.B = new oM
        },
        SmA = function(w, M, P) {
            var u = P || "";
            try {
                g.wV(w, function(X, U) {
                    var f = X;
                    g.XE(X) && (f = g.ny(X));
                    M.push(u + U + "=" + encodeURIComponent(f))
                })
            } catch (X) {
                throw M.push(u + "type=" + encodeURIComponent("_badmap")), X;
            }
        },
        kb = function(w, M, P) {
            return P && P.vz ? P.vz[w] || M : M
        },
        H0x = function(w) {
            this.C = [];
            this.hD = this.DX = this.UO = this.GE = this.B = this.DO = this.Cu = this.xu = this.j = this.cj = this.S = null;
            this.nV = this.Yu = 0;
            this.a7 = kb("failFast", !1, w);
            this.OO = this.B3 = this.V = this.K = this.G = null;
            this.QE = !0;
            this.SZ = this.t9 = -1;
            this.M7 = this.Lu = this.mN = 0;
            this.gb = kb("baseRetryDelayMs", 5E3, w);
            this.wb = kb("retryDelaySeedMs", 1E4, w);
            this.QL = kb("forwardChannelMaxRetries", 2, w);
            this.Ob = kb("forwardChannelRequestTimeoutMs", 2E4, w);
            this.rB = w && w.F3k || void 0;
            this.TD = w && w.Ep$ || void 0;
            this.Lx = w && w.yPs || !1;
            this.jL = void 0;
            this.eL = w && w.rxu ||
                !1;
            this.X = "";
            this.L = new UiE(w && w.jNs);
            this.Kx = new Z0E;
            this.bW = w && w.mxs || !1;
            this.Z3 = w && w.qe0 || !1;
            this.bW && this.Z3 && (this.Z3 = !1);
            this.jU = w && w.eUL || !1;
            w && w.Mz9 && (this.QE = !1);
            this.TE = !this.bW && this.QE && w && w.Ye9 || !1;
            this.KT = void 0;
            w && w.uM && w.uM > 0 && (this.KT = w.uM);
            this.VE = void 0;
            this.sb = 0;
            this.iW = !1;
            this.fg = this.ys = null
        },
        Lg = function(w) {
            w.B && (pnh(w), w.B.cancel(), w.B = null)
        },
        FuA = function(w) {
            Lg(w);
            w.V && (g.aF.clearTimeout(w.V), w.V = null);
            l4(w);
            w.L.cancel();
            w.K && (typeof w.K === "number" && g.aF.clearTimeout(w.K), w.K = null)
        },
        Br = function(w) {
            fqE(w.L) || w.K || (w.K = !0, g.Vk(w.Q4, w), w.mN = 0)
        },
        NH$ = function(w, M) {
            if (wnV(w.L) >= w.L.X - (w.K ? 1 : 0)) return !1;
            if (w.K) return w.C = M.Lu.concat(w.C), !0;
            if (w.AV == 1 || w.AV == 2 || w.mN >= (w.a7 ? 0 : w.QL)) return !1;
            w.K = DJ((0, g.fC)(w.Q4, w, M), EFc(w, w.mN));
            w.mN++;
            return !0
        },
        mi4 = function(w, M) {
            var P;
            M ? P = M.GE : P = w.Yu++;
            var u = w.UO.clone();
            g.WG(u, "SID", w.X);
            g.WG(u, "RID", P);
            g.WG(u, "AID", w.t9);
            RM(w, u);
            w.j && w.S && g.Sr(u, w.j, w.S);
            P = new Yb(w, w.X, P, w.mN + 1);
            w.j === null && (P.UO = w.S);
            M && (w.C = M.Lu.concat(w.C));
            M = Vhp(w, P, 1E3);
            P.setTimeout(Math.round(w.Ob * .5) + Math.round(w.Ob * .5 * Math.random()));
            i0c(w.L, P);
            bBh(P, u, M)
        },
        RM = function(w, M) {
            w.xu && g.wd(w.xu, function(P, u) {
                g.WG(M, u, P)
            });
            w.G && g.wV({}, function(P, u) {
                g.WG(M, u, P)
            })
        },
        Vhp = function(w, M, P) {
            P = Math.min(w.C.length, P);
            var u = w.G ? (0, g.fC)(w.G.rP, w.G, w) : null;
            a: {
                for (var X = w.C, U = -1;;) {
                    var f = ["count=" + P];
                    U == -1 ? P > 0 ? (U = X[0].B, f.push("ofs=" + U)) : U = 0 : f.push("ofs=" + U);
                    for (var h = !0, c = 0; c < P; c++) {
                        var Z = X[c].B,
                            S = X[c].map;
                        Z -= U;
                        if (Z < 0) U = Math.max(0, X[c].B - 100), h = !1;
                        else try {
                            SmA(S, f, "req" + Z + "_")
                        } catch (H) {
                            u && u(S)
                        }
                    }
                    if (h) {
                        u = f.join("&");
                        break a
                    }
                }
                u = void 0
            }
            w = w.C.splice(0, P);
            M.Lu = w;
            return u
        },
        urt = function(w) {
            w.B || w.V || (w.M7 = 1, g.Vk(w.aS, w), w.Lu = 0)
        },
        aKp = function(w) {
            if (w.B || w.V || w.Lu >= 3) return !1;
            w.M7++;
            w.V = DJ((0, g.fC)(w.aS, w), EFc(w, w.Lu));
            w.Lu++;
            return !0
        },
        pnh = function(w) {
            w.ys != null && (g.aF.clearTimeout(w.ys), w.ys = null)
        },
        oFa = function(w) {
            w.B = new Yb(w, w.X, "rpc", w.M7);
            w.j === null && (w.B.UO = w.S);
            w.B.jL = 0;
            var M = w.DX.clone();
            g.WG(M, "RID", "rpc");
            g.WG(M, "SID", w.X);
            g.WG(M, "AID", w.t9);
            g.WG(M, "CI", w.OO ? "0" : "1");
            !w.OO && w.KT && g.WG(M, "TO", w.KT);
            g.WG(M, "TYPE", "xmlhttp");
            RM(w, M);
            w.j && w.S && g.Sr(M, w.j, w.S);
            w.jL && w.B.setTimeout(w.jL);
            var P = w.B;
            w = w.hD;
            P.eL = 1;
            P.V = i4(M.clone());
            P.S = null;
            P.Cu = !0;
            K5p(P, w)
        },
        l4 = function(w) {
            w.B3 != null && (g.aF.clearTimeout(w.B3), w.B3 = null)
        },
        xxt = function(w, M) {
            var P = null;
            if (w.B == M) {
                l4(w);
                pnh(w);
                w.B = null;
                var u = 2
            } else if (OBA(w.L, M)) P = M.Lu, PKV(w.L, M), u = 1;
            else return;
            if (w.AV != 0)
                if (M.K)
                    if (u == 1) {
                        P = M.S ? M.S.length : 0;
                        M = Date.now() - M.mN;
                        var X = w.mN;
                        u = kZt();
                        u.dispatchEvent(new vSC(u, P, M, X));
                        Br(w)
                    } else urt(w);
            else {
                var U = M.cj;
                X = M.getLastError();
                if (X == 3 || X == 0 && U > 0 || !(u == 1 && NH$(w, M) || u == 2 && aKp(w))) switch (P && P.length > 0 && (M = w.L, M.C = M.C.concat(P)), X) {
                    case 1:
                        ez(w, 5);
                        break;
                    case 4:
                        ez(w, 10);
                        break;
                    case 3:
                        ez(w, 6);
                        break;
                    default:
                        ez(w, 2)
                }
            }
        },
        EFc = function(w, M) {
            var P = w.gb + Math.floor(Math.random() *
                w.wb);
            w.isActive() || (P *= 2);
            return P * M
        },
        ez = function(w, M) {
            if (M == 2) {
                var P = (0, g.fC)(w.U83, w),
                    u = w.TD,
                    X = !u;
                u = new g.ic(u || "//www.google.com/images/cleardot.gif");
                g.aF.location && g.aF.location.protocol == "http" || g.Mb(u, "https");
                i4(u);
                X ? hD4(u.toString(), P) : cSV(u.toString(), P)
            } else yv(2);
            w.AV = 0;
            w.G && w.G.jJ(M);
            GgA(w);
            FuA(w)
        },
        GgA = function(w) {
            w.AV = 0;
            w.fg = [];
            if (w.G) {
                var M = Wua(w.L);
                if (M.length != 0 || w.C.length != 0) g.kV(w.fg, M), g.kV(w.fg, w.C), w.L.C.length = 0, g.LC(w.C), w.C.length = 0;
                w.G.w_()
            }
        },
        ySE = function(w) {
            if (w.AV == 0) return w.fg;
            var M = [];
            g.kV(M, Wua(w.L));
            g.kV(M, w.C);
            return M
        },
        Mh$ = function(w, M, P) {
            var u = g.hK(P);
            u.B != "" ? (M && g.PG(u, M + "." + u.B), g.uc(u, u.C)) : (u = g.aF.location, u = Tox(u.protocol, M ? M + "." + u.hostname : u.hostname, +u.port, P));
            M = w.Cu;
            P = w.DO;
            M && P && g.WG(u, M, P);
            g.WG(u, "VER", w.g_);
            RM(w, u);
            return u
        },
        IKV = function(w, M, P) {
            if (M && !w.eL) throw Error("Can't create secondary domain capable XhrIo object.");
            M = w.Lx && !w.rB ? new g.Ky(new g.tC({
                Q6: P
            })) : new g.Ky(w.rB);
            M.j = w.eL;
            return M
        },
        Dih = function() {},
        qmt = function() {},
        vr = function(w, M) {
            g.WX.call(this);
            this.B = new H0x(M);
            this.G = w;
            this.L = M && M.f3O || null;
            w = M && M.PW3 || null;
            M && M.QNI && (w ? w["X-Client-Protocol"] = "webchannel" : w = {
                "X-Client-Protocol": "webchannel"
            });
            this.B.S = w;
            w = M && M.a$0 || null;
            M && M.HJ && (w ? w["X-WebChannel-Content-Type"] = M.HJ : w = {
                "X-WebChannel-Content-Type": M.HJ
            });
            M && M.qJ && (w ? w["X-WebChannel-Client-Profile"] = M.qJ : w = {
                "X-WebChannel-Client-Profile": M.qJ
            });
            this.B.cj = w;
            (w = M && M.gXL) && !g.lA(w) && (this.B.j = w);
            this.K = M && M.rxu || !1;
            this.X = M && M.tB$ || !1;
            (M = M && M.Pz) && !g.lA(M) && (this.B.Cu = M, g.h5(this.L, M) && (w =
                this.L, M in w && delete w[M]));
            this.C = new ng(this)
        },
        Ym$ = function(w) {
            eWE.call(this);
            w.__headers__ && (this.headers = w.__headers__, this.statusCode = w.__status__, delete w.__headers__, delete w.__status__);
            var M = w.__sm__;
            M ? this.data = (this.B = g.$s(M)) ? g.HT(M, this.B) : M : this.data = w
        },
        zDa = function(w) {
            B$h.call(this);
            this.status = 1;
            this.errorCode = w
        },
        ng = function(w) {
            this.B = w
        },
        TH4 = function(w, M) {
            this.L = w;
            this.B = M
        },
        dip = function(w) {
            return ySE(w.B).map(function(M) {
                var P = w.L;
                M = M.map;
                "__data__" in M ? (M = M.__data__, P = P.X ? mT$(M) : M) : P = M;
                return P
            })
        },
        sj = function(w, M) {
            if (typeof w !== "function") throw Error("Fn must not be null and must be a function");
            return g.aF.setTimeout(function() {
                w()
            }, M)
        },
        b4 = function(w) {
            Kg.dispatchEvent(new lqC(Kg, w))
        },
        lqC = function(w) {
            g.Iu.call(this, "statevent", w)
        },
        IM = function(w, M, P, u) {
            this.B = w;
            this.X = M;
            this.j = P;
            this.K = u || 1;
            this.L = 45E3;
            this.C = new g.HG(this);
            this.G = new g.e7;
            this.G.setInterval(250)
        },
        eDc = function(w, M, P) {
            w.r3 = 1;
            w.Qd = i4(M.clone());
            w.Rj = P;
            w.Cu = !0;
            Lu4(w, null)
        },
        BHE = function(w, M, P, u, X) {
            w.r3 = 1;
            w.Qd = i4(M.clone());
            w.Rj = null;
            w.Cu = P;
            X && (w.P5 = !1);
            Lu4(w, u)
        },
        Lu4 = function(w, M) {
            w.Tp = Date.now();
            QSh(w);
            w.RT = w.Qd.clone();
            My(w.RT, "t", w.K);
            w.My = 0;
            w.RY = w.B.Ro(w.B.uG() ? M : null);
            w.E0 > 0 && (w.Ep = new g.Cb((0, g.fC)(w.tO, w, w.RY), w.E0));
            w.C.listen(w.RY, "readystatechange", w.MU);
            M = w.E7 ? g.Fm(w.E7) : {};
            w.Rj ? (w.C2 = "POST", M["Content-Type"] = "application/x-www-form-urlencoded", w.RY.send(w.RT, w.C2, w.Rj, M)) : (w.C2 = "GET", w.P5 && !g.h1 && (M.Connection = "close"), w.RY.send(w.RT, w.C2, null, M));
            w.B.C1(1)
        },
        nFU = function(w, M) {
            var P = w.My,
                u = M.indexOf("\n", P);
            if (u == -1) return kgc;
            P = Number(M.substring(P, u));
            if (isNaN(P)) return RDt;
            u += 1;
            if (u + P > M.length) return kgc;
            M = M.slice(u, u + P);
            w.My = u + P;
            return M
        },
        QSh = function(w) {
            w.m2 = Date.now() + w.L;
            vFA(w, w.L)
        },
        vFA = function(w, M) {
            if (w.ge != null) throw Error("WatchDog timer not null");
            w.ge = sj((0, g.fC)(w.Cv, w), M)
        },
        sSE = function(w) {
            w.ge && (g.aF.clearTimeout(w.ge), w.ge = null)
        },
        Kut = function(w) {
            w.B.bF() || w.wu || w.B.Cw(w)
        },
        A6 = function(w) {
            sSE(w);
            g.wR(w.Ep);
            w.Ep = null;
            w.G.stop();
            w.C.removeAll();
            if (w.RY) {
                var M = w.RY;
                w.RY = null;
                M.abort();
                M.dispose()
            }
            w.c6 && (w.c6 = null)
        },
        b0h = function(w, M) {
            try {
                w.B.lj(w, M), w.B.C1(4)
            } catch (P) {}
        },
        ASh = function(w, M, P, u, X) {
            if (u == 0) P(!1);
            else {
                var U = X || 0;
                u--;
                Iqt(w, M, function(f) {
                    f ? P(!0) : g.aF.setTimeout(function() {
                        ASh(w, M, P, u, U)
                    }, U)
                })
            }
        },
        Iqt = function(w, M, P) {
            var u = new Image;
            u.onload = function() {
                try {
                    gF(u), P(!0)
                } catch (X) {}
            };
            u.onerror = function() {
                try {
                    gF(u), P(!1)
                } catch (X) {}
            };
            u.onabort = function() {
                try {
                    gF(u), P(!1)
                } catch (X) {}
            };
            u.ontimeout = function() {
                try {
                    gF(u), P(!1)
                } catch (X) {}
            };
            g.aF.setTimeout(function() {
                if (u.ontimeout) u.ontimeout()
            }, M);
            u.src = w
        },
        gF = function(w) {
            w.onload = null;
            w.onerror = null;
            w.onabort = null;
            w.ontimeout = null
        },
        gF4 = function(w) {
            this.B = w;
            this.L = new oM
        },
        JS3 = function(w) {
            var M = J6(w.B, w.h4, "/mail/images/cleardot.gif");
            i4(M);
            ASh(M.toString(), 5E3, (0, g.fC)(w.bH, w), 3, 2E3);
            w.C1(1)
        },
        rSE = function(w) {
            var M = w.B.K;
            M != null ? (b4(5), M ? (b4(11), rF(w.B, w, !1)) : (b4(12), rF(w.B, w, !0))) : (w.qE = new IM(w), w.qE.E7 = w.rT, M = w.B, M = J6(M, M.uG() ? w.yQ : null, w.M_), b4(5), My(M, "TYPE", "xmlhttp"), BHE(w.qE, M, !1, w.yQ, !1))
        },
        jSa = function(w, M, P) {
            this.B = 1;
            this.L = [];
            this.C = [];
            this.G = new oM;
            this.S = w || null;
            this.K = M != null ? M : null;
            this.V = P || !1
        },
        CKp = function(w, M) {
            this.B = w;
            this.map = M;
            this.context = null
        },
        thA = function(w, M, P, u) {
            g.Iu.call(this, "timingevent", w);
            this.size = M;
            this.rtt = P;
            this.retries = u
        },
        xiA = function(w) {
            g.Iu.call(this, "serverreachability", w)
        },
        aqV = function(w) {
            w.yR(1, 0);
            w.X3 = J6(w, null, w.XQ);
            O0x(w)
        },
        wNV = function(w) {
            w.dw && (w.dw.abort(), w.dw = null);
            w.Id && (w.Id.cancel(), w.Id = null);
            w.kX && (g.aF.clearTimeout(w.kX), w.kX = null);
            jz(w);
            w.m8 && (w.m8.cancel(), w.m8 = null);
            w.cW && (g.aF.clearTimeout(w.cW), w.cW = null)
        },
        iAE = function(w, M) {
            if (w.B == 0) throw Error("Invalid operation: sending map when state is closed");
            w.L.push(new CKp(w.Xj++, M));
            w.B != 2 && w.B != 3 || O0x(w)
        },
        MPE = function(w) {
            var M = 0;
            w.Id && M++;
            w.m8 && M++;
            return M
        },
        O0x = function(w) {
            w.m8 || w.cW || (w.cW = sj((0, g.fC)(w.ij, w), 0), w.j8 = 0)
        },
        XNx = function(w, M) {
            if (w.B == 1) {
                if (!M) {
                    w.lG = Math.floor(Math.random() * 1E5);
                    M = w.lG++;
                    var P = new IM(w, "", M);
                    P.E7 = w.Ay;
                    var u = Pbp(w),
                        X = w.X3.clone();
                    g.WG(X, "RID", M);
                    g.WG(X, "CVER", "1");
                    Cg(w, X);
                    eDc(P, X, u);
                    w.m8 = P;
                    w.B = 2
                }
            } else w.B == 3 && (M ? u7C(w, M) : w.L.length == 0 || w.m8 || u7C(w))
        },
        u7C = function(w, M) {
            if (M)
                if (w.rz > 6) {
                    w.L = w.C.concat(w.L);
                    w.C.length = 0;
                    var P = w.lG - 1;
                    M = Pbp(w)
                } else P = M.j, M = M.Rj;
            else P = w.lG++, M = Pbp(w);
            var u = w.X3.clone();
            g.WG(u, "SID", w.X);
            g.WG(u, "RID", P);
            g.WG(u, "AID", w.T_);
            Cg(w, u);
            P = new IM(w, w.X, P, w.j8 + 1);
            P.E7 = w.Ay;
            P.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            w.m8 = P;
            eDc(P, u, M)
        },
        Cg = function(w, M) {
            w.bX && (w = w.bX.Hd()) && g.wd(w, function(P, u) {
                g.WG(M, u, P)
            })
        },
        Pbp = function(w) {
            var M = Math.min(w.L.length, 1E3),
                P = ["count=" + M];
            if (w.rz > 6 && M > 0) {
                var u = w.L[0].B;
                P.push("ofs=" + u)
            } else u = 0;
            for (var X = {}, U = 0; U < M; X = {
                    OX: void 0
                }, U++) {
                X.OX = w.L[U].B;
                var f = w.L[U].map;
                X.OX = w.rz <= 6 ? U : X.OX - u;
                try {
                    g.wd(f, function(h) {
                        return function(c, Z) {
                            P.push("req" + h.OX + "_" + Z + "=" + encodeURIComponent(c))
                        }
                    }(X))
                } catch (h) {
                    P.push("req" + X.OX + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            w.C = w.C.concat(w.L.splice(0, M));
            return P.join("&")
        },
        $ZA = function(w) {
            w.Id || w.kX || (w.j = 1, w.kX = sj((0, g.fC)(w.n_, w), 0), w.Q5 = 0)
        },
        flt = function(w) {
            if (w.Id || w.kX || w.Q5 >= 3) return !1;
            w.j++;
            w.kX = sj((0, g.fC)(w.n_, w), UZ$(w, w.Q5));
            w.Q5++;
            return !0
        },
        rF = function(w, M, P) {
            w.iV = w.K == null ? P : !w.K;
            w.K0 = M.Fk;
            w.V || aqV(w)
        },
        jz = function(w) {
            w.CK != null && (g.aF.clearTimeout(w.CK), w.CK = null)
        },
        UZ$ = function(w, M) {
            var P = 5E3 + Math.floor(Math.random() * 1E4);
            w.isActive() || (P *= 2);
            return P * M
        },
        t6 = function(w, M) {
            if (M == 2 || M == 9) {
                var P = null;
                w.bX && (P = null);
                var u = (0, g.fC)(w.d89, w);
                P || (P = new g.ic("//www.google.com/images/cleardot.gif"), i4(P));
                Iqt(P.toString(), 1E4, u)
            } else b4(2);
            WmU(w, M)
        },
        WmU = function(w, M) {
            w.B = 0;
            w.bX && w.bX.NH(M);
            hNC(w);
            wNV(w)
        },
        hNC = function(w) {
            w.B = 0;
            w.K0 = -1;
            if (w.bX)
                if (w.C.length == 0 && w.L.length == 0) w.bX.WU();
                else {
                    var M = g.LC(w.C),
                        P = g.LC(w.L);
                    w.C.length = 0;
                    w.L.length = 0;
                    w.bX.WU(M, P)
                }
        },
        J6 = function(w, M, P) {
            var u = g.hK(P);
            if (u.B != "") M && g.PG(u, M + "." + u.B), g.uc(u, u.C);
            else {
                var X = window.location;
                u = Tox(X.protocol, M ? M + "." + X.hostname : X.hostname, +X.port, P)
            }
            w.t_ && g.wd(w.t_, function(U, f) {
                g.WG(u, f, U)
            });
            g.WG(u, "VER", w.rz);
            Cg(w, u);
            return u
        },
        chx = function() {},
        ZAE = function() {
            this.B = [];
            this.L = []
        },
        SU$ = function(w) {
            g.Iu.call(this, "channelMessage");
            this.message = w
        },
        HAC = function(w) {
            g.Iu.call(this, "channelError");
            this.error = w
        },
        pNC = function(w, M) {
            this.action = w;
            this.params = M || {}
        },
        xb = function(w, M) {
            g.v.call(this);
            this.B = new g.gV(this.fOu, 0, this);
            g.b(this, this.B);
            this.Hb = 5E3;
            this.L = 0;
            if (typeof w === "function") M && (w = (0, g.fC)(w, M));
            else if (w && typeof w.handleEvent === "function") w = (0, g.fC)(w.handleEvent, w);
            else throw Error("Invalid listener argument");
            this.C = w
        },
        FmU = function(w, M, P, u, X, U, f, h, c, Z, S, H, p, F) {
            P = P === void 0 ? !1 : P;
            u = u === void 0 ? function() {
                return ""
            } : u;
            X = X === void 0 ? !1 : X;
            U = U === void 0 ? !1 : U;
            f = f === void 0 ? !1 : f;
            h = h === void 0 ? function() {
                return g.zS({})
            } : h;
            c = c === void 0 ? !1 : c;
            S = S === void 0 ? !1 : S;
            H = H === void 0 ? !1 : H;
            p = p === void 0 ? !1 : p;
            F = F === void 0 ? !1 : F;
            this.eL = w;
            this.B3 = M;
            this.K = new g.oC;
            this.L = new xb(this.kD0, this);
            this.B = null;
            this.j = !1;
            this.S = null;
            this.mN = "";
            this.Lu = this.V = 0;
            this.C = [];
            this.M7 = P;
            this.Cu = u;
            this.G = U;
            this.UO = h;
            this.xu = Z;
            this.hD = f;
            this.ys = null;
            this.X = g.zS();
            this.GE = X;
            this.fg = c;
            this.bW = S;
            this.Z3 = H;
            this.QE = p;
            this.cj = F;
            this.jL = new ohc;
            this.OO = new GXp;
            this.iW = new DTV;
            this.Yu = new yR4;
            this.t9 = new qKE;
            this.TE = new YKt;
            this.VE = new z$U
        },
        VPp = function(w,
            M, P, u, X) {
            E1t(w);
            if (w.B) {
                var U = g.AR("ID_TOKEN"),
                    f = w.B.Ay || {};
                U ? f["x-youtube-identity-token"] = U : delete f["x-youtube-identity-token"];
                w.B.Ay = f
            }
            NKh(w);
            u ? (u.getState() != 3 && MPE(u) == 0 || u.getState(), w.B.connect(M, P, w.B3, u.X, u.T_)) : X ? w.B.connect(M, P, w.B3, X.sessionId, X.arrayId) : w.B.connect(M, P, w.B3)
        },
        yhx = function(w, M) {
            return w.QE ? !0 : w.Z3 ? Object.values(mZc).includes(M) : w.bW ? !Object.values(o1t).includes(M) : w.cj ? Object.values(G$t).includes(M) : !1
        },
        YUt = function(w) {
            var M, P;
            g.n(function(u) {
                if (u.L == 1) return g.q_(u, 2), g.B(u, DZ$(w), 2);
                g.B5(u);
                M = w.C;
                w.C = [];
                P = M.length;
                qUh(w, M, P);
                Oj(w);
                return g.Qx(u, 0)
            })
        },
        qUh = function(w, M, P) {
            for (var u = 0; u < P; ++u) iAE(w.B, M[u]);
            Oj(w)
        },
        Oj = function(w) {
            w.publish("handlerOpened");
            w.jL.lC("BROWSER_CHANNEL")
        },
        E1t = function(w) {
            if (w.B) {
                var M = w.Cu(),
                    P = w.B.Ay || {};
                M ? P["x-youtube-lounge-xsrf-token"] = M : delete P["x-youtube-lounge-xsrf-token"];
                w.B.Ay = P
            }
        },
        DZ$ = function(w) {
            if (w.fg) return g.zS();
            if (!w.hD) return zNc(w);
            w.ys === null && (w.ys = zNc(w));
            return w.ys
        },
        zNc = function(w) {
            return g.lO(w.UO().then(function(M) {
                TKE(w, M)
            }).NS(function() {}), function() {
                w.ys = null
            })
        },
        TKE = function(w, M) {
            if (w.B) {
                var P = w.B.Ay || {};
                M && Object.keys(M).length > 0 ? P = Object.assign({}, P, M) : delete P.Authorization;
                w.B.Ay = P
            }
        },
        NKh = function(w) {
            w.xu && !w.G && TKE(w, w.xu())
        },
        aM = function(w) {
            this.scheme = "https";
            this.port = this.domain = "";
            this.B = "/api/lounge";
            this.L = !0;
            w = w || document.location.href;
            var M = Number(g.UQ(w)[4] || null) || "";
            M && (this.port = ":" + M);
            this.domain = g.f5(w) || "";
            w = g.RK();
            w.search("MSIE") >= 0 && (w = w.match(/MSIE ([\d.]+)/)[1], g.ks(w, "10.0") < 0 && (this.L = !1))
        },
        wX = function(w, M) {
            var P = w.B;
            w.L && (P = w.scheme + "://" + w.domain + w.port + w.B);
            return g.p5(P + M, {})
        },
        dZ4 = function(w, M) {
            g.WX.call(this);
            var P = this;
            this.bB = w();
            this.bB.subscribe("handlerOpened", this.dP, this);
            this.bB.subscribe("handlerClosed", this.onClosed, this);
            this.bB.subscribe("handlerError", function(u, X) {
                P.onError(X)
            });
            this.bB.subscribe("handlerMessage", this.onMessage, this);
            this.B = M
        },
        ll3 = function(w, M, P) {
            var u = this;
            P = P === void 0 ? function() {
                return ""
            } : P;
            var X = X === void 0 ? new qmt : X;
            var U = U === void 0 ? new g.oC : U;
            this.pathPrefix = w;
            this.B = M;
            this.mN = P;
            this.G = U;
            this.V = null;
            this.S = this.j = 0;
            this.channel = null;
            this.K = 0;
            this.C = new xb(function() {
                u.C.isActive();
                var f;
                ((f = u.channel) == null ? void 0 : wnV((new TH4(f, f.B)).B.L)) === 0 && u.connect(u.V, u.j)
            });
            this.X = {};
            this.L = {};
            this.B3 = !1;
            this.logger = null;
            this.Lu = [];
            this.Oq = void 0;
            this.UO = new ohc;
            this.ys = new GXp;
            this.xu = new yR4;
            this.Cu = new qKE
        },
        LmA = function(w) {
            g.x4(w.channel, "m", function() {
                w.K = 3;
                w.C.reset();
                w.V = null;
                w.j = 0;
                for (var M = g.G(w.Lu), P = M.next(); !P.done; P = M.next()) P = P.value, w.channel && w.channel.send(P);
                w.Lu = [];
                w.publish("webChannelOpened");
                w.UO.lC("WEB_CHANNEL")
            });
            g.x4(w.channel, "n", function() {
                w.K = 0;
                w.C.isActive() || w.publish("webChannelClosed");
                var M, P = (M = w.channel) == null ? void 0 : dip(new TH4(M, M.B));
                P && (w.Lu = [].concat(g.L(P)));
                w.ys.lC("WEB_CHANNEL")
            });
            g.x4(w.channel, "p", function(M) {
                var P = M.data;
                P[0] === "gracefulReconnect" ? (w.C.start(), w.channel && w.channel.close()) : w.publish("webChannelMessage", new pNC(P[0], P[1]));
                w.Oq = M.statusCode;
                w.xu.lC("WEB_CHANNEL")
            });
            g.x4(w.channel, "o", function() {
                w.Oq === 401 || w.C.start();
                w.publish("webChannelError");
                w.Cu.lC("WEB_CHANNEL", "")
            })
        },
        eNC = function(w) {
            var M = w.mN();
            M ? w.X["x-youtube-lounge-xsrf-token"] = M : delete w.X["x-youtube-lounge-xsrf-token"]
        },
        BK$ = function(w) {
            g.WX.call(this);
            this.B = w();
            this.B.subscribe("webChannelOpened", this.Ui, this);
            this.B.subscribe("webChannelClosed", this.onClosed, this);
            this.B.subscribe("webChannelError", this.onError, this);
            this.B.subscribe("webChannelMessage", this.onMessage, this)
        },
        QmA = function(w, M, P, u, X) {
            function U() {
                return new FmU(wX(w, "/bc"), M, !1, P, u)
            }
            P = P === void 0 ? function() {
                return ""
            } : P;
            return g.FW("enable_mdx_web_channel_desktop") ? new BK$(function() {
                return new ll3(wX(w, "/wc"), M, P)
            }) : new dZ4(U, X)
        },
        v1U = function() {
            var w = k$c;
            RNc();
            i7.push(w);
            n1a()
        },
        MA = function(w, M) {
            RNc();
            var P = smh(w, String(M));
            i7.length == 0 ? Km4(P) : (n1a(), g.tx(i7, function(u) {
                u(P)
            }))
        },
        Pd = function(w) {
            MA("CP", w)
        },
        RNc = function() {
            i7 || (i7 = g.Mj("yt.mdx.remote.debug.handlers_") || [], g.ih("yt.mdx.remote.debug.handlers_", i7))
        },
        Km4 = function(w) {
            var M = (u7 + 1) % 50;
            u7 = M;
            X9[M] = w;
            $_ || ($_ = M == 49)
        },
        n1a = function() {
            var w = i7;
            if (X9[0]) {
                var M = $_ ? u7 : -1,
                    P = {};
                do P = {
                    hh: void 0
                }, M = (M + 1) % 50, P.hh = X9[M], g.tx(w, function(u) {
                    return function(X) {
                        X(u.hh)
                    }
                }(P));
                while (M != u7);
                X9 = Array(50);
                u7 = -1;
                $_ = !1
            }
        },
        smh = function(w, M) {
            var P = (Date.now() - bA$) / 1E3;
            P.toFixed && (P = P.toFixed(3));
            var u = [];
            u.push("[", P + "s", "] ");
            u.push("[", "yt.mdx.remote", "] ");
            u.push(w + ": " + M, "\n");
            return u.join("")
        },
        U9 = function(w) {
            g.wC.call(this);
            this.K = w;
            this.screens = []
        },
        Ilt = function(w, M) {
            var P = w.get(M.uuid) || w.get(M.id);
            if (P) return w = P.name, P.id = M.id || P.id, P.name = M.name, P.token = M.token, P.uuid = M.uuid || P.uuid, P.name != w;
            w.screens.push(M);
            return !0
        },
        Aht = function(w, M) {
            var P = w.screens.length != M.length;
            w.screens = g.DP(w.screens, function(U) {
                return !!Uxt(M, U)
            });
            for (var u = M.length, X = 0; X < u; X++) P = Ilt(w, M[X]) || P;
            return P
        },
        g14 = function(w, M) {
            var P = w.screens.length;
            w.screens = g.DP(w.screens, function(u) {
                return !(u || M ? !u != !M ? 0 : u.id == M.id : 1)
            });
            return w.screens.length < P
        },
        Jh3 = function(w, M, P, u, X) {
            g.wC.call(this);
            this.C = w;
            this.j = M;
            this.X = P;
            this.K = u;
            this.G = X;
            this.L = 0;
            this.B = null;
            this.jZ = NaN
        },
        Wd = function(w) {
            U9.call(this, "LocalScreenService");
            this.L = w;
            this.B = NaN;
            fu(this);
            this.info("Initializing with " + uW3(this.screens))
        },
        rhA = function(w) {
            if (w.screens.length) {
                var M = g.EV(w.screens, function(u) {
                        return u.id
                    }),
                    P = wX(w.L, "/pairing/get_lounge_token_batch");
                w.L.sendRequest("POST", P, {
                    screen_ids: M.join(",")
                }, (0, g.fC)(w.DB, w), (0, g.fC)(w.Go, w))
            }
        },
        fu = function(w) {
            if (g.FW("deprecate_pair_servlet_enabled")) return Aht(w, []);
            var M = PL3(HBE());
            M = g.DP(M, function(P) {
                return !P.uuid
            });
            return Aht(w, M)
        },
        ho = function(w, M) {
            F5x(g.EV(w.screens, R$$));
            M && pFx()
        },
        CbC = function(w, M) {
            g.wC.call(this);
            this.K = M;
            M = (M = g.dH("yt-remote-online-screen-ids") || "") ? M.split(",") : [];
            for (var P = {}, u = this.K(), X = u.length, U = 0; U < X; ++U) {
                var f = u[U].id;
                P[f] = g.o$(M, f)
            }
            this.B = P;
            this.G = w;
            this.C = this.X = NaN;
            this.L = null;
            jmE("Initialized with " + g.ny(this.B))
        },
        tPp = function(w, M, P) {
            var u = wX(w.G, "/pairing/get_screen_availability");
            w.G.sendRequest("POST", u, {
                lounge_token: M.token
            }, (0, g.fC)(function(X) {
                X = X.screens || [];
                for (var U = X.length, f = 0; f < U; ++f)
                    if (X[f].loungeToken == M.token) {
                        P(X[f].status == "online");
                        return
                    }
                P(!1)
            }, w), (0, g.fC)(function() {
                P(!1)
            }, w))
        },
        OAt = function(w, M) {
            a: if (No$(M) != No$(w.B)) var P = !1;
                else {
                    P = g.WT(M);
                    for (var u = P.length, X = 0; X < u; ++X)
                        if (!w.B[P[X]]) {
                            P = !1;
                            break a
                        }
                    P = !0
                }P || (jmE("Updated online screens: " + g.ny(w.B)), w.B = M, w.publish("screenChange"));xZt(w)
        },
        cd = function(w) {
            isNaN(w.C) || g.S9(w.C);
            w.C = g.cF((0, g.fC)(w.yb, w), w.X > 0 && w.X < g.ca() ? 2E4 : 1E4)
        },
        jmE = function(w) {
            MA("OnlineScreenService", w)
        },
        alh = function(w) {
            var M = {};
            g.tx(w.K(), function(P) {
                P.token ? M[P.token] = P.id : this.y0("Requesting availability of screen w/o lounge token.")
            });
            return M
        },
        xZt = function(w) {
            w = g.WT(g.iA(w.B, function(M) {
                return M
            }));
            g.r3(w);
            w.length ? g.Tg("yt-remote-online-screen-ids", w.join(","), 60) : g.lK("yt-remote-online-screen-ids")
        },
        Zu = function(w, M) {
            M = M === void 0 ? !1 : M;
            U9.call(this, "ScreenService");
            this.X = w;
            this.j = M;
            this.B = this.L = null;
            this.C = [];
            this.G = {};
            wbU(this)
        },
        MUj = function(w, M, P, u, X, U) {
            w.info("getAutomaticScreenByIds " + P + " / " + M);
            P || (P = w.G[M]);
            var f = w.dG(),
                h = P ? ZJ(f, P) : null;
            P && (w.j || h) || (h = ZJ(f, M));
            if (h) {
                h.uuid = M;
                var c = S_(w, h);
                tPp(w.B, c, function(Z) {
                    X(Z ? c : null)
                })
            } else P ? idC(w, P, (0, g.fC)(function(Z) {
                var S = S_(this, new Wr({
                    name: u,
                    screenId: P,
                    loungeToken: Z,
                    dialId: M || ""
                }));
                tPp(this.B, S, function(H) {
                    X(H ? S : null)
                })
            }, w), U) : X(null)
        },
        PvA = function(w, M) {
            for (var P = w.screens.length, u = 0; u < P; ++u)
                if (w.screens[u].name == M) return w.screens[u];
            return null
        },
        uXc = function(w, M, P) {
            tPp(w.B, M, P)
        },
        idC = function(w, M, P, u) {
            w.info("requestLoungeToken_ for " + M);
            var X = {
                postParams: {
                    screen_ids: M
                },
                method: "POST",
                context: w,
                onSuccess: function(U, f) {
                    U = f && f.screens || [];
                    U[0] && U[0].screenId == M ? P(U[0].loungeToken) : u(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    u(Error("Request screen lounge token failed"))
                }
            };
            g.o1(wX(w.X, "/pairing/get_lounge_token_batch"), X)
        },
        XbE = function(w) {
            w.screens = w.L.dG();
            var M = w.G,
                P = {},
                u;
            for (u in M) P[M[u]] = u;
            M = w.screens.length;
            for (u = 0; u < M; ++u) {
                var X = w.screens[u];
                X.uuid = P[X.id] || ""
            }
            w.info("Updated manual screens: " + uW3(w.screens))
        },
        wbU = function(w) {
            $6E(w);
            w.L = new Wd(w.X);
            w.L.subscribe("screenChange", (0, g.fC)(w.lA, w));
            XbE(w);
            w.j || (w.C = PL3(g.dH("yt-remote-automatic-screen-cache") || []));
            $6E(w);
            w.info("Initializing automatic screens: " + uW3(w.C));
            w.B = new CbC(w.X, (0, g.fC)(w.dG, w, !0));
            w.B.subscribe("screenChange", (0, g.fC)(function() {
                this.publish("onlineScreenChange")
            }, w))
        },
        S_ = function(w, M) {
            var P = w.get(M.id);
            P ? (P.uuid = M.uuid, M = P) : ((P = ZJ(w.C, M.uuid)) ? (P.id = M.id, P.token = M.token, M = P) : w.C.push(M), w.j || U6$(w));
            $6E(w);
            w.G[M.uuid] = M.id;
            g.Tg("yt-remote-device-id-map", w.G, 31536E3);
            return M
        },
        U6$ = function(w) {
            w = g.DP(w.C, function(M) {
                return M.idType != "shortLived"
            });
            g.Tg("yt-remote-automatic-screen-cache", g.EV(w, R$$))
        },
        $6E = function(w) {
            w.G = g.dH("yt-remote-device-id-map") || {}
        },
        Hd = function(w, M, P) {
            g.wC.call(this);
            this.Cu = P;
            this.X = w;
            this.L = M;
            this.B = null
        },
        pu = function(w, M) {
            w.B = M;
            w.publish("sessionScreen", w.B)
        },
        f8$ = function(w, M) {
            w.B && (w.B.token = M, S_(w.X, w.B));
            w.publish("sessionScreen", w.B)
        },
        F9 = function(w, M) {
            MA(w.Cu, M)
        },
        E9 = function(w, M, P) {
            Hd.call(this, w, M, "CastSession");
            var u = this;
            this.config_ = P;
            this.C = null;
            this.Lu = (0, g.fC)(this.Gs, this);
            this.ys = (0, g.fC)(this.XlO, this);
            this.B3 = g.cF(function() {
                Wha(u, null)
            }, 12E4);
            this.j = this.G = this.K = this.V = 0;
            this.mN = !1;
            this.S = "unknown"
        },
        cip = function(w, M) {
            g.S9(w.j);
            w.j = 0;
            M == 0 ? hzt(w) : w.j = g.cF(function() {
                hzt(w)
            }, M)
        },
        hzt = function(w) {
            Zd3(w, "getLoungeToken");
            g.S9(w.G);
            w.G = g.cF(function() {
                SYE(w, null)
            }, 3E4)
        },
        Zd3 = function(w, M) {
            w.info("sendYoutubeMessage_: " + M + " " + g.ny());
            var P = {};
            P.type = M;
            w.C ? w.C.sendMessage("urn:x-cast:com.google.youtube.mdx", P, function() {}, (0, g.fC)(function() {
                F9(this, "Failed to send message: " + M + ".")
            }, w)) : F9(w, "Sending yt message without session: " + g.ny(P))
        },
        Hdh = function(w, M) {
            M ? (w.info("onConnectedScreenId_: Received screenId: " + M), w.B && w.B.id == M || w.dX(M, function(P) {
                pu(w, P)
            }, function() {
                return w.wg()
            }, 5)) : w.wg(Error("Waiting for session status timed out."))
        },
        Fhj = function(w, M, P) {
            w.info("onConnectedScreenData_: Received screenData: " + JSON.stringify(M));
            var u = new Wr(M);
            pbA(w, u, function(X) {
                X ? (w.mN = !0, S_(w.X, u), pu(w, u), w.S = "unknown", cip(w, P)) : (g.ro(Error("CastSession, RemoteScreen from screenData: " + JSON.stringify(M) + " is not online.")), w.wg())
            }, 5)
        },
        Wha = function(w, M) {
            g.S9(w.B3);
            w.B3 = 0;
            M ? w.config_.enableCastLoungeToken && M.loungeToken ? M.deviceId ? w.B && w.B.uuid == M.deviceId || (M.loungeTokenRefreshIntervalMs ? Fhj(w, {
                    name: w.L.friendlyName,
                    screenId: M.screenId,
                    loungeToken: M.loungeToken,
                    dialId: M.deviceId,
                    screenIdType: "shortLived"
                }, M.loungeTokenRefreshIntervalMs) : (g.ro(Error("No loungeTokenRefreshIntervalMs presents in mdxSessionStatusData: " + JSON.stringify(M) + ".")), Hdh(w, M.screenId))) : (g.ro(Error("No device id presents in mdxSessionStatusData: " + JSON.stringify(M) + ".")), Hdh(w, M.screenId)) :
                Hdh(w, M.screenId) : w.wg(Error("Waiting for session status timed out."))
        },
        SYE = function(w, M) {
            g.S9(w.G);
            w.G = 0;
            var P = null;
            if (M)
                if (M.loungeToken) {
                    var u;
                    ((u = w.B) == null ? void 0 : u.token) == M.loungeToken && (P = "staleLoungeToken")
                } else P = "missingLoungeToken";
            else P = "noLoungeTokenResponse";
            P ? (w.info("Did not receive a new lounge token in onLoungeToken_ with data: " + (JSON.stringify(M) + ", error: " + P)), w.S = P, cip(w, 3E4)) : (f8$(w, M.loungeToken), w.mN = !1, w.S = "unknown", cip(w, M.loungeTokenRefreshIntervalMs))
        },
        pbA = function(w, M, P, u) {
            g.S9(w.K);
            w.K = 0;
            uXc(w.X, M, function(X) {
                X || u < 0 ? P(X) : w.K = g.cF(function() {
                    pbA(w, M, P, u - 1)
                }, 300)
            })
        },
        EQA = function(w) {
            g.S9(w.V);
            w.V = 0;
            g.S9(w.K);
            w.K = 0;
            g.S9(w.B3);
            w.B3 = 0;
            g.S9(w.G);
            w.G = 0;
            g.S9(w.j);
            w.j = 0
        },
        NA = function(w, M, P, u) {
            Hd.call(this, w, M, "DialSession");
            this.config_ = u;
            this.C = this.V = null;
            this.ys = "";
            this.eL = P;
            this.UO = null;
            this.B3 = function() {};
            this.S = NaN;
            this.xu = (0, g.fC)(this.Dj, this);
            this.G = function() {};
            this.j = this.K = 0;
            this.Lu = !1;
            this.mN = "unknown"
        },
        V9 = function(w) {
            var M;
            return !!(w.config_.enableDialLoungeToken && ((M = w.C) == null ? 0 : M.getDialAppInfo))
        },
        N9$ = function(w) {
            w.G = w.X.bj(w.ys, w.L.label, w.L.friendlyName, V9(w), function(M, P) {
                w.G = function() {};
                w.Lu = !0;
                pu(w, M);
                M.idType == "shortLived" && P > 0 && mT(w, P)
            }, function(M) {
                w.G = function() {};
                w.wg(M)
            })
        },
        VUU = function(w) {
            var M = {};
            M.pairingCode = w.ys;
            M.theme = w.eL;
            N$E() && (M.env_useStageMdx = 1);
            return g.HY(M)
        },
        m6E = function(w) {
            return new Promise(function(M) {
                w.ys = XFC();
                if (w.UO) {
                    var P = new chrome.cast.DialLaunchResponse(!0, VUU(w));
                    M(P);
                    N9$(w)
                } else w.B3 = function() {
                    g.S9(w.S);
                    w.B3 = function() {};
                    w.S = NaN;
                    var u = new chrome.cast.DialLaunchResponse(!0, VUU(w));
                    M(u);
                    N9$(w)
                }, w.S = g.cF(function() {
                    w.B3()
                }, 100)
            })
        },
        Gsp = function(w, M, P) {
            w.info("initOnConnectedScreenDataPromise_: Received screenData: " + JSON.stringify(M));
            var u = new Wr(M);
            return (new Promise(function(X) {
                oQV(w, u, function(U) {
                    U ? (w.Lu = !0, S_(w.X, u), pu(w, u), mT(w, P)) : g.ro(Error("DialSession, RemoteScreen from screenData: " + JSON.stringify(M) + " is not online."));
                    X(U)
                }, 5)
            })).then(function(X) {
                return X ? new chrome.cast.DialLaunchResponse(!1) : m6E(w)
            })
        },
        yiC = function(w, M) {
            var P = w.V.receiver.label,
                u = w.L.friendlyName;
            return (new Promise(function(X) {
                MUj(w.X, P, M, u, function(U) {
                    U && U.token && pu(w, U);
                    X(U)
                }, function(U) {
                    F9(w, "Failed to get DIAL screen: " + U);
                    X(null)
                })
            })).then(function(X) {
                return X && X.token ? new chrome.cast.DialLaunchResponse(!1) : m6E(w)
            })
        },
        oQV = function(w, M, P, u) {
            g.S9(w.K);
            w.K = 0;
            uXc(w.X, M, function(X) {
                X || u < 0 ? P(X) : w.K = g.cF(function() {
                    oQV(w, M, P, u - 1)
                }, 300)
            })
        },
        mT = function(w, M) {
            w.info("getDialAppInfoWithTimeout_ " + M);
            V9(w) && (g.S9(w.j), w.j = 0, M == 0 ? D6h(w) : w.j = g.cF(function() {
                D6h(w)
            }, M))
        },
        D6h = function(w) {
            V9(w) && w.C.getDialAppInfo(function(M) {
                w.info("getDialAppInfo dialLaunchData: " + JSON.stringify(M));
                M = M.extraData || {};
                var P = null;
                if (M.loungeToken) {
                    var u;
                    ((u = w.B) == null ? void 0 : u.token) == M.loungeToken && (P = "staleLoungeToken")
                } else P = "missingLoungeToken";
                P ? (w.mN = P, mT(w, 3E4)) : (w.Lu = !1, w.mN = "unknown", f8$(w, M.loungeToken), mT(w, M.loungeTokenRefreshIntervalMs))
            }, function(M) {
                w.info("getDialAppInfo error: " + M);
                w.mN = "noLoungeTokenResponse";
                mT(w, 3E4)
            })
        },
        qYU = function(w) {
            g.S9(w.K);
            w.K = 0;
            g.S9(w.j);
            w.j = 0;
            w.G();
            w.G = function() {};
            g.S9(w.S)
        },
        oc = function(w, M) {
            Hd.call(this, w, M, "ManualSession");
            this.C = g.cF((0, g.fC)(this.eN, this, null), 150)
        },
        G7 = function(w, M) {
            g.wC.call(this);
            this.config_ = M;
            this.L = w;
            this.V = M.appId || "233637DE";
            this.X = M.theme || "cl";
            this.S = M.disableCastApi || !1;
            this.K = M.forceMirroring || !1;
            this.B = null;
            this.j = !1;
            this.C = [];
            this.G = (0, g.fC)(this.Ut$, this)
        },
        YY3 = function(w, M) {
            return M ? g.Nj(w.C, function(P) {
                return h6(M, P.label)
            }, w) : null
        },
        y9 = function(w) {
            MA("Controller", w)
        },
        k$c = function(w) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(w)
        },
        Du = function(w) {
            return w.j || !!w.C.length || !!w.B
        },
        qA = function(w, M, P) {
            M != w.B && (g.wR(w.B), (w.B = M) ? (P ? w.publish("yt-remote-cast2-receiver-resumed",
                M.L) : w.publish("yt-remote-cast2-receiver-selected", M.L), M.subscribe("sessionScreen", (0, g.fC)(w.H2, w, M)), M.subscribe("sessionFailed", function() {
                return zzx(w, M)
            }), M.B ? w.publish("yt-remote-cast2-session-change", M.B) : P && w.B.eN(null)) : w.publish("yt-remote-cast2-session-change", null))
        },
        zzx = function(w, M) {
            w.B == M && w.publish("yt-remote-cast2-session-failed")
        },
        T9E = function(w) {
            var M = w.L.AO(),
                P = w.B && w.B.L;
            w = g.EV(M, function(u) {
                P && h6(u, P.label) && (P = null);
                var X = u.uuid ? u.uuid : u.id,
                    U = YY3(this, u);
                U ? (U.label = X, U.friendlyName = u.name) : (U = new chrome.cast.Receiver(X, u.name), U.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return U
            }, w);
            P && (P.receiverType != chrome.cast.ReceiverType.CUSTOM && (P = new chrome.cast.Receiver(P.label, P.friendlyName), P.receiverType = chrome.cast.ReceiverType.CUSTOM), w.push(P));
            return w
        },
        ksj = function(w, M, P, u) {
            u.disableCastApi ? Y_("Cannot initialize because disabled by Mdx config.") : d63() ? l8C(M, u) && (LhC(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? ezE(w, P) : (window.__onGCastApiAvailable = function(X, U) {
                X ? ezE(w, P) : (z7("Failed to load cast API: " + U), B9c(!1), LhC(!1), g.lK("yt-remote-cast-available"), g.lK("yt-remote-cast-receiver"),
                    QXU(), P(!1))
            }, u.loadCastApiSetupScript ? g.aX("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") : window.navigator.userAgent.indexOf("Android") >= 0 && window.navigator.userAgent.indexOf("Chrome/") >= 0 && window.navigator.presentation ? mxt() >= 60 && dxj() : !window.chrome || !window.navigator.presentation || window.navigator.userAgent.indexOf("Edge") >= 0 ? DxU() : mxt() >= 89 ? L5U() : (T$c(), Vv(lK3.map(qLE))))) : Y_("Cannot initialize because not running Chrome")
        },
        QXU = function() {
            Y_("dispose");
            var w = T7();
            w && w.dispose();
            g.ih("yt.mdx.remote.cloudview.instance_", null);
            RzE(!1);
            g.xQ(nQE);
            nQE.length = 0
        },
        dX = function() {
            return !!g.dH("yt-remote-cast-installed")
        },
        vQ$ = function() {
            var w = g.dH("yt-remote-cast-receiver");
            return w ? w.friendlyName : null
        },
        sXE = function() {
            Y_("clearCurrentReceiver");
            g.lK("yt-remote-cast-receiver")
        },
        KhV = function() {
            return dX() ? T7() ? T7().getCastSession() : (z7("getCastSelector: Cast is not initialized."), null) : (z7("getCastSelector: Cast API is not installed!"), null)
        },
        bdt = function() {
            dX() ? T7() ? l7() ? (Y_("Requesting cast selector."), T7().requestSession()) : (Y_("Wait for cast API to be ready to request the session."), nQE.push(g.ti("yt-remote-cast2-api-ready", bdt))) : z7("requestCastSelector: Cast is not initialized.") : z7("requestCastSelector: Cast API is not installed!")
        },
        Lu = function(w, M) {
            l7() ? T7().setConnectedScreenStatus(w, M) : z7("setConnectedScreenStatus called before ready.")
        },
        d63 = function() {
            var w = g.RK().search(/ (CrMo|Chrome|CriOS)\//) >= 0;
            return g.p3 || w
        },
        I8t = function(w, M) {
            T7().init(w, M)
        },
        l8C = function(w, M) {
            var P = !1;
            T7() || (w = new G7(w, M), w.subscribe("yt-remote-cast2-availability-change", function(u) {
                g.Tg("yt-remote-cast-available", u);
                Ej("yt-remote-cast2-availability-change", u)
            }), w.subscribe("yt-remote-cast2-receiver-selected", function(u) {
                Y_("onReceiverSelected: " + u.friendlyName);
                g.Tg("yt-remote-cast-receiver", u);
                Ej("yt-remote-cast2-receiver-selected", u)
            }), w.subscribe("yt-remote-cast2-receiver-resumed", function(u) {
                Y_("onReceiverResumed: " + u.friendlyName);
                g.Tg("yt-remote-cast-receiver", u);
                Ej("yt-remote-cast2-receiver-resumed", u)
            }), w.subscribe("yt-remote-cast2-session-change", function(u) {
                Y_("onSessionChange: " + cr(u));
                u || g.lK("yt-remote-cast-receiver");
                Ej("yt-remote-cast2-session-change", u)
            }), g.ih("yt.mdx.remote.cloudview.instance_", w), P = !0);
            Y_("cloudview.createSingleton_: " + P);
            return P
        },
        T7 = function() {
            return g.Mj("yt.mdx.remote.cloudview.instance_")
        },
        ezE = function(w, M) {
            B9c(!0);
            LhC(!1);
            I8t(w, function(P) {
                P ? (RzE(!0), g.OY("yt-remote-cast2-api-ready")) : (z7("Failed to initialize cast API."), B9c(!1), g.lK("yt-remote-cast-available"), g.lK("yt-remote-cast-receiver"), QXU());
                M(P)
            })
        },
        Y_ = function(w) {
            MA("cloudview", w)
        },
        z7 = function(w) {
            MA("cloudview", w)
        },
        B9c = function(w) {
            Y_("setCastInstalled_ " + w);
            g.Tg("yt-remote-cast-installed", w)
        },
        l7 = function() {
            return !!g.Mj("yt.mdx.remote.cloudview.apiReady_")
        },
        RzE = function(w) {
            Y_("setApiReady_ " + w);
            g.ih("yt.mdx.remote.cloudview.apiReady_", w)
        },
        LhC = function(w) {
            g.ih("yt.mdx.remote.cloudview.initializing_", w)
        },
        e_ = function(w) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.G = this.K = 0;
            this.trackData = null;
            this.kH = this.ST = !1;
            this.V = this.C = this.j = this.L = 0;
            this.B = NaN;
            this.X = !1;
            this.reset(w)
        },
        Ai3 = function(w) {
            w.audioTrackId = null;
            w.trackData = null;
            w.playerState = -1;
            w.ST = !1;
            w.kH = !1;
            w.K = 0;
            w.G = g.ca();
            w.L = 0;
            w.j = 0;
            w.C = 0;
            w.V = 0;
            w.B = NaN;
            w.X = !1
        },
        Bd = function(w) {
            return w.isPlaying() ? (g.ca() - w.G) / 1E3 : 0
        },
        Q9 = function(w, M) {
            w.K = M;
            w.G = g.ca()
        },
        k_ = function(w) {
            switch (w.playerState) {
                case 1:
                case 1081:
                    return (g.ca() - w.G) / 1E3 + w.K;
                case -1E3:
                    return 0
            }
            return w.K
        },
        gQE = function(w) {
            return w.X ? w.j + Bd(w) : w.j
        },
        Rc = function(w, M, P) {
            var u = w.videoId;
            w.videoId = M;
            w.index = P;
            M != u && Ai3(w)
        },
        Jia = function(w) {
            var M = {};
            M.index = w.index;
            M.listId = w.listId;
            M.videoId = w.videoId;
            M.playerState = w.playerState;
            M.volume = w.volume;
            M.muted = w.muted;
            M.audioTrackId = w.audioTrackId;
            M.trackData = g.Eu(w.trackData);
            M.hasPrevious = w.ST;
            M.hasNext = w.kH;
            M.playerTime = w.K;
            M.playerTimeAt = w.G;
            M.seekableStart = w.L;
            M.seekableEnd = w.j;
            M.duration = w.C;
            M.loadedTime = w.V;
            M.liveIngestionTime = w.B;
            return M
        },
        vd = function(w, M) {
            g.wC.call(this);
            var P = this;
            this.C = 0;
            this.X = w;
            this.K = [];
            this.G = new ZAE;
            this.L = this.B = null;
            this.S = (0, g.fC)(this.jIs, this);
            this.j = (0, g.fC)(this.AL, this);
            this.V = (0, g.fC)(this.w30, this);
            this.B3 = (0, g.fC)(this.uK9, this);
            var u = 0;
            w ? (u = w.getProxyState(), u != 3 && (w.subscribe("proxyStateChange", this.NN, this), ric(this))) : u = 3;
            u != 0 && (M ? this.NN(u) : g.cF(function() {
                P.NN(u)
            }, 0));
            (w = KhV()) && nu(this, w);
            this.subscribe("yt-remote-cast2-session-change", this.B3)
        },
        s9 = function(w) {
            return new e_(w.X.getPlayerContextData())
        },
        ric = function(w) {
            g.tx("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange multiStateLoopEnabled loopModeChange".split(" "), function(M) {
                this.K.push(this.X.subscribe(M, g.Wa(this.Xkk, M), this))
            }, w)
        },
        jX$ = function(w) {
            g.tx(w.K, function(M) {
                this.X.unsubscribeByKey(M)
            }, w);
            w.K.length = 0
        },
        Ku = function(w) {
            return w.getState() == 1
        },
        b7 = function(w, M) {
            var P = w.G;
            P.B.length + P.L.length < 50 && w.G.enqueue(M)
        },
        Cvh = function(w, M, P) {
            var u = s9(w);
            Q9(u, P);
            u.playerState != -1E3 && (u.playerState = M);
            Ic(w, u)
        },
        Ao = function(w, M, P) {
            w.X.sendMessage(M, P)
        },
        Ic = function(w, M) {
            jX$(w);
            w.X.setPlayerContextData(Jia(M));
            ric(w)
        },
        nu = function(w, M) {
            w.L && (w.L.removeUpdateListener(w.S), w.L.removeMediaListener(w.j), w.AL(null));
            w.L = M;
            w.L && (Pd("Setting cast session: " + w.L.sessionId), w.L.addUpdateListener(w.S), w.L.addMediaListener(w.j), w.L.media.length && w.AL(w.L.media[0]))
        },
        tUE = function(w) {
            var M = w.B.media,
                P = w.B.customData;
            if (M && P) {
                var u = s9(w);
                M.contentId != u.videoId && Pd("Cast changing video to: " + M.contentId);
                u.videoId = M.contentId;
                u.playerState = P.playerState;
                Q9(u, w.B.getEstimatedTime());
                Ic(w, u)
            } else Pd("No cast media video. Ignoring state update.")
        },
        gX = function(w, M, P) {
            return (0, g.fC)(function(u) {
                this.y0("Failed to " + M + " with cast v2 channel. Error code: " + u.code);
                u.code != chrome.cast.ErrorCode.TIMEOUT && (this.y0("Retrying " + M + " using MDx browser channel."), Ao(this, M, P))
            }, w)
        },
        j_ = function(w, M, P, u) {
            u = u === void 0 ? !1 : u;
            g.wC.call(this);
            var X = this;
            this.K = NaN;
            this.ys = !1;
            this.S = this.V = this.Lu = this.mN = NaN;
            this.B3 = [];
            this.G = this.j = this.X = this.B = this.L = null;
            this.UO = w;
            this.xu = u;
            this.B3.push(g.Ni(window, "beforeunload", function() {
                X.FT(2)
            }));
            this.C = [];
            this.B = new e_;
            this.eL = M.id;
            this.Cu = M.idType;
            this.L = QmA(this.UO, P, this.c7, this.Cu == "shortLived", this.eL);
            this.L.listen("channelOpened", function() {
                x6E(X)
            });
            this.L.listen("channelClosed", function() {
                Jo("Channel closed");
                isNaN(X.K) ? pg(!0) : pg();
                X.dispose()
            });
            this.L.listen("channelError", function(U) {
                pg();
                isNaN(X.QF()) ? (U == 1 && X.Cu == "shortLived" && X.publish("browserChannelAuthError", U), Jo("Channel error: " + U + " without reconnection"), X.dispose()) : (X.ys = !0, Jo("Channel error: " + U + " with reconnection in " + X.QF() + " ms"), rX(X, 2))
            });
            this.L.listen("channelMessage", function(U) {
                Od4(X, U)
            });
            this.L.T2(M.token);
            this.subscribe("remoteQueueChange", function() {
                var U = X.B.videoId;
                g.L0() && g.Tg("yt-remote-session-video-id", U)
            })
        },
        a8V = function(w) {
            return g.Nj(w.C, function(M) {
                return M.type == "LOUNGE_SCREEN"
            })
        },
        Jo = function(w) {
            MA("conn", w)
        },
        rX = function(w, M) {
            w.publish("proxyStateChange", M)
        },
        wlA = function(w) {
            w.K = g.cF(function() {
                Jo("Connecting timeout");
                w.FT(1)
            }, 2E4)
        },
        ix3 = function(w) {
            g.S9(w.K);
            w.K = NaN
        },
        MWE = function(w) {
            g.S9(w.mN);
            w.mN = NaN
        },
        ubx = function(w) {
            P5h(w);
            w.Lu = g.cF(function() {
                Cu(w, "getNowPlaying")
            }, 2E4)
        },
        P5h = function(w) {
            g.S9(w.Lu);
            w.Lu = NaN
        },
        x6E = function(w) {
            Jo("Channel opened");
            w.ys && (w.ys = !1, MWE(w), w.mN = g.cF(function() {
                Jo("Timing out waiting for a screen.");
                w.FT(1)
            }, 15E3))
        },
        $W4 = function(w, M) {
            var P = null;
            if (M) {
                var u = a8V(w);
                u && (P = {
                    clientName: u.clientName,
                    deviceMake: u.brand,
                    deviceModel: u.model,
                    osVersion: u.osVersion
                })
            }
            g.ih("yt.mdx.remote.remoteClient_", P);
            M && (ix3(w), MWE(w));
            P = w.L.gC() && isNaN(w.K);
            M == P ? M && (rX(w, 1), Cu(w, "getSubtitlesTrack")) : M ? (w.rX() && w.B.reset(), rX(w, 1), Cu(w, "getNowPlaying"), XlE(w)) : w.FT(1)
        },
        UWE = function(w, M) {
            var P = M.params.videoId;
            delete M.params.videoId;
            P == w.B.videoId && (g.SF(M.params) ? w.B.trackData = null : w.B.trackData = M.params, w.publish("remotePlayerChange"))
        },
        f2t = function(w, M, P) {
            var u = M.params.videoId || M.params.video_id,
                X = parseInt(M.params.currentIndex, 10);
            w.B.listId = M.params.listId || w.B.listId;
            Rc(w.B, u, X);
            w.publish("remoteQueueChange", P)
        },
        h1h = function(w, M) {
            M.params = M.params || {};
            f2t(w, M, "NOW_PLAYING_MAY_CHANGE");
            WS$(w, M);
            w.publish("autoplayDismissed")
        },
        WS$ = function(w, M) {
            var P = parseInt(M.params.currentTime || M.params.current_time, 10);
            Q9(w.B, isNaN(P) ? 0 : P);
            P = parseInt(M.params.state, 10);
            P = isNaN(P) ? -1 : P;
            P == -1 && w.B.playerState == -1E3 && (P = -1E3);
            w.B.playerState = P;
            P = Number(M.params.loadedTime);
            w.B.V = isNaN(P) ? 0 : P;
            w.B.l4(Number(M.params.duration));
            P = w.B;
            var u = Number(M.params.liveIngestionTime);
            P.B = u;
            P.X = isNaN(u) ? !1 : !0;
            P = w.B;
            u = Number(M.params.seekableStartTime);
            M = Number(M.params.seekableEndTime);
            P.L = isNaN(u) ? 0 : u;
            P.j = isNaN(M) ? 0 : M;
            w.B.playerState == 1 ? ubx(w) : P5h(w);
            w.publish("remotePlayerChange")
        },
        crE = function(w, M) {
            if (w.B.playerState != -1E3) {
                var P =
                    1085;
                switch (parseInt(M.params.adState, 10)) {
                    case 1:
                        P = 1081;
                        break;
                    case 2:
                        P = 1084;
                        break;
                    case 0:
                        P = 1083
                }
                w.B.playerState = P;
                M = parseInt(M.params.currentTime, 10);
                Q9(w.B, isNaN(M) ? 0 : M);
                w.publish("remotePlayerChange")
            }
        },
        Zxt = function(w, M) {
            var P = M.params.muted == "true";
            w.B.volume = parseInt(M.params.volume, 10);
            w.B.muted = P;
            w.publish("remotePlayerChange")
        },
        SXE = function(w, M) {
            w.j = M.params.videoId;
            w.publish("nowAutoplaying", parseInt(M.params.timeout, 10))
        },
        Hx3 = function(w, M) {
            w.j = M.params.videoId || null;
            w.publish("autoplayUpNext", w.j)
        },
        plj = function(w, M) {
            w.G = M.params.autoplayMode;
            w.publish("autoplayModeChange", w.G);
            w.G == "DISABLED" && w.publish("autoplayDismissed")
        },
        FSV = function(w, M) {
            var P = M.params.hasNext == "true";
            w.B.ST = M.params.hasPrevious == "true";
            w.B.kH = P;
            w.publish("previousNextChange")
        },
        Od4 = function(w, M) {
            M = M.message;
            M.params ? Jo("Received: action=" + M.action + ", params=" + g.ny(M.params)) : Jo("Received: action=" + M.action + " {}");
            switch (M.action) {
                case "loungeStatus":
                    M = Pr(M.params.devices);
                    w.C = g.EV(M, function(u) {
                        return new fg(u)
                    });
                    M = !!g.Nj(w.C, function(u) {
                        return u.type == "LOUNGE_SCREEN"
                    });
                    $W4(w, M);
                    M = w.If("mlm");
                    w.publish("multiStateLoopEnabled", M);
                    break;
                case "loungeScreenDisconnected":
                    g.Tc(w.C, function(u) {
                        return u.type == "LOUNGE_SCREEN"
                    });
                    $W4(w, !1);
                    break;
                case "remoteConnected":
                    var P = new fg(Pr(M.params.device));
                    g.Nj(w.C, function(u) {
                        return u.equals(P)
                    }) || EhA(w.C, P);
                    break;
                case "remoteDisconnected":
                    P = new fg(Pr(M.params.device));
                    g.Tc(w.C, function(u) {
                        return u.equals(P)
                    });
                    break;
                case "gracefulDisconnect":
                    break;
                case "playlistModified":
                    f2t(w, M, "QUEUE_MODIFIED");
                    break;
                case "nowPlaying":
                    h1h(w, M);
                    break;
                case "onStateChange":
                    WS$(w, M);
                    break;
                case "onAdStateChange":
                    crE(w, M);
                    break;
                case "onVolumeChanged":
                    Zxt(w, M);
                    break;
                case "onSubtitlesTrackChanged":
                    UWE(w, M);
                    break;
                case "nowAutoplaying":
                    SXE(w, M);
                    break;
                case "autoplayDismissed":
                    w.publish("autoplayDismissed");
                    break;
                case "autoplayUpNext":
                    Hx3(w, M);
                    break;
                case "onAutoplayModeChanged":
                    plj(w, M);
                    break;
                case "onHasPreviousNextChanged":
                    FSV(w,
                        M);
                    break;
                case "requestAssistedSignIn":
                    w.publish("assistedSignInRequested", M.params.authCode);
                    break;
                case "onLoopModeChanged":
                    w.publish("loopModeChange", M.params.loopMode);
                    break;
                default:
                    Jo("Unrecognized action: " + M.action)
            }
        },
        XlE = function(w) {
            g.S9(w.S);
            w.S = g.cF(function() {
                w.FT(1)
            }, 864E5)
        },
        Cu = function(w, M, P) {
            P ? Jo("Sending: action=" + M + ", params=" + g.ny(P)) : Jo("Sending: action=" + M);
            w.L.sendMessage(M, P)
        },
        EB$ = function(w) {
            U9.call(this, "ScreenServiceProxy");
            this.XJ = w;
            this.B = [];
            this.B.push(this.XJ.$_s("screenChange", (0, g.fC)(this.QR, this)));
            this.B.push(this.XJ.$_s("onlineScreenChange", (0, g.fC)(this.x7u, this)))
        },
        GJj = function(w, M) {
            ESt();
            if (!FA || !FA.get("yt-remote-disable-remote-module-for-dev")) {
                M = g.AR("MDX_CONFIG") || M;
                fKj();
                ZBt();
                to || (to = new aM(M ? M.loungeApiHost : void 0), N$E() && (to.B = "/api/loungedev"));
                x_ || (x_ = g.Mj("yt.mdx.remote.deferredProxies_") || [], g.ih("yt.mdx.remote.deferredProxies_", x_));
                NGE();
                var P = O9();
                if (!P) {
                    var u = new Zu(to, M ? M.disableAutomaticScreenCache || !1 : !1);
                    g.ih("yt.mdx.remote.screenService_", u);
                    P = O9();
                    var X = {};
                    M && (X = {
                        appId: M.appId,
                        disableDial: M.disableDial,
                        theme: M.theme,
                        loadCastApiSetupScript: M.loadCastApiSetupScript,
                        disableCastApi: M.disableCastApi,
                        enableDialLoungeToken: M.enableDialLoungeToken,
                        enableCastLoungeToken: M.enableCastLoungeToken,
                        forceMirroring: M.forceMirroring
                    });
                    g.ih("yt.mdx.remote.enableConnectWithInitialState_", M ? M.enableConnectWithInitialState || !1 : !1);
                    ksj(w, u, function(U) {
                        U ? ac() && Lu(ac(), "YouTube TV") : u.subscribe("onlineScreenChange", function() {
                            Ej("yt-remote-receiver-availability-change")
                        })
                    }, X)
                }
                M && !g.Mj("yt.mdx.remote.initialized_") && (g.ih("yt.mdx.remote.initialized_", !0), wJ("Initializing: " + g.ny(M)),
                    iS.push(g.ti("yt-remote-cast2-api-ready", function() {
                        Ej("yt-remote-api-ready")
                    })), iS.push(g.ti("yt-remote-cast2-availability-change", function() {
                        Ej("yt-remote-receiver-availability-change")
                    })), iS.push(g.ti("yt-remote-cast2-receiver-selected", function() {
                        Mw(null);
                        Ej("yt-remote-auto-connect", "cast-selector-receiver")
                    })), iS.push(g.ti("yt-remote-cast2-receiver-resumed", function() {
                        Ej("yt-remote-receiver-resumed", "cast-selector-receiver")
                    })), iS.push(g.ti("yt-remote-cast2-session-change", VWh)), iS.push(g.ti("yt-remote-connection-change", function(U) {
                        U ? Lu(ac(), "YouTube TV") : PB() || (Lu(null, null), sXE())
                    })), iS.push(g.ti("yt-remote-cast2-session-failed", function() {
                        Ej("yt-remote-connection-failed")
                    })), w = mWt(), M.isAuto && (w.id += "#dial"), X = M.capabilities || [], X.length > 0 && (w.capabilities =
                        X), w.name = M.device, w.app = M.app, (M = M.theme) && (w.theme = M), wJ(" -- with channel params: " + g.ny(w)), w ? (g.Tg("yt-remote-session-app", w.app), g.Tg("yt-remote-session-name", w.name)) : (g.lK("yt-remote-session-app"), g.lK("yt-remote-session-name")), g.ih("yt.mdx.remote.channelParams_", w), P.start(), ac() || oB3())
            }
        },
        yrE = function() {
            var w = O9().XJ.$_gos();
            var M = uS();
            M && XC() && (Uxt(w, M) || w.push(M));
            return $xE(w)
        },
        qXU = function() {
            var w = DWc();
            !w && dX() && vQ$() && (w = {
                key: "cast-selector-receiver",
                name: vQ$()
            });
            return w
        },
        DWc = function() {
            var w = yrE(),
                M = uS();
            M || (M = PB());
            return g.Nj(w, function(P) {
                return M && h6(M, P.key) ? !0 : !1
            })
        },
        uS = function() {
            var w = ac();
            if (!w) return null;
            var M = O9().dG();
            return ZJ(M, w)
        },
        VWh = function(w) {
            wJ("remote.onCastSessionChange_: " + cr(w));
            if (w) {
                var M = uS();
                if (M && M.id == w.id) {
                    if (Lu(M.id, "YouTube TV"), w.idType == "shortLived" && (w = w.token)) $o && ($o.token = w), (M = XC()) && M.T2(w)
                } else M && Ul(), f1(w, 1)
            } else XC() && Ul()
        },
        Ul = function() {
            l7() ? T7().stopSession() : z7("stopSession called before API ready.");
            var w = XC();
            w && (w.disconnect(1), YXA(null))
        },
        z1C = function() {
            var w = XC();
            return !!w && w.getProxyState() != 3
        },
        wJ = function(w) {
            MA("remote", w)
        },
        O9 = function() {
            if (!TGE) {
                var w = g.Mj("yt.mdx.remote.screenService_");
                TGE = w ? new EB$(w) : null
            }
            return TGE
        },
        ac = function() {
            return g.Mj("yt.mdx.remote.currentScreenId_")
        },
        dWA = function(w) {
            g.ih("yt.mdx.remote.currentScreenId_", w)
        },
        l2t = function() {
            return g.Mj("yt.mdx.remote.connectData_")
        },
        Mw = function(w) {
            g.ih("yt.mdx.remote.connectData_", w)
        },
        XC = function() {
            return g.Mj("yt.mdx.remote.connection_")
        },
        YXA = function(w) {
            var M = XC();
            Mw(null);
            w || dWA("");
            g.ih("yt.mdx.remote.connection_", w);
            x_ && (g.tx(x_, function(P) {
                P(w)
            }), x_.length = 0);
            M && !w ? Ej("yt-remote-connection-change", !1) : !M && w && Ej("yt-remote-connection-change", !0)
        },
        PB = function() {
            var w = g.L0();
            if (!w) return null;
            var M = O9();
            if (!M) return null;
            M = M.dG();
            return ZJ(M, w)
        },
        f1 = function(w, M) {
            ac();
            uS() && uS();
            if (WB) $o = w;
            else {
                dWA(w.id);
                var P = g.Mj("yt.mdx.remote.enableConnectWithInitialState_") || !1;
                w = new j_(to, w, mWt(), P);
                w.connect(M, l2t());
                w.subscribe("beforeDisconnect", function(u) {
                    Ej("yt-remote-before-disconnect", u)
                });
                w.subscribe("beforeDispose", function() {
                    XC() && (XC(), YXA(null))
                });
                w.subscribe("browserChannelAuthError", function() {
                    var u = uS();
                    u && u.idType == "shortLived" && (l7() ? T7().handleBrowserChannelAuthError() : z7("refreshLoungeToken called before API ready."))
                });
                YXA(w)
            }
        },
        oB3 = function() {
            var w = PB();
            w ? (wJ("Resume connection to: " + cr(w)), f1(w, 0)) : (pg(), sXE(), wJ("Skipping connecting because no session screen found."))
        },
        NGE = function() {
            var w = mWt();
            if (g.SF(w)) {
                w = Hr();
                var M = g.dH("yt-remote-session-name") || "",
                    P = g.dH("yt-remote-session-app") || "";
                w = {
                    device: "REMOTE_CONTROL",
                    id: w,
                    name: M,
                    app: P,
                    mdxVersion: 3
                };
                w.authuser = String(g.AR("SESSION_INDEX", "0"));
                (M = g.AR("DELEGATED_SESSION_ID")) && (w.pageId = String(M));
                g.ih("yt.mdx.remote.channelParams_", w)
            }
        },
        mWt = function() {
            return g.Mj("yt.mdx.remote.channelParams_") || {}
        },
        BGA = function(w, M, P) {
            g.v.call(this);
            var u = this;
            this.B = w;
            this.U = M;
            this.Hj = P;
            this.events = new g.V2(this);
            this.G = !1;
            this.K = new g.EH(64);
            this.L = new g.gV(this.eC, 500, this);
            this.C = new g.gV(this.GM, 1E3, this);
            this.V = new mN(this.nDs, 0, this);
            this.X = {};
            this.S = new g.gV(this.Dd, 1E3, this);
            this.j = new g.Cb(this.seekTo, 1E3, this);
            this.B3 = this.events.Y(this.U, "onVolumeChange", function(X) {
                LS4(u, X)
            });
            g.b(this, this.events);
            this.events.Y(M, "onCaptionsTrackListChanged", this.RiL);
            this.events.Y(M, "captionschanged", this.a3O);
            this.events.Y(M, "captionssettingschanged", this.t8);
            this.events.Y(M, "videoplayerreset", this.LY);
            this.events.Y(M, "mdxautoplaycancel", function() {
                u.Hj.Ux()
            });
            M.D("enable_mdx_video_play_directly") && this.events.Y(M, "videodatachange", function() {
                e1$(u.B) || hj(u) || cB(u, 0)
            });
            w = this.Hj;
            w.sO();
            w.subscribe("proxyStateChange", this.iL, this);
            w.subscribe("remotePlayerChange", this.fC, this);
            w.subscribe("remoteQueueChange", this.LY, this);
            w.subscribe("previousNextChange", this.td, this);
            w.subscribe("nowAutoplaying", this.gQ, this);
            w.subscribe("autoplayDismissed", this.yf, this);
            g.b(this, this.L);
            g.b(this, this.C);
            g.b(this, this.V);
            g.b(this, this.S);
            g.b(this, this.j);
            this.t8();
            this.LY();
            this.fC()
        },
        LS4 = function(w, M) {
            if (hj(w)) {
                w.Hj.unsubscribe("remotePlayerChange", w.fC, w);
                var P = Math.round(M.volume);
                M = !!M.muted;
                var u = s9(w.Hj);
                if (P !== u.volume || M !== u.muted) w.Hj.setVolume(P, M), w.S.start();
                w.Hj.subscribe("remotePlayerChange", w.fC, w)
            }
        },
        QEE = function(w) {
            w.Ub(0);
            w.L.stop();
            w.Pk(new g.EH(64))
        },
        kJj = function(w, M) {
            if (hj(w) && !w.G) {
                var P = null;
                M && (P = {
                    style: w.U.getSubtitlesUserSettings()
                }, Object.assign(P, M));
                w.Hj.SJ(w.U.getVideoData(1).videoId, P);
                w.X = s9(w.Hj).trackData
            }
        },
        cB = function(w, M) {
            var P = w.U.getPlaylist();
            if (P == null ? 0 : P.listId) {
                var u = P.index;
                var X = P.listId.toString()
            }
            P = w.U.getVideoData(1);
            w.Hj.playVideo(P.videoId, M, u, X, P.playerParams, P.UO, Fbc(P));
            w.Pk(new g.EH(1))
        },
        R1a = function(w, M) {
            if (M) {
                var P = w.U.getOption("captions", "tracklist", {
                    bS: 1
                });
                P && P.length ? (w.U.setOption("captions", "track", M), w.G = !1) : (w.U.loadModule("captions"), w.G = !0)
            } else w.U.setOption("captions", "track", {})
        },
        hj = function(w) {
            return s9(w.Hj).videoId === w.U.getVideoData(1).videoId
        },
        nB$ = function(w, M) {
            g.Al.call(this, w);
            this.B = M
        },
        ZL = function() {
            g.r.call(this, {
                W: "div",
                T: "ytp-mdx-popup-dialog",
                Z: {
                    role: "dialog"
                },
                J: [{
                    W: "div",
                    T: "ytp-mdx-popup-dialog-inner-content",
                    J: [{
                        W: "div",
                        T: "ytp-mdx-popup-title",
                        pu: "You're signed out"
                    }, {
                        W: "div",
                        T: "ytp-mdx-popup-description",
                        pu: "Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer."
                    }, {
                        W: "div",
                        T: "ytp-mdx-privacy-popup-buttons",
                        J: [{
                            W: "button",
                            d$: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                            pu: "Cancel"
                        }, {
                            W: "button",
                            d$: ["ytp-button",
                                "ytp-mdx-privacy-popup-confirm"
                            ],
                            pu: "Confirm"
                        }]
                    }]
                }]
            });
            this.fade = new g.Cf(this, 250);
            this.cancelButton = this.RI("ytp-mdx-privacy-popup-cancel");
            this.confirmButton = this.RI("ytp-mdx-privacy-popup-confirm");
            g.b(this, this.fade);
            this.Y(this.cancelButton, "click", this.B);
            this.Y(this.confirmButton, "click", this.L)
        },
        S$ = function(w) {
            g.r.call(this, {
                W: "div",
                T: "ytp-remote",
                J: [{
                    W: "div",
                    T: "ytp-remote-display-status",
                    J: [{
                        W: "div",
                        T: "ytp-remote-display-status-icon",
                        J: [g.cSM()]
                    }, {
                        W: "div",
                        T: "ytp-remote-display-status-text",
                        pu: "{{statustext}}"
                    }]
                }]
            });
            this.api = w;
            this.fade = new g.Cf(this, 250);
            g.b(this, this.fade);
            this.Y(w, "presentingplayerstatechange", this.onStateChange);
            this.g7(w.getPlayerStateObject())
        },
        HB = function(w, M) {
            g.v6.call(this, "Play on", 1, w, M);
            this.U = w;
            this.g0 = {};
            this.Y(w, "onMdxReceiversChange", this.X);
            this.Y(w, "presentingplayerstatechange", this.X);
            this.X()
        },
        vBV = function(w) {
            g.D0.call(this, w);
            this.yJ = {
                key: XFC(),
                name: "This computer"
            };
            this.Px = null;
            this.subscriptions = [];
            this.A$ = this.Hj = null;
            this.g0 = [this.yJ];
            this.KH = this.yJ;
            this.zt = new g.EH(64);
            this.yM = 0;
            this.yO = -1;
            this.Fn = !1;
            this.Wb = this.KC = this.RL = null;
            if (!g.jY(this.player.N()) && !g.LW(this.player.N())) {
                w = this.player;
                var M = g.y1(w);
                M && (M = M.CN()) && (M = new HB(w, M), g.b(this, M));
                M = new S$(w);
                g.b(this, M);
                g.bD(w, M.element, 4);
                this.RL = new ZL;
                g.b(this, this.RL);
                g.bD(w, this.RL.element, 4);
                this.Fn = !!PB()
            }
        },
        p1 = function(w) {
            w.KC && (w.player.removeEventListener("presentingplayerstatechange",
                w.KC), w.KC = null)
        },
        sEa = function(w, M, P) {
            w.zt = P;
            w.player.publish("presentingplayerstatechange", new g.$9(P, M))
        },
        FC = function(w, M) {
            if (M.key !== w.KH.key)
                if (M.key === w.yJ.key) Ul();
                else if (e1$(w) && KS4(w), w.KH = M, !w.player.N().D("disable_mdx_connection_in_mdx_module_for_music_web") || !g.LW(w.player.N())) {
                var P = w.player.getPlaylistId();
                var u = w.player.getVideoData(1);
                var X = u.videoId;
                if (!P && !X || (w.player.getAppState() === 2 || w.player.getAppState() === 1) && w.player.N().D("should_clear_video_data_on_player_cued_unstarted")) u = null;
                else {
                    var U = w.player.getPlaylist();
                    if (U) {
                        var f = [];
                        for (var h = 0; h < U.length; h++) f[h] = g.o5(U, h).videoId
                    } else f = [X];
                    U = w.player.getCurrentTime(1);
                    w = {
                        videoIds: f,
                        listId: P,
                        videoId: X,
                        playerParams: u.playerParams,
                        clickTrackingParams: u.UO,
                        index: Math.max(w.player.getPlaylistIndex(), 0),
                        currentTime: U === 0 ? void 0 : U
                    };
                    (u = Fbc(u)) && (w.locationInfo = u);
                    u = w
                }
                wJ("Connecting to: " + g.ny(M));
                M.key == "cast-selector-receiver" ? (Mw(u || null), M = u || null, l7() ? T7().setLaunchParams(M) : z7("setLaunchParams called before ready.")) : !u && z1C() && ac() == M.key ? Ej("yt-remote-connection-change", !0) : (Ul(), Mw(u || null), u = O9().dG(), (M = ZJ(u, M.key)) && f1(M, 1))
            }
        },
        e1$ = function(w) {
            var M = w.player.N();
            return !M.D("mdx_enable_privacy_disclosure_ui") || w.isLoggedIn() || w.Fn || !w.RL ? !1 : g.fp(M) || g.c0(M)
        },
        KS4 = function(w) {
            w.player.getPlayerStateObject().isPlaying() ? w.player.pauseVideo() : (w.KC = function(M) {
                !w.Fn && g.fW(M, 8) && (w.player.pauseVideo(), p1(w))
            }, w.player.addEventListener("presentingplayerstatechange", w.KC));
            w.RL && w.RL.w7();
            XC() || (WB = !0)
        };
    g.BV.prototype.Y5 = g.Xl(49, function() {
        this.app.sG().Y5()
    });
    g.tl.prototype.Y5 = g.Xl(48, function() {
        this.Wb = null
    });
    g.BV.prototype.mY = g.Xl(47, function(w) {
        this.app.sG().mY(w)
    });
    g.tl.prototype.mY = g.Xl(46, function(w) {
        this.Wb = w
    });
    ohc.prototype.lC = function(w) {
        this.B.qz("/client_streamz/youtube/living_room/mdx/channel/opened", w)
    };
    GXp.prototype.lC = function(w) {
        this.B.qz("/client_streamz/youtube/living_room/mdx/channel/closed", w)
    };
    yR4.prototype.lC = function(w) {
        this.B.qz("/client_streamz/youtube/living_room/mdx/channel/message_received", w)
    };
    DTV.prototype.lC = function() {
        this.B.qz("/client_streamz/youtube/living_room/mdx/channel/success")
    };
    qKE.prototype.lC = function(w, M) {
        this.B.qz("/client_streamz/youtube/living_room/mdx/channel/error", w, M)
    };
    YKt.prototype.lC = function() {
        this.B.qz("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
    };
    z$U.prototype.lC = function() {
        this.B.qz("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
    };
    g.N = $b.prototype;
    g.N.yX = function() {
        Uj(this);
        for (var w = [], M = 0; M < this.B.length; M++) w.push(this.L[this.B[M]]);
        return w
    };
    g.N.oN = function() {
        Uj(this);
        return this.B.concat()
    };
    g.N.has = function(w) {
        return XA(this.L, w)
    };
    g.N.equals = function(w, M) {
        if (this === w) return !0;
        if (this.size != w.size) return !1;
        M = M || lYE;
        Uj(this);
        for (var P, u = 0; P = this.B[u]; u++)
            if (!M(this.get(P), w.get(P))) return !1;
        return !0
    };
    g.N.isEmpty = function() {
        return this.size == 0
    };
    g.N.clear = function() {
        this.L = {};
        this.LK = this.size = this.B.length = 0
    };
    g.N.remove = function(w) {
        return this.delete(w)
    };
    g.N.delete = function(w) {
        return XA(this.L, w) ? (delete this.L[w], --this.size, this.LK++, this.B.length > 2 * this.size && Uj(this), !0) : !1
    };
    g.N.get = function(w, M) {
        return XA(this.L, w) ? this.L[w] : M
    };
    g.N.set = function(w, M) {
        XA(this.L, w) || (this.size += 1, this.B.push(w), this.LK++);
        this.L[w] = M
    };
    g.N.forEach = function(w, M) {
        for (var P = this.oN(), u = 0; u < P.length; u++) {
            var X = P[u],
                U = this.get(X);
            w.call(M, U, X, this)
        }
    };
    g.N.clone = function() {
        return new $b(this)
    };
    g.N.keys = function() {
        return g.p_(this.Sx(!0)).B()
    };
    g.N.values = function() {
        return g.p_(this.Sx(!1)).B()
    };
    g.N.entries = function() {
        var w = this;
        return dTh(this.keys(), function(M) {
            return [M, w.get(M)]
        })
    };
    g.N.Sx = function(w) {
        Uj(this);
        var M = 0,
            P = this.LK,
            u = this,
            X = new g.Vl;
        X.next = function() {
            if (P != u.LK) throw Error("The map has changed since the iterator was created");
            if (M >= u.B.length) return g.S4;
            var U = u.B[M++];
            return g.m8(w ? U : u.L[U])
        };
        return X
    };
    var Qgj = {
            pb$: "atp",
            u_u: "ska",
            f8I: "que",
            MxN: "mus",
            jB9: "sus",
            o6O: "dsp",
            Ugu: "seq",
            LA3: "mic",
            Bg$: "dpa",
            ryI: "mlm",
            PII: "dsdtr",
            k19: "ntb",
            xru: "vsp",
            WQ3: "scn",
            LP3: "rpe",
            qzK: "dcn",
            J5k: "dcp",
            txs: "pas",
            cF3: "drq",
            Dz3: "opf",
            X_N: "els",
            yF3: "isg",
            xg3: "svq",
            CTO: "mvp",
            Rh$: "ads",
            ooW: "stcp",
            DgI: "sads",
            Sz$: "dloc",
            IvK: "dcw",
            CXK: "asw",
            rVO: "apw"
        },
        kXa = {
            kLI: "u",
            GJ0: "cl",
            TkO: "k",
            ve0: "i",
            iiW: "cr",
            yyW: "m",
            av3: "g",
            MF: "up"
        },
        mZc = {
            Ja: "adPlaying",
            c$: "onAdStateChange"
        },
        o1t = {
            xz$: "nowPlaying",
            O$0: "onStateChange",
            Ja: "adPlaying",
            c$: "onAdStateChange",
            JT: "nowPlayingShorts",
            P$: "onShortsStateChange"
        },
        G$t = {
            JT: "nowPlayingShorts",
            P$: "onShortsStateChange"
        };
    fg.prototype.equals = function(w) {
        return w ? this.id == w.id : !1
    };
    var cDE = "",
        FA = null;
    g.V(V9x, g.Bj);
    var Ny, zW4 = oSE("loadCastFramework") || oSE("loadCastApplicationFramework"),
        lK3 = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    g.Sp(mN, g.v);
    g.N = mN.prototype;
    g.N.Ih = function(w) {
        this.X = arguments;
        this.B = !1;
        this.jZ ? this.C = g.ca() + this.Hb : this.jZ = g.BX(this.G, this.Hb)
    };
    g.N.stop = function() {
        this.jZ && (g.aF.clearTimeout(this.jZ), this.jZ = null);
        this.C = null;
        this.B = !1;
        this.X = []
    };
    g.N.pause = function() {
        ++this.L
    };
    g.N.resume = function() {
        this.L && (--this.L, !this.L && this.B && (this.B = !1, this.K.apply(null, this.X)))
    };
    g.N.v3 = function() {
        this.stop();
        mN.Ik.v3.call(this)
    };
    g.N.vE = function() {
        this.jZ && (g.aF.clearTimeout(this.jZ), this.jZ = null);
        this.C ? (this.jZ = g.BX(this.G, this.C - g.ca()), this.C = null) : this.L ? this.B = !0 : (this.B = !1, this.K.apply(null, this.X))
    };
    oM.prototype.stringify = function(w) {
        return g.aF.JSON.stringify(w, void 0)
    };
    oM.prototype.parse = function(w) {
        return g.aF.JSON.parse(w, void 0)
    };
    g.Sp(eWE, g.Iu);
    g.Sp(B$h, g.Iu);
    var Q1E = null;
    g.Sp(RW3, g.Iu);
    g.Sp(nS3, g.Iu);
    g.Sp(vSC, g.Iu);
    qy.prototype.debug = function() {};
    qy.prototype.info = function() {};
    qy.prototype.warning = function() {};
    var rDa = {},
        JDp = {};
    g.N = Yb.prototype;
    g.N.setTimeout = function(w) {
        this.iW = w
    };
    g.N.m1 = function(w) {
        w = w.target;
        var M = this.t9;
        M && g.An(w) == 3 ? M.Up() : this.O4(w)
    };
    g.N.O4 = function(w) {
        try {
            if (w == this.B) a: {
                var M = g.An(this.B),
                    P = this.B.L,
                    u = this.B.getStatus();
                if (!(M < 3) && (M != 3 || this.B && (this.L.L || g.Jn(this.B) || g.rb(this.B)))) {
                    this.xu || M != 4 || P == 7 || (P == 8 || u <= 0 ? GA(3) : GA(2));
                    t9E(this);
                    var X = this.B.getStatus();
                    this.cj = X;
                    var U = gSE(this);
                    if (this.K = X == 200) {
                        if (this.fg && !this.OO) {
                            b: {
                                if (this.B) {
                                    var f = g.j7(this.B, "X-HTTP-Initial-Response");
                                    if (f && !g.lA(f)) {
                                        var h = f;
                                        break b
                                    }
                                }
                                h = null
                            }
                            if (w = h) this.OO = !0,
                            Xn$(this, w);
                            else {
                                this.K = !1;
                                this.G = 3;
                                yv(12);
                                TA(this);
                                dF(this);
                                break a
                            }
                        }
                        if (this.Cu) {
                            w = !0;
                            for (var c; !this.xu && this.j < U.length;)
                                if (c = j1x(this, U), c == JDp) {
                                    M == 4 && (this.G = 4, yv(14), w = !1);
                                    break
                                } else if (c == rDa) {
                                this.G = 4;
                                yv(15);
                                w = !1;
                                break
                            } else Xn$(this, c);
                            AD$(this) && this.j != 0 && (this.L.B = this.L.B.slice(this.j), this.j = 0);
                            M != 4 || U.length != 0 || this.L.L || (this.G = 1, yv(16), w = !1);
                            this.K = this.K && w;
                            w ? U.length > 0 && !this.M7 && (this.M7 = !0, this.C.fF(this)) : (TA(this), dF(this))
                        } else Xn$(this, U);
                        M == 4 && TA(this);
                        this.K && !this.xu && (M == 4 ? xxt(this.C, this) : (this.K = !1, zA(this)))
                    } else g.o61(this.B), X == 400 && U.indexOf("Unknown SID") >
                        0 ? (this.G = 3, yv(12)) : (this.G = 0, yv(13)), TA(this), dF(this)
                }
            }
        } catch (Z) {} finally {}
    };
    g.N.cancel = function() {
        this.xu = !0;
        TA(this)
    };
    g.N.Ei = function() {
        this.B3 = null;
        var w = Date.now();
        w - this.Z3 >= 0 ? (this.eL != 2 && (GA(3), yv(17)), TA(this), this.G = 2, dF(this)) : CLj(this, this.Z3 - w)
    };
    g.N.getLastError = function() {
        return this.G
    };
    g.N.ma = function() {
        return this.B
    };
    UiE.prototype.cancel = function() {
        this.C = Wua(this);
        if (this.L) this.L.cancel(), this.L = null;
        else if (this.B && this.B.size !== 0) {
            for (var w = g.G(this.B.values()), M = w.next(); !M.done; M = w.next()) M.value.cancel();
            this.B.clear()
        }
    };
    g.N = H0x.prototype;
    g.N.g_ = 8;
    g.N.AV = 1;
    g.N.connect = function(w, M, P, u) {
        yv(0);
        this.GE = w;
        this.xu = M || {};
        P && u !== void 0 && (this.xu.OSID = P, this.xu.OAID = u);
        this.OO = this.QE;
        this.UO = Mh$(this, null, this.GE);
        Br(this)
    };
    g.N.disconnect = function() {
        FuA(this);
        if (this.AV == 3) {
            var w = this.Yu++,
                M = this.UO.clone();
            g.WG(M, "SID", this.X);
            g.WG(M, "RID", w);
            g.WG(M, "TYPE", "terminate");
            RM(this, M);
            w = new Yb(this, this.X, w);
            w.eL = 2;
            w.V = i4(M.clone());
            M = !1;
            if (g.aF.navigator && g.aF.navigator.sendBeacon) try {
                M = g.aF.navigator.sendBeacon(w.V.toString(), "")
            } catch (P) {}!M && g.aF.Image && ((new Image).src = w.V, M = !0);
            M || (w.B = IKV(w.C, null), w.B.send(w.V));
            w.mN = Date.now();
            zA(w)
        }
        GgA(this)
    };
    g.N.bF = function() {
        return this.AV == 0
    };
    g.N.getState = function() {
        return this.AV
    };
    g.N.Q4 = function(w) {
        if (this.K)
            if (this.K = null, this.AV == 1) {
                if (!w) {
                    this.Yu = Math.floor(Math.random() * 1E5);
                    w = this.Yu++;
                    var M = new Yb(this, "", w),
                        P = this.S;
                    this.cj && (P ? (P = g.Fm(P), g.NK(P, this.cj)) : P = this.cj);
                    this.j !== null || this.Z3 || (M.UO = P, P = null);
                    var u;
                    if (this.bW) a: {
                        for (var X = u = 0; X < this.C.length; X++) {
                            b: {
                                var U = this.C[X];
                                if ("__data__" in U.map && (U = U.map.__data__, typeof U === "string")) {
                                    U = U.length;
                                    break b
                                }
                                U = void 0
                            }
                            if (U === void 0) break;u += U;
                            if (u > 4096) {
                                u = X;
                                break a
                            }
                            if (u === 4096 || X === this.C.length - 1) {
                                u = X + 1;
                                break a
                            }
                        }
                        u =
                        1E3
                    }
                    else u = 1E3;
                    u = Vhp(this, M, u);
                    X = this.UO.clone();
                    g.WG(X, "RID", w);
                    g.WG(X, "CVER", 22);
                    this.Cu && g.WG(X, "X-HTTP-Session-Id", this.Cu);
                    RM(this, X);
                    P && (this.Z3 ? u = "headers=" + g.TL(g.bhU(P)) + "&" + u : this.j && g.Sr(X, this.j, P));
                    i0c(this.L, M);
                    this.jU && g.WG(X, "TYPE", "init");
                    this.bW ? (g.WG(X, "$req", u), g.WG(X, "SID", "null"), M.fg = !0, bBh(M, X, null)) : bBh(M, X, u);
                    this.AV = 2
                }
            } else this.AV == 3 && (w ? mi4(this, w) : this.C.length == 0 || fqE(this.L) || mi4(this))
    };
    g.N.aS = function() {
        this.V = null;
        oFa(this);
        if (this.TE && !(this.iW || this.B == null || this.sb <= 0)) {
            var w = 2 * this.sb;
            this.ys = DJ((0, g.fC)(this.guI, this), w)
        }
    };
    g.N.guI = function() {
        this.ys && (this.ys = null, this.OO = !1, this.iW = !0, yv(10), Lg(this), oFa(this))
    };
    g.N.fF = function(w) {
        this.B == w && this.TE && !this.iW && (pnh(this), this.iW = !0, yv(11))
    };
    g.N.Rh = function() {
        this.B3 != null && (this.B3 = null, Lg(this), aKp(this), yv(19))
    };
    g.N.U83 = function(w) {
        w ? yv(2) : yv(1)
    };
    g.N.isActive = function() {
        return !!this.G && this.G.isActive(this)
    };
    g.N = Dih.prototype;
    g.N.uj = function() {};
    g.N.TB = function() {};
    g.N.jJ = function() {};
    g.N.w_ = function() {};
    g.N.isActive = function() {
        return !0
    };
    g.N.rP = function() {};
    g.Sp(vr, g.WX);
    vr.prototype.open = function() {
        this.B.G = this.C;
        this.K && (this.B.eL = !0);
        this.B.connect(this.G, this.L || void 0)
    };
    vr.prototype.close = function() {
        this.B.disconnect()
    };
    vr.prototype.send = function(w) {
        var M = this.B;
        if (typeof w === "string") {
            var P = {};
            P.__data__ = w;
            w = P
        } else this.X && (P = {}, P.__data__ = g.ny(w), w = P);
        M.C.push(new $ih(M.nV++, w));
        M.AV == 3 && Br(M)
    };
    vr.prototype.v3 = function() {
        this.B.G = null;
        delete this.C;
        this.B.disconnect();
        delete this.B;
        vr.Ik.v3.call(this)
    };
    g.Sp(Ym$, eWE);
    g.Sp(zDa, B$h);
    g.Sp(ng, Dih);
    ng.prototype.uj = function() {
        this.B.dispatchEvent("m")
    };
    ng.prototype.TB = function(w) {
        this.B.dispatchEvent(new Ym$(w))
    };
    ng.prototype.jJ = function(w) {
        this.B.dispatchEvent(new zDa(w))
    };
    ng.prototype.w_ = function() {
        this.B.dispatchEvent("n")
    };
    var Kg = new g.WX;
    g.V(lqC, g.Iu);
    g.N = IM.prototype;
    g.N.E7 = null;
    g.N.SB = !1;
    g.N.ge = null;
    g.N.m2 = null;
    g.N.Tp = null;
    g.N.r3 = null;
    g.N.Qd = null;
    g.N.RT = null;
    g.N.Rj = null;
    g.N.RY = null;
    g.N.My = 0;
    g.N.c6 = null;
    g.N.C2 = null;
    g.N.mJ = null;
    g.N.jR = -1;
    g.N.P5 = !0;
    g.N.wu = !1;
    g.N.E0 = 0;
    g.N.Ep = null;
    var RDt = {},
        kgc = {};
    g.N = IM.prototype;
    g.N.setTimeout = function(w) {
        this.L = w
    };
    g.N.MU = function(w) {
        w = w.target;
        var M = this.Ep;
        M && g.An(w) == 3 ? M.Up() : this.tO(w)
    };
    g.N.tO = function(w) {
        try {
            if (w == this.RY) a: {
                var M = g.An(this.RY),
                    P = this.RY.L,
                    u = this.RY.getStatus();
                if (g.h1 && !g.KQ("420+")) {
                    if (M < 4) break a
                } else if (M < 3 || M == 3 && !g.Jn(this.RY)) break a;this.wu || M != 4 || P == 7 || (P == 8 || u <= 0 ? this.B.C1(3) : this.B.C1(2));sSE(this);
                var X = this.RY.getStatus();this.jR = X;
                var U = g.Jn(this.RY);
                if (this.SB = X == 200) {
                    M == 4 && A6(this);
                    if (this.Cu) {
                        for (w = !0; !this.wu && this.My < U.length;) {
                            var f = nFU(this, U);
                            if (f == kgc) {
                                M == 4 && (this.mJ = 4, b4(15), w = !1);
                                break
                            } else if (f == RDt) {
                                this.mJ = 4;
                                b4(16);
                                w = !1;
                                break
                            } else b0h(this,
                                f)
                        }
                        M == 4 && U.length == 0 && (this.mJ = 1, b4(17), w = !1);
                        this.SB = this.SB && w;
                        w || (A6(this), Kut(this))
                    } else b0h(this, U);
                    this.SB && !this.wu && (M == 4 ? this.B.Cw(this) : (this.SB = !1, QSh(this)))
                } else X == 400 && U.indexOf("Unknown SID") > 0 ? (this.mJ = 3, b4(13)) : (this.mJ = 0, b4(14)),
                A6(this),
                Kut(this)
            }
        } catch (h) {} finally {}
    };
    g.N.cancel = function() {
        this.wu = !0;
        A6(this)
    };
    g.N.Cv = function() {
        this.ge = null;
        var w = Date.now();
        w - this.m2 >= 0 ? (this.r3 != 2 && this.B.C1(3), A6(this), this.mJ = 2, b4(18), Kut(this)) : vFA(this, this.m2 - w)
    };
    g.N.getLastError = function() {
        return this.mJ
    };
    g.N = gF4.prototype;
    g.N.rT = null;
    g.N.qE = null;
    g.N.aM = !1;
    g.N.M_ = null;
    g.N.HI = null;
    g.N.Fk = -1;
    g.N.yQ = null;
    g.N.h4 = null;
    g.N.connect = function(w) {
        this.M_ = w;
        w = J6(this.B, null, this.M_);
        b4(3);
        Date.now();
        var M = this.B.S;
        M != null ? (this.yQ = M[0], (this.h4 = M[1]) ? (this.HI = 1, JS3(this)) : (this.HI = 2, rSE(this))) : (My(w, "MODE", "init"), this.qE = new IM(this), this.qE.E7 = this.rT, BHE(this.qE, w, !1, null, !0), this.HI = 0)
    };
    g.N.bH = function(w) {
        if (w) this.HI = 2, rSE(this);
        else {
            b4(4);
            var M = this.B;
            M.K0 = M.dw.Fk;
            t6(M, 9)
        }
        w && this.C1(2)
    };
    g.N.Ro = function(w) {
        return this.B.Ro(w)
    };
    g.N.abort = function() {
        this.qE && (this.qE.cancel(), this.qE = null);
        this.Fk = -1
    };
    g.N.bF = function() {
        return !1
    };
    g.N.lj = function(w, M) {
        this.Fk = w.jR;
        if (this.HI == 0)
            if (M) {
                try {
                    var P = this.L.parse(M)
                } catch (u) {
                    w = this.B;
                    w.K0 = this.Fk;
                    t6(w, 2);
                    return
                }
                this.yQ = P[0];
                this.h4 = P[1]
            } else w = this.B, w.K0 = this.Fk, t6(w, 2);
        else this.HI == 2 && (this.aM ? (b4(7), Date.now()) : M == "11111" ? (b4(6), this.aM = !0, Date.now(), this.Fk = 200, this.qE.cancel(), b4(12), rF(this.B, this, !0)) : (b4(8), Date.now(), this.aM = !1))
    };
    g.N.Cw = function() {
        this.Fk = this.qE.jR;
        if (this.qE.SB) this.HI == 0 ? this.h4 ? (this.HI = 1, JS3(this)) : (this.HI = 2, rSE(this)) : this.HI == 2 && (this.aM ? (b4(12), rF(this.B, this, !0)) : (b4(11), rF(this.B, this, !1)));
        else {
            this.HI == 0 ? b4(9) : this.HI == 2 && b4(10);
            var w = this.B;
            this.qE.getLastError();
            w.K0 = this.Fk;
            t6(w, 2)
        }
    };
    g.N.uG = function() {
        return this.B.uG()
    };
    g.N.isActive = function() {
        return this.B.isActive()
    };
    g.N.C1 = function(w) {
        this.B.C1(w)
    };
    g.N = jSa.prototype;
    g.N.Ay = null;
    g.N.t_ = null;
    g.N.m8 = null;
    g.N.Id = null;
    g.N.XQ = null;
    g.N.X3 = null;
    g.N.Yk = null;
    g.N.yZ = null;
    g.N.lG = 0;
    g.N.Xj = 0;
    g.N.bX = null;
    g.N.cW = null;
    g.N.kX = null;
    g.N.CK = null;
    g.N.dw = null;
    g.N.iV = null;
    g.N.T_ = -1;
    g.N.V4 = -1;
    g.N.K0 = -1;
    g.N.j8 = 0;
    g.N.Q5 = 0;
    g.N.rz = 8;
    var bxU = {
        OK: 0,
        mgK: 2,
        qQs: 4,
        e1I: 5,
        FtK: 6,
        STOP: 7,
        qD: 8,
        Rqu: 9,
        vQI: 10,
        mvs: 11,
        M03: 12
    };
    g.Sp(thA, g.Iu);
    g.Sp(xiA, g.Iu);
    g.N = jSa.prototype;
    g.N.connect = function(w, M, P, u, X) {
        b4(0);
        this.XQ = M;
        this.t_ = P || {};
        u && X !== void 0 && (this.t_.OSID = u, this.t_.OAID = X);
        this.V ? (sj((0, g.fC)(this.Sn, this, w), 100), aqV(this)) : this.Sn(w)
    };
    g.N.disconnect = function() {
        wNV(this);
        if (this.B == 3) {
            var w = this.lG++,
                M = this.X3.clone();
            g.WG(M, "SID", this.X);
            g.WG(M, "RID", w);
            g.WG(M, "TYPE", "terminate");
            Cg(this, M);
            w = new IM(this, this.X, w);
            w.r3 = 2;
            w.Qd = i4(M.clone());
            (new Image).src = w.Qd.toString();
            w.Tp = Date.now();
            QSh(w)
        }
        hNC(this)
    };
    g.N.Sn = function(w) {
        this.dw = new gF4(this);
        this.dw.rT = this.Ay;
        this.dw.L = this.G;
        this.dw.connect(w)
    };
    g.N.bF = function() {
        return this.B == 0
    };
    g.N.getState = function() {
        return this.B
    };
    g.N.ij = function(w) {
        this.cW = null;
        XNx(this, w)
    };
    g.N.n_ = function() {
        this.kX = null;
        this.Id = new IM(this, this.X, "rpc", this.j);
        this.Id.E7 = this.Ay;
        this.Id.E0 = 0;
        var w = this.Yk.clone();
        g.WG(w, "RID", "rpc");
        g.WG(w, "SID", this.X);
        g.WG(w, "CI", this.iV ? "0" : "1");
        g.WG(w, "AID", this.T_);
        Cg(this, w);
        g.WG(w, "TYPE", "xmlhttp");
        BHE(this.Id, w, !0, this.yZ, !1)
    };
    g.N.lj = function(w, M) {
        if (this.B != 0 && (this.Id == w || this.m8 == w))
            if (this.K0 = w.jR, this.m8 == w && this.B == 3)
                if (this.rz > 7) {
                    try {
                        var P = this.G.parse(M)
                    } catch (u) {
                        P = null
                    }
                    if (Array.isArray(P) && P.length == 3)
                        if (w = P, w[0] == 0) a: {
                            if (!this.kX) {
                                if (this.Id)
                                    if (this.Id.Tp + 3E3 < this.m8.Tp) jz(this), this.Id.cancel(), this.Id = null;
                                    else break a;
                                flt(this);
                                b4(19)
                            }
                        }
                    else this.V4 = w[1], 0 < this.V4 - this.T_ && w[2] < 37500 && this.iV && this.Q5 == 0 && !this.CK && (this.CK = sj((0, g.fC)(this.WE, this), 6E3));
                    else t6(this, 11)
                } else M != "y2f%" && t6(this, 11);
        else if (this.Id ==
            w && jz(this), !g.lA(M))
            for (w = this.G.parse(M), M = 0; M < w.length; M++) P = w[M], this.T_ = P[0], P = P[1], this.B == 2 ? P[0] == "c" ? (this.X = P[1], this.yZ = P[2], P = P[3], P != null ? this.rz = P : this.rz = 6, this.B = 3, this.bX && this.bX.zB(), this.Yk = J6(this, this.uG() ? this.yZ : null, this.XQ), $ZA(this)) : P[0] == "stop" && t6(this, 7) : this.B == 3 && (P[0] == "stop" ? t6(this, 7) : P[0] != "noop" && this.bX && this.bX.oS(P), this.Q5 = 0)
    };
    g.N.WE = function() {
        this.CK != null && (this.CK = null, this.Id.cancel(), this.Id = null, flt(this), b4(20))
    };
    g.N.Cw = function(w) {
        if (this.Id == w) {
            jz(this);
            this.Id = null;
            var M = 2
        } else if (this.m8 == w) this.m8 = null, M = 1;
        else return;
        this.K0 = w.jR;
        if (this.B != 0)
            if (w.SB)
                if (M == 1) {
                    M = w.Rj ? w.Rj.length : 0;
                    w = Date.now() - w.Tp;
                    var P = Kg;
                    P.dispatchEvent(new thA(P, M, w, this.j8));
                    O0x(this);
                    this.bX && this.bX.ZA(this, this.C);
                    this.C.length = 0
                } else $ZA(this);
        else {
            P = w.getLastError();
            var u;
            if (!(u = P == 3 || P == 7 || P == 0 && this.K0 > 0)) {
                if (u = M == 1) this.m8 || this.cW || this.B == 1 || this.j8 >= 2 ? u = !1 : (this.cW = sj((0, g.fC)(this.ij, this, w), UZ$(this, this.j8)), this.j8++,
                    u = !0);
                u = !(u || M == 2 && flt(this))
            }
            if (u) switch (P) {
                case 1:
                    t6(this, 5);
                    break;
                case 4:
                    t6(this, 10);
                    break;
                case 3:
                    t6(this, 6);
                    break;
                case 7:
                    t6(this, 12);
                    break;
                default:
                    t6(this, 2)
            }
        }
    };
    g.N.yR = function(w) {
        if (!g.o$(arguments, this.B)) throw Error("Unexpected channel state: " + this.B);
    };
    g.N.d89 = function(w) {
        w ? b4(2) : (b4(1), WmU(this, 8))
    };
    g.N.Ro = function(w) {
        if (w) throw Error("Can't create secondary domain capable XhrIo object.");
        w = new g.Ky;
        w.j = !1;
        return w
    };
    g.N.isActive = function() {
        return !!this.bX && this.bX.isActive(this)
    };
    g.N.C1 = function(w) {
        var M = Kg;
        M.dispatchEvent(new xiA(M, w))
    };
    g.N.uG = function() {
        return !1
    };
    g.N = chx.prototype;
    g.N.zB = function() {};
    g.N.oS = function() {};
    g.N.ZA = function() {};
    g.N.NH = function() {};
    g.N.WU = function() {};
    g.N.Hd = function() {
        return {}
    };
    g.N.isActive = function() {
        return !0
    };
    g.N = ZAE.prototype;
    g.N.enqueue = function(w) {
        this.L.push(w)
    };
    g.N.isEmpty = function() {
        return this.B.length === 0 && this.L.length === 0
    };
    g.N.clear = function() {
        this.B = [];
        this.L = []
    };
    g.N.contains = function(w) {
        return g.o$(this.B, w) || g.o$(this.L, w)
    };
    g.N.remove = function(w) {
        var M = this.B;
        var P = (0, g.rHx)(M, w);
        P >= 0 ? (g.Gc(M, P), M = !0) : M = !1;
        return M || g.D4(this.L, w)
    };
    g.N.yX = function() {
        for (var w = [], M = this.B.length - 1; M >= 0; --M) w.push(this.B[M]);
        M = this.L.length;
        for (var P = 0; P < M; ++P) w.push(this.L[P]);
        return w
    };
    g.V(SU$, g.Iu);
    g.V(HAC, g.Iu);
    g.Sp(xb, g.v);
    g.N = xb.prototype;
    g.N.fOu = function() {
        this.Hb = Math.min(3E5, this.Hb * 2);
        this.C();
        this.L && this.start()
    };
    g.N.start = function() {
        var w = this.Hb + 15E3 * Math.random();
        g.JK(this.B, w);
        this.L = Date.now() + w
    };
    g.N.stop = function() {
        this.B.stop();
        this.L = 0
    };
    g.N.isActive = function() {
        return this.B.isActive()
    };
    g.N.reset = function() {
        this.B.stop();
        this.Hb = 5E3
    };
    g.Sp(FmU, chx);
    g.N = FmU.prototype;
    g.N.subscribe = function(w, M, P) {
        return this.K.subscribe(w, M, P)
    };
    g.N.unsubscribe = function(w, M, P) {
        return this.K.unsubscribe(w, M, P)
    };
    g.N.HZ = function(w) {
        return this.K.HZ(w)
    };
    g.N.publish = function(w, M) {
        return this.K.publish.apply(this.K, arguments)
    };
    g.N.dispose = function() {
        this.j || (this.j = !0, g.wR(this.K), this.disconnect(), g.wR(this.L), this.L = null, this.Cu = function() {
            return ""
        }, this.UO = function() {
            return g.zS({})
        })
    };
    g.N.sO = function() {
        return this.j
    };
    g.N.connect = function(w, M, P) {
        var u = this,
            X, U, f, h;
        return g.n(function(c) {
            if (c.L == 1) return g.q_(c, 2), u.G ? g.B(c, u.X, 2) : c.M0(2);
            g.B5(c);
            if (u.j || u.B && u.B.getState() == 2) return c.return();
            u.mN = "";
            u.L.stop();
            u.S = w || null;
            u.V = M || 0;
            X = u.eL + "/test";
            U = u.eL + "/bind";
            f = new jSa(P ? P.firstTestResults : null, P ? P.secondTestResults : null, u.M7);
            if (h = u.B) h.bX = null;
            f.bX = u;
            u.B = f;
            if (u.G) return u.X = DZ$(u).then(function() {
                return VPp(u, X, U, h, P)
            }), c.return(u.X.then(function() {
                u.X = g.zS()
            }));
            VPp(u, X, U, h, P);
            return g.Qx(c, 0)
        })
    };
    g.N.disconnect = function(w) {
        try {
            this.G && (this.X.cancel(), this.X = g.zS())
        } finally {
            this.Lu = w || 0, this.L && this.L.stop(), E1t(this), this.B && (this.B.getState() == 3 && XNx(this.B), this.B.disconnect()), this.Lu = 0
        }
    };
    g.N.sendMessage = function(w, M) {
        var P = this,
            u;
        return g.n(function(X) {
            switch (X.L) {
                case 1:
                    g.q_(X, 2);
                    if (!P.G) {
                        X.M0(2);
                        break
                    }
                    return g.B(X, P.X, 2);
                case 2:
                    g.B5(X);
                    if (P.j) return X.return();
                    u = {
                        _sc: w
                    };
                    M && g.NK(u, M);
                    if (P.L.isActive() || (P.B ? P.B.getState() : 0) == 2) {
                        P.C.push(u);
                        X.M0(6);
                        break
                    }
                    if (!P.gC()) {
                        X.M0(6);
                        break
                    }
                    g.q_(X, 8);
                    if (!P.G || yhx(P, w)) {
                        X.M0(8);
                        break
                    }
                    return g.B(X, DZ$(P), 8);
                case 8:
                    g.B5(X, 0, 0, 1);
                    P.gC() && (yhx(P, w) || NKh(P), E1t(P), iAE(P.B, u));
                    g.Qx(X, 6, 1);
                    break;
                case 6:
                    g.Qx(X, 0)
            }
        })
    };
    g.N.zB = function() {
        this.L.reset();
        this.S = null;
        this.V = 0;
        if (this.C.length)
            if (this.G) YUt(this);
            else {
                var w = this.C;
                this.C = [];
                var M = w.length;
                NKh(this);
                qUh(this, w, M);
                Oj(this)
            }
        else Oj(this)
    };
    g.N.NH = function(w) {
        var M = w == 2 && this.B.K0 == 401;
        w == 4 || M || this.L.start();
        this.publish("handlerError", w, M);
        M = Object.keys(bxU).find(function(P) {
            return bxU[P] === w
        });
        this.t9.lC("BROWSER_CHANNEL", M != null ? M : "UNKNOWN")
    };
    g.N.WU = function(w, M) {
        if (!this.L.isActive()) this.publish("handlerClosed");
        else if (M)
            for (var P = M.length, u = 0; u < P; ++u) {
                var X = M[u].map;
                X && this.C.push(X)
            }
        this.OO.lC("BROWSER_CHANNEL");
        w && this.TE.B.U0("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps", w.length);
        M && this.VE.B.U0("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps", M.length)
    };
    g.N.ZA = function(w, M) {
        M != null && w != null && this.iW.lC()
    };
    g.N.Hd = function() {
        var w = {
            v: 2
        };
        this.mN && (w.gsessionid = this.mN);
        this.V != 0 && (w.ui = "" + this.V);
        this.Lu != 0 && (w.ui = "" + this.Lu);
        this.S && g.NK(w, this.S);
        return w
    };
    g.N.oS = function(w) {
        w[0] == "S" ? this.mN = w[1] : w[0] == "gracefulReconnect" ? (this.L.start(), this.B.disconnect()) : this.publish("handlerMessage", new pNC(w[0], w[1]));
        this.Yu.lC("BROWSER_CHANNEL")
    };
    g.N.gC = function() {
        return !!this.B && this.B.getState() == 3
    };
    g.N.T2 = function(w) {
        (this.B3.loungeIdToken = w) || this.L.stop();
        if (this.GE && this.B) {
            var M = this.B.Ay || {};
            w ? M["X-YouTube-LoungeId-Token"] = w : delete M["X-YouTube-LoungeId-Token"];
            this.B.Ay = M
        }
    };
    g.N.getDeviceId = function() {
        return this.B3.id
    };
    g.N.uJ = function() {
        return this.L.isActive() ? this.L.L - Date.now() : NaN
    };
    g.N.nE = function() {
        var w = this.L;
        g.rV(w.B);
        w.start()
    };
    g.N.kD0 = function() {
        this.L.isActive();
        MPE(this.B) == 0 && this.connect(this.S, this.V)
    };
    aM.prototype.sendRequest = function(w, M, P, u, X, U, f) {
        w = {
            format: U ? "RAW" : "JSON",
            method: w,
            context: this,
            timeout: 5E3,
            withCredentials: !!f,
            onSuccess: g.Wa(this.X, u, !U),
            onError: g.Wa(this.C, X),
            onTimeout: g.Wa(this.G, X)
        };
        P && (w.postParams = P, w.headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        });
        return g.o1(M, w)
    };
    aM.prototype.X = function(w, M, P, u) {
        M ? w(u) : w({
            text: P.responseText
        })
    };
    aM.prototype.C = function(w, M) {
        w(Error("Request error: " + M.status))
    };
    aM.prototype.G = function(w) {
        w(Error("request timed out"))
    };
    g.V(dZ4, g.WX);
    g.N = dZ4.prototype;
    g.N.connect = function(w, M, P) {
        this.bB.connect(w, M, P)
    };
    g.N.disconnect = function(w) {
        this.bB.disconnect(w)
    };
    g.N.nE = function() {
        this.bB.nE()
    };
    g.N.getDeviceId = function() {
        return this.bB.getDeviceId()
    };
    g.N.uJ = function() {
        return this.bB.uJ()
    };
    g.N.gC = function() {
        return this.bB.gC()
    };
    g.N.dP = function() {
        this.dispatchEvent("channelOpened");
        var w = this.bB,
            M = this.B;
        g.Tg("yt-remote-session-browser-channel", {
            firstTestResults: [""],
            secondTestResults: !w.B.iV,
            sessionId: w.B.X,
            arrayId: w.B.T_
        });
        g.Tg("yt-remote-session-screen-id", M);
        w = Sz();
        M = Hr();
        g.o$(w, M) || w.push(M);
        hWc(w);
        ZBt()
    };
    g.N.onClosed = function() {
        this.dispatchEvent("channelClosed")
    };
    g.N.onMessage = function(w) {
        this.dispatchEvent(new SU$(w))
    };
    g.N.onError = function(w) {
        this.dispatchEvent(new HAC(w ? 1 : 0))
    };
    g.N.sendMessage = function(w, M) {
        this.bB.sendMessage(w, M)
    };
    g.N.T2 = function(w) {
        this.bB.T2(w)
    };
    g.N.dispose = function() {
        this.bB.dispose()
    };
    g.N = ll3.prototype;
    g.N.connect = function(w, M) {
        w = w === void 0 ? {} : w;
        M = M === void 0 ? 0 : M;
        this.K !== 2 && (this.C.stop(), this.V = w, this.j = M, eNC(this), (w = g.AR("ID_TOKEN")) ? this.X["x-youtube-identity-token"] = w : delete this.X["x-youtube-identity-token"], this.B && (this.L.device = this.B.device, this.L.name = this.B.name, this.L.app = this.B.app, this.L.id = this.B.id, this.B.qq && (this.L.mdxVersion = "" + this.B.qq), this.B.theme && (this.L.theme = this.B.theme), this.B.capabilities && (this.L.capabilities = this.B.capabilities), this.B.KR && (this.L.cst = this.B.KR),
            this.B.authuser && (this.L.authuser = this.B.authuser), this.B.pageId && (this.L.pageId = this.B.pageId)), this.j !== 0 ? this.L.ui = "" + this.j : delete this.L.ui, Object.assign(this.L, this.V), this.channel = new vr(this.pathPrefix, {
            Pz: "gsessionid",
            PW3: this.X,
            f3O: this.L
        }), this.channel.open(), this.K = 2, LmA(this))
    };
    g.N.disconnect = function(w) {
        this.S = w === void 0 ? 0 : w;
        this.C.stop();
        eNC(this);
        this.channel && (this.S !== 0 ? this.L.ui = "" + this.S : delete this.L.ui, this.channel.close());
        this.S = 0
    };
    g.N.uJ = function() {
        return this.C.isActive() ? this.C.L - Date.now() : NaN
    };
    g.N.nE = function() {
        var w = this.C;
        g.rV(w.B);
        w.start()
    };
    g.N.sendMessage = function(w, M) {
        this.channel && (eNC(this), w = Object.assign({}, {
            _sc: w
        }, M), this.channel.send(w))
    };
    g.N.T2 = function(w) {
        w || this.C.stop();
        w ? this.X["X-YouTube-LoungeId-Token"] = w : delete this.X["X-YouTube-LoungeId-Token"]
    };
    g.N.getDeviceId = function() {
        return this.B ? this.B.id : ""
    };
    g.N.publish = function(w) {
        return this.G.publish.apply(this.G, [w].concat(g.L(g.Kz.apply(1, arguments))))
    };
    g.N.subscribe = function(w, M, P) {
        return this.G.subscribe(w, M, P)
    };
    g.N.unsubscribe = function(w, M, P) {
        return this.G.unsubscribe(w, M, P)
    };
    g.N.HZ = function(w) {
        return this.G.HZ(w)
    };
    g.N.dispose = function() {
        this.B3 || (this.B3 = !0, g.wR(this.G), this.disconnect(), g.wR(this.C), this.mN = function() {
            return ""
        })
    };
    g.N.sO = function() {
        return this.B3
    };
    g.V(BK$, g.WX);
    g.N = BK$.prototype;
    g.N.connect = function(w, M) {
        this.B.connect(w, M)
    };
    g.N.disconnect = function(w) {
        this.B.disconnect(w)
    };
    g.N.nE = function() {
        this.B.nE()
    };
    g.N.getDeviceId = function() {
        return this.B.getDeviceId()
    };
    g.N.uJ = function() {
        return this.B.uJ()
    };
    g.N.gC = function() {
        return this.B.K === 3
    };
    g.N.Ui = function() {
        this.dispatchEvent("channelOpened")
    };
    g.N.onClosed = function() {
        this.dispatchEvent("channelClosed")
    };
    g.N.onMessage = function(w) {
        this.dispatchEvent(new SU$(w))
    };
    g.N.onError = function() {
        this.dispatchEvent(new HAC(this.B.Oq === 401 ? 1 : 0))
    };
    g.N.sendMessage = function(w, M) {
        this.B.sendMessage(w, M)
    };
    g.N.T2 = function(w) {
        this.B.T2(w)
    };
    g.N.dispose = function() {
        this.B.dispose()
    };
    var bA$ = Date.now(),
        i7 = null,
        X9 = Array(50),
        u7 = -1,
        $_ = !1;
    g.Sp(U9, g.wC);
    U9.prototype.dG = function() {
        return this.screens
    };
    U9.prototype.contains = function(w) {
        return !!Uxt(this.screens, w)
    };
    U9.prototype.get = function(w) {
        return w ? ZJ(this.screens, w) : null
    };
    U9.prototype.info = function(w) {
        MA(this.K, w)
    };
    g.V(Jh3, g.wC);
    g.N = Jh3.prototype;
    g.N.start = function() {
        !this.B && isNaN(this.jZ) && this.UC()
    };
    g.N.stop = function() {
        this.B && (this.B.abort(), this.B = null);
        isNaN(this.jZ) || (g.S9(this.jZ), this.jZ = NaN)
    };
    g.N.v3 = function() {
        this.stop();
        g.wC.prototype.v3.call(this)
    };
    g.N.UC = function() {
        this.jZ = NaN;
        this.B = g.o1(wX(this.C, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: this.j
            },
            timeout: 5E3,
            onSuccess: (0, g.fC)(this.Fj, this),
            onError: (0, g.fC)(this.Kv, this),
            onTimeout: (0, g.fC)(this.kL, this)
        })
    };
    g.N.Fj = function(w, M) {
        this.B = null;
        w = M.screen || {};
        w.dialId = this.X;
        w.name = this.K;
        M = -1;
        this.G && w.shortLivedLoungeToken && w.shortLivedLoungeToken.value && w.shortLivedLoungeToken.refreshIntervalMs && (w.screenIdType = "shortLived", w.loungeToken = w.shortLivedLoungeToken.value, M = w.shortLivedLoungeToken.refreshIntervalMs);
        this.publish("pairingComplete", new Wr(w), M)
    };
    g.N.Kv = function(w) {
        this.B = null;
        w.status && w.status == 404 ? this.L >= I2a.length ? this.publish("pairingFailed", Error("DIAL polling timed out")) : (w = I2a[this.L], this.jZ = g.cF((0, g.fC)(this.UC, this), w), this.L++) : this.publish("pairingFailed", Error("Server error " + w.status))
    };
    g.N.kL = function() {
        this.B = null;
        this.publish("pairingFailed", Error("Server not responding"))
    };
    var I2a = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.Sp(Wd, U9);
    g.N = Wd.prototype;
    g.N.start = function() {
        fu(this) && this.publish("screenChange");
        !g.dH("yt-remote-lounge-token-expiration") && rhA(this);
        g.S9(this.B);
        this.B = g.cF((0, g.fC)(this.start, this), 1E4)
    };
    g.N.add = function(w, M) {
        fu(this);
        Ilt(this, w);
        ho(this, !1);
        this.publish("screenChange");
        M(w);
        w.token || rhA(this)
    };
    g.N.remove = function(w, M) {
        var P = fu(this);
        g14(this, w) && (ho(this, !1), P = !0);
        M(w);
        P && this.publish("screenChange")
    };
    g.N.VD = function(w, M, P, u) {
        var X = fu(this),
            U = this.get(w.id);
        U ? (U.name != M && (U.name = M, ho(this, !1), X = !0), P(w)) : u(Error("no such local screen."));
        X && this.publish("screenChange")
    };
    g.N.v3 = function() {
        g.S9(this.B);
        Wd.Ik.v3.call(this)
    };
    g.N.DB = function(w) {
        fu(this);
        var M = this.screens.length;
        w = w && w.screens || [];
        for (var P = w.length, u = 0; u < P; ++u) {
            var X = w[u],
                U = this.get(X.screenId);
            U && (U.token = X.loungeToken, --M)
        }
        ho(this, !M);
        M && MA(this.K, "Missed " + M + " lounge tokens.")
    };
    g.N.Go = function(w) {
        MA(this.K, "Requesting lounge tokens failed: " + w)
    };
    g.V(CbC, g.wC);
    g.N = CbC.prototype;
    g.N.start = function() {
        var w = parseInt(g.dH("yt-remote-fast-check-period") || "0", 10);
        (this.X = g.ca() - 144E5 < w ? 0 : w) ? cd(this): (this.X = g.ca() + 3E5, g.Tg("yt-remote-fast-check-period", this.X), this.yb())
    };
    g.N.isEmpty = function() {
        return g.SF(this.B)
    };
    g.N.update = function() {
        jmE("Updating availability on schedule.");
        var w = this.K(),
            M = g.iA(this.B, function(P, u) {
                return P && !!ZJ(w, u)
            }, this);
        OAt(this, M)
    };
    g.N.v3 = function() {
        g.S9(this.C);
        this.C = NaN;
        this.L && (this.L.abort(), this.L = null);
        g.wC.prototype.v3.call(this)
    };
    g.N.yb = function() {
        g.S9(this.C);
        this.C = NaN;
        this.L && this.L.abort();
        var w = alh(this);
        if (No$(w)) {
            var M = wX(this.G, "/pairing/get_screen_availability");
            this.L = this.G.sendRequest("POST", M, {
                lounge_token: g.WT(w).join(",")
            }, (0, g.fC)(this.nAW, this, w), (0, g.fC)(this.VZ9, this))
        } else OAt(this, {}), cd(this)
    };
    g.N.nAW = function(w, M) {
        this.L = null;
        var P = g.WT(alh(this));
        if (g.jp(P, g.WT(w))) {
            M = M.screens || [];
            P = {};
            for (var u = M.length, X = 0; X < u; ++X) P[w[M[X].loungeToken]] = M[X].status == "online";
            OAt(this, P);
            cd(this)
        } else this.y0("Changing Screen set during request."), this.yb()
    };
    g.N.VZ9 = function(w) {
        this.y0("Screen availability failed: " + w);
        this.L = null;
        cd(this)
    };
    g.N.y0 = function(w) {
        MA("OnlineScreenService", w)
    };
    g.Sp(Zu, U9);
    g.N = Zu.prototype;
    g.N.start = function() {
        this.L.start();
        this.B.start();
        this.screens.length && (this.publish("screenChange"), this.B.isEmpty() || this.publish("onlineScreenChange"))
    };
    g.N.add = function(w, M, P) {
        this.L.add(w, M, P)
    };
    g.N.remove = function(w, M, P) {
        this.L.remove(w, M, P);
        this.B.update()
    };
    g.N.VD = function(w, M, P, u) {
        this.L.contains(w) ? this.L.VD(w, M, P, u) : (w = "Updating name of unknown screen: " + w.name, MA(this.K, w), u(Error(w)))
    };
    g.N.dG = function(w) {
        return w ? this.screens : g.lh(this.screens, g.DP(this.C, function(M) {
            return !this.contains(M)
        }, this))
    };
    g.N.AO = function() {
        return g.DP(this.dG(!0), function(w) {
            return !!this.B.B[w.id]
        }, this)
    };
    g.N.bj = function(w, M, P, u, X, U) {
        var f = this;
        this.info("getDialScreenByPairingCode " + w + " / " + M);
        var h = new Jh3(this.X, w, M, P, u);
        h.subscribe("pairingComplete", function(c, Z) {
            g.wR(h);
            X(S_(f, c), Z)
        });
        h.subscribe("pairingFailed", function(c) {
            g.wR(h);
            U(c)
        });
        h.start();
        return (0, g.fC)(h.stop, h)
    };
    g.N.xL = function(w, M, P, u) {
        g.o1(wX(this.X, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: w
            },
            timeout: 5E3,
            onSuccess: (0, g.fC)(function(X, U) {
                X = new Wr(U.screen || {});
                if (!X.name || PvA(this, X.name)) {
                    a: {
                        U = X.name;
                        for (var f = 2, h = M(U, f); PvA(this, h);) {
                            f++;
                            if (f > 20) break a;
                            h = M(U, f)
                        }
                        U = h
                    }
                    X.name = U
                }
                P(S_(this, X))
            }, this),
            onError: (0, g.fC)(function(X) {
                u(Error("pairing request failed: " + X.status))
            }, this),
            onTimeout: (0, g.fC)(function() {
                u(Error("pairing request timed out."))
            }, this)
        })
    };
    g.N.v3 = function() {
        g.wR(this.L);
        g.wR(this.B);
        Zu.Ik.v3.call(this)
    };
    g.N.lA = function() {
        XbE(this);
        this.publish("screenChange");
        this.B.update()
    };
    Zu.prototype.dispose = Zu.prototype.dispose;
    g.Sp(Hd, g.wC);
    g.N = Hd.prototype;
    g.N.wg = function(w) {
        this.sO() || (w && (F9(this, "" + w), this.publish("sessionFailed")), this.B = null, this.publish("sessionScreen", null))
    };
    g.N.info = function(w) {
        MA(this.Cu, w)
    };
    g.N.qH = function() {
        return null
    };
    g.N.YU = function(w) {
        var M = this.L;
        w ? (M.displayStatus = new chrome.cast.ReceiverDisplayStatus(w, []), M.displayStatus.showStop = !0) : M.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(M, (0, g.fC)(function() {
            this.info("Updated receiver status for " + M.friendlyName + ": " + w)
        }, this), (0, g.fC)(function() {
            F9(this, "Failed to update receiver status for: " + M.friendlyName)
        }, this))
    };
    g.N.v3 = function() {
        this.YU("");
        Hd.Ik.v3.call(this)
    };
    g.V(E9, Hd);
    g.N = E9.prototype;
    g.N.uQ = function(w) {
        if (this.C) {
            if (this.C == w) return;
            F9(this, "Overriding cast session with new session object");
            EQA(this);
            this.mN = !1;
            this.S = "unknown";
            this.C.removeUpdateListener(this.Lu);
            this.C.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.ys)
        }
        this.C = w;
        this.C.addUpdateListener(this.Lu);
        this.C.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.ys);
        Zd3(this, "getMdxSessionStatus")
    };
    g.N.eN = function(w) {
        this.info("launchWithParams no-op for Cast: " + g.ny(w))
    };
    g.N.stop = function() {
        this.C ? this.C.stop((0, g.fC)(function() {
            this.wg()
        }, this), (0, g.fC)(function() {
            this.wg(Error("Failed to stop receiver app."))
        }, this)) : this.wg(Error("Stopping cast device without session."))
    };
    g.N.YU = function() {};
    g.N.v3 = function() {
        this.info("disposeInternal");
        EQA(this);
        this.C && (this.C.removeUpdateListener(this.Lu), this.C.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.ys));
        this.C = null;
        Hd.prototype.v3.call(this)
    };
    g.N.XlO = function(w, M) {
        if (!this.sO())
            if (M)
                if (M = Pr(M), g.XE(M)) switch (w = "" + M.type, M = M.data || {}, this.info("onYoutubeMessage_: " + w + " " + g.ny(M)), w) {
                    case "mdxSessionStatus":
                        Wha(this, M);
                        break;
                    case "loungeToken":
                        SYE(this, M);
                        break;
                    default:
                        F9(this, "Unknown youtube message: " + w)
                } else F9(this, "Unable to parse message.");
                else F9(this, "No data in message.")
    };
    g.N.dX = function(w, M, P, u) {
        g.S9(this.V);
        this.V = 0;
        MUj(this.X, this.L.label, w, this.L.friendlyName, (0, g.fC)(function(X) {
            X ? M(X) : u >= 0 ? (F9(this, "Screen " + w + " appears to be offline. " + u + " retries left."), this.V = g.cF((0, g.fC)(this.dX, this, w, M, P, u - 1), 300)) : P(Error("Unable to fetch screen."))
        }, this), P)
    };
    g.N.qH = function() {
        return this.C
    };
    g.N.Gs = function(w) {
        this.sO() || w || (F9(this, "Cast session died."), this.wg())
    };
    g.V(NA, Hd);
    g.N = NA.prototype;
    g.N.uQ = function(w) {
        this.C = w;
        this.C.addUpdateListener(this.xu)
    };
    g.N.eN = function(w) {
        this.UO = w;
        this.B3()
    };
    g.N.stop = function() {
        qYU(this);
        this.C ? this.C.stop((0, g.fC)(this.wg, this, null), (0, g.fC)(this.wg, this, "Failed to stop DIAL device.")) : this.wg()
    };
    g.N.v3 = function() {
        qYU(this);
        this.C && this.C.removeUpdateListener(this.xu);
        this.C = null;
        Hd.prototype.v3.call(this)
    };
    g.N.Dj = function(w) {
        this.sO() || w || (F9(this, "DIAL session died."), this.G(), this.G = function() {}, this.wg())
    };
    g.V(oc, Hd);
    oc.prototype.stop = function() {
        this.wg()
    };
    oc.prototype.uQ = function() {};
    oc.prototype.eN = function() {
        g.S9(this.C);
        this.C = NaN;
        var w = ZJ(this.X.dG(), this.L.label);
        w ? pu(this, w) : this.wg(Error("No such screen"))
    };
    oc.prototype.v3 = function() {
        g.S9(this.C);
        this.C = NaN;
        Hd.prototype.v3.call(this)
    };
    g.V(G7, g.wC);
    g.N = G7.prototype;
    g.N.init = function(w, M) {
        chrome.cast.timeout.requestSession = 3E4;
        var P = new chrome.cast.SessionRequest(this.V, [chrome.cast.Capability.AUDIO_OUT]);
        g.FW("desktop_enable_cast_connect") && (P.androidReceiverCompatible = !0);
        this.S || (P.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var u = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED;
        w = w || this.K ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION;
        var X = (0, g.fC)(this.k53, this);
        P = new chrome.cast.ApiConfig(P, (0, g.fC)(this.o1,
            this), X, u, w);
        P.customDialLaunchCallback = (0, g.fC)(this.ouu, this);
        chrome.cast.initialize(P, (0, g.fC)(function() {
            this.sO() || (chrome.cast.addReceiverActionListener(this.G), v1U(), this.L.subscribe("onlineScreenChange", (0, g.fC)(this.JO, this)), this.C = T9E(this), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.fC)(function(U) {
                this.y0("Failed to set initial custom receivers: " + g.ny(U))
            }, this)), this.publish("yt-remote-cast2-availability-change", Du(this)), M(!0))
        }, this), (0, g.fC)(function(U) {
            this.y0("Failed to initialize API: " +
                g.ny(U));
            M(!1)
        }, this))
    };
    g.N.j7s = function(w, M) {
        y9("Setting connected screen ID: " + w + " -> " + M);
        if (this.B) {
            var P = this.B.B;
            if (!w || P && P.id != w) y9("Unsetting old screen status: " + this.B.L.friendlyName), qA(this, null)
        }
        if (w && M) {
            if (!this.B) {
                w = ZJ(this.L.dG(), w);
                if (!w) {
                    y9("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                if (w.idType == "shortLived") {
                    y9("setConnectedScreenStatus: Screen with id type to be short lived.");
                    return
                }
                P = YY3(this, w);
                P || (y9("setConnectedScreenStatus: Connected receiver not custom..."), P = new chrome.cast.Receiver(w.uuid ?
                    w.uuid : w.id, w.name), P.receiverType = chrome.cast.ReceiverType.CUSTOM, this.C.push(P), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.fC)(function(u) {
                    this.y0("Failed to set initial custom receivers: " + g.ny(u))
                }, this)));
                y9("setConnectedScreenStatus: new active receiver: " + P.friendlyName);
                qA(this, new oc(this.L, P), !0)
            }
            this.B.YU(M)
        } else y9("setConnectedScreenStatus: no screen.")
    };
    g.N.lCL = function(w) {
        this.sO() ? this.y0("Setting connection data on disposed cast v2") : this.B ? this.B.eN(w) : this.y0("Setting connection data without a session")
    };
    g.N.Oi = function() {
        this.sO() ? this.y0("Stopping session on disposed cast v2") : this.B ? (this.B.stop(), qA(this, null)) : y9("Stopping non-existing session")
    };
    g.N.requestSession = function() {
        chrome.cast.requestSession((0, g.fC)(this.o1, this), (0, g.fC)(this.N7N, this))
    };
    g.N.v3 = function() {
        this.L.unsubscribe("onlineScreenChange", (0, g.fC)(this.JO, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.G);
        var w = k$c,
            M = g.Mj("yt.mdx.remote.debug.handlers_");
        g.D4(M || [], w);
        g.wR(this.B);
        g.wC.prototype.v3.call(this)
    };
    g.N.y0 = function(w) {
        MA("Controller", w)
    };
    g.N.H2 = function(w, M) {
        this.B == w && (M || qA(this, null), this.publish("yt-remote-cast2-session-change", M))
    };
    g.N.Ut$ = function(w, M) {
        if (!this.sO())
            if (w) switch (w.friendlyName = chrome.cast.unescape(w.friendlyName), y9("onReceiverAction_ " + w.label + " / " + w.friendlyName + "-- " + M), M) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.B)
                        if (this.B.L.label != w.label) y9("onReceiverAction_: Stopping active receiver: " + this.B.L.friendlyName), this.B.stop();
                        else {
                            y9("onReceiverAction_: Casting to active receiver.");
                            this.B.B && this.publish("yt-remote-cast2-session-change", this.B.B);
                            break
                        }
                    switch (w.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            qA(this,
                                new oc(this.L, w));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            qA(this, new NA(this.L, w, this.X, this.config_));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            qA(this, new E9(this.L, w, this.config_));
                            break;
                        default:
                            this.y0("Unknown receiver type: " + w.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.B && this.B.L.label == w.label ? this.B.stop() : this.y0("Stopping receiver w/o session: " + w.friendlyName)
            } else this.y0("onReceiverAction_ called without receiver.")
    };
    g.N.ouu = function(w) {
        if (this.sO()) return Promise.reject(Error("disposed"));
        var M = w.receiver;
        M.receiverType != chrome.cast.ReceiverType.DIAL && (this.y0("Not DIAL receiver: " + M.friendlyName), M.receiverType = chrome.cast.ReceiverType.DIAL);
        var P = this.B ? this.B.L : null;
        if (!P || P.label != M.label) return this.y0("Receiving DIAL launch request for non-clicked DIAL receiver: " + M.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (P && P.label == M.label && P.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.B.B) return y9("Reselecting dial screen."),
                this.publish("yt-remote-cast2-session-change", this.B.B), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.y0('Changing CAST intent from "' + P.receiverType + '" to "dial" for ' + M.friendlyName);
            qA(this, new NA(this.L, M, this.X, this.config_))
        }
        M = this.B;
        M.V = w;
        M.V.appState == chrome.cast.DialAppState.RUNNING ? (w = M.V.extraData || {}, P = w.screenId || null, V9(M) && w.loungeToken ? w.loungeTokenRefreshIntervalMs ? w = Gsp(M, {
            name: M.L.friendlyName,
            screenId: w.screenId,
            loungeToken: w.loungeToken,
            dialId: M.V.receiver.label,
            screenIdType: "shortLived"
        }, w.loungeTokenRefreshIntervalMs) : (g.ro(Error("No loungeTokenRefreshIntervalMs presents in additionalData: " + JSON.stringify(w) + ".")), w = yiC(M, P)) : w = yiC(M, P)) : w = m6E(M);
        return w
    };
    g.N.o1 = function(w) {
        var M = this;
        if (!this.sO() && !this.K) {
            y9("New cast session ID: " + w.sessionId);
            var P = w.receiver;
            if (P.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.B)
                    if (P.receiverType == chrome.cast.ReceiverType.CAST) y9("Got resumed cast session before resumed mdx connection."), P.friendlyName = chrome.cast.unescape(P.friendlyName), qA(this, new E9(this.L, P, this.config_), !0);
                    else {
                        this.y0("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var u = this.B.L,
                    X = ZJ(this.L.dG(),
                        u.label);
                X && h6(X, P.label) && u.receiverType != chrome.cast.ReceiverType.CAST && P.receiverType == chrome.cast.ReceiverType.CAST && (y9("onSessionEstablished_: manual to cast session change " + P.friendlyName), g.wR(this.B), this.B = new E9(this.L, P, this.config_), this.B.subscribe("sessionScreen", (0, g.fC)(this.H2, this, this.B)), this.B.subscribe("sessionFailed", function() {
                    return zzx(M, M.B)
                }), this.B.eN(null));
                this.B.uQ(w)
            }
        }
    };
    g.N.hm = function() {
        return this.B ? this.B.qH() : null
    };
    g.N.N7N = function(w) {
        this.sO() || (this.y0("Failed to estabilish a session: " + g.ny(w)), w.code != chrome.cast.ErrorCode.CANCEL && qA(this, null), this.publish("yt-remote-cast2-session-failed"))
    };
    g.N.k53 = function(w) {
        y9("Receiver availability updated: " + w);
        if (!this.sO()) {
            var M = Du(this);
            this.j = w == chrome.cast.ReceiverAvailability.AVAILABLE;
            Du(this) != M && this.publish("yt-remote-cast2-availability-change", Du(this))
        }
    };
    g.N.JO = function() {
        this.sO() || (this.C = T9E(this), y9("Updating custom receivers: " + g.ny(this.C)), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.fC)(function() {
            this.y0("Failed to set custom receivers.")
        }, this)), this.publish("yt-remote-cast2-availability-change", Du(this)))
    };
    G7.prototype.setLaunchParams = G7.prototype.lCL;
    G7.prototype.setConnectedScreenStatus = G7.prototype.j7s;
    G7.prototype.stopSession = G7.prototype.Oi;
    G7.prototype.getCastSession = G7.prototype.hm;
    G7.prototype.requestSession = G7.prototype.requestSession;
    G7.prototype.init = G7.prototype.init;
    G7.prototype.dispose = G7.prototype.dispose;
    var nQE = [];
    g.N = e_.prototype;
    g.N.reset = function(w) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        Ai3(this);
        this.volume = -1;
        this.muted = !1;
        w && (this.index = w.index, this.listId = w.listId, this.videoId = w.videoId, this.playerState = w.playerState, this.volume = w.volume, this.muted = w.muted, this.audioTrackId = w.audioTrackId, this.trackData = w.trackData, this.ST = w.hasPrevious, this.kH = w.hasNext, this.K = w.playerTime, this.G = w.playerTimeAt, this.L = w.seekableStart, this.j = w.seekableEnd, this.C = w.duration, this.V = w.loadedTime, this.B = w.liveIngestionTime, this.X = !isNaN(this.B))
    };
    g.N.isPlaying = function() {
        return this.playerState == 1
    };
    g.N.isBuffering = function() {
        return this.playerState == 3
    };
    g.N.rj = function() {
        return this.playerState == 1081
    };
    g.N.l4 = function(w) {
        this.C = isNaN(w) ? 0 : w
    };
    g.N.getDuration = function() {
        return this.X ? this.C + Bd(this) : this.C
    };
    g.N.clone = function() {
        return new e_(Jia(this))
    };
    g.V(vd, g.wC);
    g.N = vd.prototype;
    g.N.getState = function() {
        return this.C
    };
    g.N.uJ = function() {
        return this.X.getReconnectTimeout()
    };
    g.N.nE = function() {
        this.X.reconnect()
    };
    g.N.play = function() {
        Ku(this) ? (this.B ? this.B.play(null, g.e0, gX(this, "play")) : Ao(this, "play"), Cvh(this, 1, k_(s9(this))), this.publish("remotePlayerChange")) : b7(this, this.play)
    };
    g.N.pause = function() {
        Ku(this) ? (this.B ? this.B.pause(null, g.e0, gX(this, "pause")) : Ao(this, "pause"), Cvh(this, 2, k_(s9(this))), this.publish("remotePlayerChange")) : b7(this, this.pause)
    };
    g.N.seekTo = function(w) {
        if (Ku(this)) {
            if (this.B) {
                var M = s9(this),
                    P = new chrome.cast.media.SeekRequest;
                P.currentTime = w;
                M.isPlaying() || M.isBuffering() ? P.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : P.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.B.seek(P, g.e0, gX(this, "seekTo", {
                    newTime: w
                }))
            } else Ao(this, "seekTo", {
                newTime: w
            });
            Cvh(this, 3, w);
            this.publish("remotePlayerChange")
        } else b7(this, g.Wa(this.seekTo, w))
    };
    g.N.stop = function() {
        if (Ku(this)) {
            this.B ? this.B.stop(null, g.e0, gX(this, "stopVideo")) : Ao(this, "stopVideo");
            var w = s9(this);
            w.index = -1;
            w.videoId = "";
            Ai3(w);
            Ic(this, w);
            this.publish("remotePlayerChange")
        } else b7(this, this.stop)
    };
    g.N.setVolume = function(w, M) {
        if (Ku(this)) {
            var P = s9(this);
            if (this.L) {
                if (P.volume != w) {
                    var u = Math.round(w) / 100;
                    this.L.setReceiverVolumeLevel(u, (0, g.fC)(function() {
                        Pd("set receiver volume: " + u)
                    }, this), (0, g.fC)(function() {
                        this.y0("failed to set receiver volume.")
                    }, this))
                }
                P.muted != M && this.L.setReceiverMuted(M, (0, g.fC)(function() {
                    Pd("set receiver muted: " + M)
                }, this), (0, g.fC)(function() {
                    this.y0("failed to set receiver muted.")
                }, this))
            } else {
                var X = {
                    volume: w,
                    muted: M
                };
                P.volume != -1 && (X.delta = w - P.volume);
                Ao(this, "setVolume", X)
            }
            P.muted = M;
            P.volume = w;
            Ic(this, P)
        } else b7(this, g.Wa(this.setVolume, w, M))
    };
    g.N.SJ = function(w, M) {
        if (Ku(this)) {
            var P = s9(this);
            w = {
                videoId: w
            };
            M && (P.trackData = {
                trackName: M.name,
                languageCode: M.languageCode,
                sourceLanguageCode: M.translationLanguage ? M.translationLanguage.languageCode : "",
                languageName: M.languageName,
                kind: M.kind
            }, w.style = g.ny(M.style), g.NK(w, P.trackData));
            Ao(this, "setSubtitlesTrack", w);
            Ic(this, P)
        } else b7(this, g.Wa(this.SJ, w, M))
    };
    g.N.setAudioTrack = function(w, M) {
        Ku(this) ? (M = M.getLanguageInfo().getId(), Ao(this, "setAudioTrack", {
            videoId: w,
            audioTrackId: M
        }), w = s9(this), w.audioTrackId = M, Ic(this, w)) : b7(this, g.Wa(this.setAudioTrack, w, M))
    };
    g.N.playVideo = function(w, M, P, u, X, U, f) {
        u = u === void 0 ? null : u;
        X = X === void 0 ? null : X;
        U = U === void 0 ? null : U;
        f = f === void 0 ? null : f;
        var h = s9(this),
            c = {
                videoId: w
            };
        P !== void 0 && (c.currentIndex = P);
        Rc(h, w, P || 0);
        M !== void 0 && (Q9(h, M), c.currentTime = M);
        u && (c.listId = u);
        X && (c.playerParams = X);
        U && (c.clickTrackingParams = U);
        f && (c.locationInfo = g.ny(f));
        Ao(this, "setPlaylist", c);
        u || Ic(this, h)
    };
    g.N.xi = function(w, M) {
        if (Ku(this)) {
            if (w && M) {
                var P = s9(this);
                Rc(P, w, M);
                Ic(this, P)
            }
            Ao(this, "previous")
        } else b7(this, g.Wa(this.xi, w, M))
    };
    g.N.nextVideo = function(w, M) {
        if (Ku(this)) {
            if (w && M) {
                var P = s9(this);
                Rc(P, w, M);
                Ic(this, P)
            }
            Ao(this, "next")
        } else b7(this, g.Wa(this.nextVideo, w, M))
    };
    g.N.eh = function() {
        if (Ku(this)) {
            Ao(this, "clearPlaylist");
            var w = s9(this);
            w.reset();
            Ic(this, w);
            this.publish("remotePlayerChange")
        } else b7(this, this.eh)
    };
    g.N.Ux = function() {
        Ku(this) ? Ao(this, "dismissAutoplay") : b7(this, this.Ux)
    };
    g.N.dispose = function() {
        if (this.C != 3) {
            var w = this.C;
            this.C = 3;
            this.publish("proxyStateChange", w, this.C)
        }
        g.wC.prototype.dispose.call(this)
    };
    g.N.v3 = function() {
        jX$(this);
        this.X = null;
        this.G.clear();
        nu(this, null);
        g.wC.prototype.v3.call(this)
    };
    g.N.NN = function(w) {
        if ((w != this.C || w == 2) && this.C != 3 && w != 0) {
            var M = this.C;
            this.C = w;
            this.publish("proxyStateChange", M, w);
            if (w == 1)
                for (; !this.G.isEmpty();) M = w = this.G, M.B.length === 0 && (M.B = M.L, M.B.reverse(), M.L = []), w.B.pop().apply(this);
            else w == 3 && this.dispose()
        }
    };
    g.N.Xkk = function(w, M) {
        this.publish(w, M)
    };
    g.N.jIs = function(w) {
        if (!w) this.AL(null), nu(this, null);
        else if (this.L.receiver.volume) {
            w = this.L.receiver.volume;
            var M = s9(this),
                P = Math.round(100 * w.level || 0);
            if (M.volume != P || M.muted != w.muted) Pd("Cast volume update: " + w.level + (w.muted ? " muted" : "")), M.volume = P, M.muted = !!w.muted, Ic(this, M)
        }
    };
    g.N.AL = function(w) {
        Pd("Cast media: " + !!w);
        this.B && this.B.removeUpdateListener(this.V);
        if (this.B = w) this.B.addUpdateListener(this.V), tUE(this), this.publish("remotePlayerChange")
    };
    g.N.w30 = function(w) {
        w ? (tUE(this), this.publish("remotePlayerChange")) : this.AL(null)
    };
    g.N.kI = function() {
        Ao(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.N.uK9 = function() {
        var w = KhV();
        w && nu(this, w)
    };
    g.N.y0 = function(w) {
        MA("CP", w)
    };
    g.V(j_, g.wC);
    g.N = j_.prototype;
    g.N.connect = function(w, M) {
        if (M) {
            var P = M.listId,
                u = M.videoId,
                X = M.videoIds,
                U = M.playerParams,
                f = M.clickTrackingParams,
                h = M.index,
                c = {
                    videoId: u
                },
                Z = M.currentTime,
                S = M.locationInfo;
            M = M.loopMode;
            Z !== void 0 && (c.currentTime = Z <= 5 ? 0 : Z);
            U && (c.playerParams = U);
            S && (c.locationInfo = S);
            f && (c.clickTrackingParams = f);
            P && (c.listId = P);
            X && X.length > 0 && (c.videoIds = X.join(","));
            h !== void 0 && (c.currentIndex = h);
            this.xu && (c.loopMode = M || "LOOP_MODE_OFF");
            P && (this.B.listId = P);
            this.B.videoId = u;
            this.B.index = h || 0;
            this.B.state = 3;
            Q9(this.B,
                Z);
            this.G = "UNSUPPORTED";
            P = this.xu ? "setInitialState" : "setPlaylist";
            Jo("Connecting with " + P + " and params: " + g.ny(c));
            this.L.connect({
                method: P,
                params: g.ny(c)
            }, w, SLt())
        } else Jo("Connecting without params"), this.L.connect({}, w, SLt());
        wlA(this)
    };
    g.N.T2 = function(w) {
        this.L.T2(w)
    };
    g.N.dispose = function() {
        this.sO() || (g.ih("yt.mdx.remote.remoteClient_", null), this.publish("beforeDispose"), rX(this, 3));
        g.wC.prototype.dispose.call(this)
    };
    g.N.v3 = function() {
        ix3(this);
        P5h(this);
        MWE(this);
        g.S9(this.V);
        this.V = NaN;
        g.S9(this.S);
        this.S = NaN;
        this.X = null;
        g.Vh(this.B3);
        this.B3.length = 0;
        this.L.dispose();
        g.wC.prototype.v3.call(this);
        this.G = this.j = this.C = this.B = this.L = null
    };
    g.N.If = function(w) {
        if (!this.C || this.C.length === 0) return !1;
        for (var M = g.G(this.C), P = M.next(); !P.done; P = M.next())
            if (!P.value.capabilities.has(w)) return !1;
        return !0
    };
    g.N.B4 = function() {
        var w = 3;
        this.sO() || (w = 0, isNaN(this.QF()) ? this.L.gC() && isNaN(this.K) && (w = 1) : w = 2);
        return w
    };
    g.N.FT = function(w) {
        Jo("Disconnecting with " + w);
        g.ih("yt.mdx.remote.remoteClient_", null);
        ix3(this);
        this.publish("beforeDisconnect", w);
        w == 1 && pg();
        this.L.disconnect(w);
        this.dispose()
    };
    g.N.b$ = function() {
        var w = this.B;
        this.X && (w = this.B.clone(), Rc(w, this.X, w.index));
        return Jia(w)
    };
    g.N.nmK = function(w) {
        var M = this,
            P = new e_(w);
        P.videoId && P.videoId != this.B.videoId && (this.X = P.videoId, g.S9(this.V), this.V = g.cF(function() {
            if (M.X) {
                var X = M.X;
                M.X = null;
                M.B.videoId != X && Cu(M, "getNowPlaying")
            }
        }, 5E3));
        var u = [];
        this.B.listId == P.listId && this.B.videoId == P.videoId && this.B.index == P.index || u.push("remoteQueueChange");
        this.B.playerState == P.playerState && this.B.volume == P.volume && this.B.muted == P.muted && k_(this.B) == k_(P) && g.ny(this.B.trackData) == g.ny(P.trackData) || u.push("remotePlayerChange");
        this.B.reset(w);
        g.tx(u, function(X) {
            this.publish(X)
        }, this)
    };
    g.N.rX = function() {
        var w = this.L.getDeviceId(),
            M = g.Nj(this.C, function(P) {
                return P.type == "REMOTE_CONTROL" && P.id != w
            });
        return M ? M.id : ""
    };
    g.N.QF = function() {
        return this.L.uJ()
    };
    g.N.al = function() {
        return this.G || "UNSUPPORTED"
    };
    g.N.QV = function() {
        return this.j || ""
    };
    g.N.gP = function() {
        !isNaN(this.QF()) && this.L.nE()
    };
    g.N.gmu = function(w, M) {
        Cu(this, w, M);
        XlE(this)
    };
    g.N.c7 = function() {
        var w = g.e9("SAPISID", "") || g.e9("__Secure-1PAPISID") || "",
            M = g.e9("__Secure-3PAPISID", "") || "";
        if (!w && !M) return "";
        w = g.Yw(g.qq(w), 2);
        M = g.Yw(g.qq(M), 2);
        return g.Yw(g.qq("," + w + "," + M), 2)
    };
    j_.prototype.subscribe = j_.prototype.subscribe;
    j_.prototype.unsubscribeByKey = j_.prototype.HZ;
    j_.prototype.getProxyState = j_.prototype.B4;
    j_.prototype.disconnect = j_.prototype.FT;
    j_.prototype.getPlayerContextData = j_.prototype.b$;
    j_.prototype.setPlayerContextData = j_.prototype.nmK;
    j_.prototype.getOtherConnectedRemoteId = j_.prototype.rX;
    j_.prototype.getReconnectTimeout = j_.prototype.QF;
    j_.prototype.getAutoplayMode = j_.prototype.al;
    j_.prototype.getAutoplayVideoId = j_.prototype.QV;
    j_.prototype.reconnect = j_.prototype.gP;
    j_.prototype.sendMessage = j_.prototype.gmu;
    j_.prototype.getXsrfToken = j_.prototype.c7;
    j_.prototype.isCapabilitySupportedOnConnectedDevices = j_.prototype.If;
    g.V(EB$, U9);
    g.N = EB$.prototype;
    g.N.dG = function(w) {
        return this.XJ.$_gs(w)
    };
    g.N.contains = function(w) {
        return !!this.XJ.$_c(w)
    };
    g.N.get = function(w) {
        return this.XJ.$_g(w)
    };
    g.N.start = function() {
        this.XJ.$_st()
    };
    g.N.add = function(w, M, P) {
        this.XJ.$_a(w, M, P)
    };
    g.N.remove = function(w, M, P) {
        this.XJ.$_r(w, M, P)
    };
    g.N.VD = function(w, M, P, u) {
        this.XJ.$_un(w, M, P, u)
    };
    g.N.v3 = function() {
        for (var w = this.B.length, M = 0; M < w; ++M) this.XJ.$_ubk(this.B[M]);
        this.B.length = 0;
        this.XJ = null;
        U9.prototype.v3.call(this)
    };
    g.N.QR = function() {
        this.publish("screenChange")
    };
    g.N.x7u = function() {
        this.publish("onlineScreenChange")
    };
    Zu.prototype.$_st = Zu.prototype.start;
    Zu.prototype.$_gspc = Zu.prototype.xL;
    Zu.prototype.$_gsppc = Zu.prototype.bj;
    Zu.prototype.$_c = Zu.prototype.contains;
    Zu.prototype.$_g = Zu.prototype.get;
    Zu.prototype.$_a = Zu.prototype.add;
    Zu.prototype.$_un = Zu.prototype.VD;
    Zu.prototype.$_r = Zu.prototype.remove;
    Zu.prototype.$_gs = Zu.prototype.dG;
    Zu.prototype.$_gos = Zu.prototype.AO;
    Zu.prototype.$_s = Zu.prototype.subscribe;
    Zu.prototype.$_ubk = Zu.prototype.HZ;
    var $o = null,
        WB = !1,
        to = null,
        x_ = null,
        TGE = null,
        iS = [];
    g.V(BGA, g.v);
    g.N = BGA.prototype;
    g.N.v3 = function() {
        g.v.prototype.v3.call(this);
        this.L.stop();
        this.C.stop();
        this.V.stop();
        var w = this.Hj;
        w.unsubscribe("proxyStateChange", this.iL, this);
        w.unsubscribe("remotePlayerChange", this.fC, this);
        w.unsubscribe("remoteQueueChange", this.LY, this);
        w.unsubscribe("previousNextChange", this.td, this);
        w.unsubscribe("nowAutoplaying", this.gQ, this);
        w.unsubscribe("autoplayDismissed", this.yf, this);
        this.Hj = this.B = null
    };
    g.N.ME = function(w) {
        var M = g.Kz.apply(1, arguments);
        if (this.Hj.C != 2)
            if (hj(this)) {
                if (!s9(this.Hj).rj() || w !== "control_seek") switch (w) {
                    case "control_toggle_play_pause":
                        s9(this.Hj).isPlaying() ? this.Hj.pause() : this.Hj.play();
                        break;
                    case "control_play":
                        this.Hj.play();
                        break;
                    case "control_pause":
                        this.Hj.pause();
                        break;
                    case "control_seek":
                        this.j.Up(M[0], M[1]);
                        break;
                    case "control_subtitles_set_track":
                        kJj(this, M[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(M[0])
                }
            } else switch (w) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    M =
                        this.U.getCurrentTime();
                    cB(this, M === 0 ? void 0 : M);
                    break;
                case "control_seek":
                    cB(this, M[0]);
                    break;
                case "control_subtitles_set_track":
                    kJj(this, M[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(M[0])
            }
    };
    g.N.a3O = function(w) {
        this.V.Ih(w)
    };
    g.N.nDs = function(w) {
        this.ME("control_subtitles_set_track", g.SF(w) ? null : w)
    };
    g.N.t8 = function() {
        var w = this.U.getOption("captions", "track");
        g.SF(w) || kJj(this, w)
    };
    g.N.Ub = function(w) {
        this.B.Ub(w, this.U.getVideoData().lengthSeconds)
    };
    g.N.RiL = function() {
        g.SF(this.X) || R1a(this, this.X);
        this.G = !1
    };
    g.N.iL = function(w, M) {
        this.C.stop();
        M === 2 && this.GM()
    };
    g.N.fC = function() {
        if (hj(this)) {
            this.L.stop();
            var w = s9(this.Hj);
            switch (w.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.B.yO = 1;
                    break;
                case 1082:
                case 1083:
                    this.B.yO = 0;
                    break;
                default:
                    this.B.yO = -1
            }
            switch (w.playerState) {
                case 1081:
                case 1:
                    this.Pk(new g.EH(8));
                    this.eC();
                    break;
                case 1085:
                case 3:
                    this.Pk(new g.EH(9));
                    break;
                case 1083:
                case 0:
                    this.Pk(new g.EH(2));
                    this.j.stop();
                    this.Ub(this.U.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    this.Pk(new g.EH(4));
                    break;
                case 2:
                    this.Pk(new g.EH(4));
                    this.Ub(k_(w));
                    break;
                case -1:
                    this.Pk(new g.EH(64));
                    break;
                case -1E3:
                    this.Pk(new g.EH(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "This video is not available for remote playback.",
                        nQ: 2
                    }))
            }
            w = s9(this.Hj).trackData;
            var M = this.X;
            (w || M ? w && M && w.trackName == M.trackName && w.languageCode == M.languageCode && w.languageName == M.languageName && w.kind == M.kind : 1) || (this.X = w, R1a(this, w));
            w = s9(this.Hj);
            w.volume === -1 || Math.round(this.U.getVolume()) === w.volume && this.U.isMuted() === w.muted || this.S.isActive() || this.Dd()
        } else QEE(this)
    };
    g.N.td = function() {
        this.U.publish("mdxpreviousnextchange")
    };
    g.N.LY = function() {
        hj(this) || QEE(this)
    };
    g.N.gQ = function(w) {
        isNaN(w) || this.U.publish("mdxnowautoplaying", w)
    };
    g.N.yf = function() {
        this.U.publish("mdxautoplaycanceled")
    };
    g.N.setAudioTrack = function(w) {
        hj(this) && this.Hj.setAudioTrack(this.U.getVideoData(1).videoId, w)
    };
    g.N.seekTo = function(w, M) {
        s9(this.Hj).playerState === -1 ? cB(this, w) : M && this.Hj.seekTo(w)
    };
    g.N.Dd = function() {
        var w = this;
        if (hj(this)) {
            var M = s9(this.Hj);
            this.events.Mt(this.B3);
            M.muted ? this.U.mute() : this.U.unMute();
            this.U.setVolume(M.volume);
            this.B3 = this.events.Y(this.U, "onVolumeChange", function(P) {
                LS4(w, P)
            })
        }
    };
    g.N.eC = function() {
        this.L.stop();
        if (!this.Hj.sO()) {
            var w = s9(this.Hj);
            w.isPlaying() && this.Pk(new g.EH(8));
            this.Ub(k_(w));
            this.L.start()
        }
    };
    g.N.GM = function() {
        this.C.stop();
        this.L.stop();
        var w = this.Hj.uJ();
        this.Hj.C == 2 && !isNaN(w) && this.C.start()
    };
    g.N.Pk = function(w) {
        this.C.stop();
        var M = this.K;
        if (!g.yO(M, w)) {
            var P = g.C(w, 2);
            P !== g.C(this.K, 2) && this.U.j4(P);
            this.K = w;
            sEa(this.B, M, w)
        }
    };
    g.V(nB$, g.Al);
    g.N = nB$.prototype;
    g.N.getCurrentTime = function() {
        return this.B.getCurrentTime()
    };
    g.N.getDuration = function() {
        return this.B.getDuration()
    };
    g.N.Ls = function() {
        return this.B.Ls()
    };
    g.N.rk = function() {
        return this.B.rk()
    };
    g.N.Ft = function() {
        return this.B.Ft()
    };
    g.N.l6 = function() {
        return this.B.l6()
    };
    g.N.getPlayerState = function() {
        return this.B.zt
    };
    g.N.isAtLiveHead = function() {
        return this.B.isAtLiveHead()
    };
    g.N.pauseVideo = function() {
        this.B.iD("control_pause")
    };
    g.N.playVideo = function() {
        var w = this;
        return g.n(function(M) {
            w.B.iD("control_play");
            return M.return()
        })
    };
    g.N.seekTo = function(w, M) {
        this.B.iD("control_seek", w, !(M == null ? 0 : M.qs))
    };
    g.N.WH = function(w) {
        this.B.iD("control_set_audio_track", w);
        return !0
    };
    g.V(ZL, g.r);
    ZL.prototype.w7 = function() {
        this.fade.show()
    };
    ZL.prototype.Wj = function() {
        this.fade.hide()
    };
    ZL.prototype.B = function() {
        Ej("mdx-privacy-popup-cancel");
        this.Wj()
    };
    ZL.prototype.L = function() {
        Ej("mdx-privacy-popup-confirm");
        this.Wj()
    };
    g.V(S$, g.r);
    S$.prototype.onStateChange = function(w) {
        this.g7(w.state)
    };
    S$.prototype.g7 = function(w) {
        if (this.api.getPresentingPlayerType() === 3) {
            var M = {
                RECEIVER_NAME: this.api.getOption("remote", "currentReceiver").name
            };
            w = g.C(w, 128) ? g.iM("Error on $RECEIVER_NAME", M) : w.isPlaying() || w.isPaused() ? g.iM("Playing on $RECEIVER_NAME", M) : g.iM("Connected to $RECEIVER_NAME", M);
            this.updateValue("statustext", w);
            this.fade.show()
        } else this.fade.hide()
    };
    g.V(HB, g.v6);
    HB.prototype.X = function() {
        var w = this.U.getOption("remote", "receivers");
        w && w.length > 1 && !this.U.getOption("remote", "quickCast") ? (this.g0 = g.xV(w, this.B, this), this.cI(g.EV(w, this.B)), w = this.U.getOption("remote", "currentReceiver"), w = this.B(w), this.options[w] && this.JV(w), this.enable(!0)) : this.enable(!1)
    };
    HB.prototype.B = function(w) {
        return w.key
    };
    HB.prototype.SH = function(w) {
        return w === "cast-selector-receiver" ? "Cast..." : this.g0[w].name
    };
    HB.prototype.p9 = function(w) {
        g.v6.prototype.p9.call(this, w);
        this.U.setOption("remote", "currentReceiver", this.g0[w]);
        this.Lg.Wj()
    };
    g.V(vBV, g.D0);
    g.N = vBV.prototype;
    g.N.create = function() {
        var w = this.player.N(),
            M = g.r8(w);
        w = {
            device: "Desktop",
            app: "youtube-desktop",
            loadCastApiSetupScript: w.D("mdx_load_cast_api_bootstrap_script"),
            enableDialLoungeToken: w.D("enable_dial_short_lived_lounge_token"),
            enableCastLoungeToken: w.D("enable_cast_short_lived_lounge_token")
        };
        GJj(M, w);
        this.subscriptions.push(g.ti("yt-remote-before-disconnect", this.Ou$, this));
        this.subscriptions.push(g.ti("yt-remote-connection-change", this.svu, this));
        this.subscriptions.push(g.ti("yt-remote-receiver-availability-change", this.Vf,
            this));
        this.subscriptions.push(g.ti("yt-remote-auto-connect", this.FTu, this));
        this.subscriptions.push(g.ti("yt-remote-receiver-resumed", this.KT0, this));
        this.subscriptions.push(g.ti("mdx-privacy-popup-confirm", this.oau, this));
        this.subscriptions.push(g.ti("mdx-privacy-popup-cancel", this.NBK, this));
        this.Vf()
    };
    g.N.load = function() {
        this.player.cancelPlayback();
        g.D0.prototype.load.call(this);
        this.Wb = new nB$(this.player.N(), this);
        this.player.mY(this.Wb);
        this.Px = new BGA(this, this.player, this.Hj);
        var w = (w = l2t()) ? w.currentTime : 0;
        var M = z1C() ? new vd(XC(), void 0) : null;
        w == 0 && M && (w = k_(s9(M)));
        w !== 0 && this.Ub(w);
        sEa(this, this.zt, this.zt);
        this.player.Nx(6)
    };
    g.N.unload = function() {
        this.player.publish("mdxautoplaycanceled");
        this.player.Y5();
        this.KH = this.yJ;
        g.iZ(this.Px, this.Hj);
        this.Hj = this.Wb = this.Px = null;
        g.D0.prototype.unload.call(this);
        this.player.Nx(5);
        p1(this)
    };
    g.N.v3 = function() {
        g.xQ(this.subscriptions);
        g.D0.prototype.v3.call(this)
    };
    g.N.iD = function(w) {
        var M = g.Kz.apply(1, arguments);
        this.loaded && this.Px.ME.apply(this.Px, [w].concat(g.L(M)))
    };
    g.N.getAdState = function() {
        return this.yO
    };
    g.N.ST = function() {
        return this.Hj ? s9(this.Hj).ST : !1
    };
    g.N.kH = function() {
        return this.Hj ? s9(this.Hj).kH : !1
    };
    g.N.Ub = function(w, M) {
        this.yM = w || 0;
        this.player.publish("progresssync", w, M);
        this.player.z5("onVideoProgress", w || 0)
    };
    g.N.getCurrentTime = function() {
        return this.yM
    };
    g.N.getDuration = function() {
        return s9(this.Hj).getDuration() || 0
    };
    g.N.Ls = function() {
        var w = s9(this.Hj);
        return w.X ? w.B + Bd(w) : w.B
    };
    g.N.rk = function() {
        return s9(this.Hj).V
    };
    g.N.Ft = function() {
        return gQE(s9(this.Hj))
    };
    g.N.l6 = function() {
        var w = s9(this.Hj);
        return w.L > 0 ? w.L + Bd(w) : w.L
    };
    g.N.getProgressState = function() {
        var w = s9(this.Hj),
            M = this.player.getVideoData();
        return {
            airingStart: 0,
            airingEnd: 0,
            allowSeeking: !w.rj() && this.player.q8(),
            clipEnd: M.clipEnd,
            clipStart: M.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: this.getDuration(),
            ingestionTime: this.Ls(),
            isAtLiveHead: this.isAtLiveHead(),
            loaded: this.rk(),
            seekableEnd: this.Ft(),
            seekableStart: this.l6(),
            offset: 0,
            viewerLivestreamJoinMediaTime: 0
        }
    };
    g.N.isAtLiveHead = function() {
        return gQE(s9(this.Hj)) - this.getCurrentTime() <= 1
    };
    g.N.nextVideo = function() {
        this.Hj && this.Hj.nextVideo()
    };
    g.N.xi = function() {
        this.Hj && this.Hj.xi()
    };
    g.N.Ou$ = function(w) {
        w === 1 && (this.A$ = this.Hj ? s9(this.Hj) : null)
    };
    g.N.svu = function() {
        var w = z1C() ? new vd(XC(), void 0) : null;
        if (w) {
            var M = this.KH;
            this.loaded && this.unload();
            this.Hj = w;
            this.A$ = null;
            M.key !== this.yJ.key && (this.KH = M, this.load())
        } else g.wR(this.Hj), this.Hj = null, this.loaded && (this.unload(), (w = this.A$) && w.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(w.videoId, k_(w)));
        this.player.publish("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.N.Vf = function() {
        var w = [this.yJ],
            M = w.concat,
            P = yrE();
        dX() && g.dH("yt-remote-cast-available") && P.push({
            key: "cast-selector-receiver",
            name: "Cast..."
        });
        this.g0 = M.call(w, P);
        w = qXU() || this.yJ;
        FC(this, w);
        this.player.z5("onMdxReceiversChange")
    };
    g.N.FTu = function() {
        var w = qXU();
        FC(this, w)
    };
    g.N.KT0 = function() {
        this.KH = qXU()
    };
    g.N.oau = function() {
        this.Fn = !0;
        p1(this);
        WB = !1;
        $o && f1($o, 1);
        $o = null
    };
    g.N.NBK = function() {
        this.Fn = !1;
        p1(this);
        FC(this, this.yJ);
        this.KH = this.yJ;
        WB = !1;
        $o = null;
        this.player.playVideo()
    };
    g.N.S0 = function(w, M) {
        switch (w) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.g0;
            case "currentReceiver":
                return M && (M.key === "cast-selector-receiver" ? bdt() : FC(this, M)), this.loaded ? this.KH : this.yJ;
            case "quickCast":
                return this.g0.length === 2 && this.g0[1].key === "cast-selector-receiver" ? (M && bdt(), !0) : !1
        }
    };
    g.N.kI = function() {
        this.Hj.kI()
    };
    g.N.Yo = function() {
        return !1
    };
    g.N.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.N.isLoggedIn = function() {
        var w, M;
        return ((w = g.AR("PLAYER_CONFIG")) == null ? void 0 : (M = w.args) == null ? void 0 : M.authuser) !== void 0 ? !0 : !(!g.AR("SESSION_INDEX") && !g.AR("LOGGED_IN"))
    };
    g.yT("remote", vBV);
})(_yt_player);