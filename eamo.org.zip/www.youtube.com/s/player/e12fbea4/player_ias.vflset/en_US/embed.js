(function(g) {
    var window = this;
    'use strict';
    var WRh = function(w) {
            w.mutedAutoplay = !1;
            w.endSeconds = NaN;
            w.limitedPlaybackDurationInSeconds = NaN;
            g.Up(w)
        },
        hZ3 = function() {
            return {
                W: "svg",
                Z: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                J: [{
                    W: "path",
                    fT: !0,
                    T: "ytp-svg-fill",
                    Z: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        caC = function() {
            return {
                W: "svg",
                Z: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                J: [{
                    W: "path",
                    Z: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    W: "path",
                    Z: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    W: "path",
                    Z: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    W: "path",
                    Z: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    W: "path",
                    Z: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    W: "path",
                    Z: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        Z5$ = function(w) {
            g.r.call(this, {
                W: "div",
                T: "ytp-related-on-error-overlay"
            });
            var M = this;
            this.api = w;
            this.K = this.L = 0;
            this.X = new g.V2(this);
            this.B = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.r({
                W: "h2",
                T: "ytp-related-title",
                pu: "{{title}}"
            });
            this.previous = new g.r({
                W: "button",
                d$: ["ytp-button", "ytp-previous"],
                Z: {
                    "aria-label": "Show previous suggested videos"
                },
                J: [g.cz()]
            });
            this.S = new g.Mg(function(U) {
                M.suggestions.element.scrollLeft = -U
            });
            this.C = this.scrollPosition = 0;
            this.j = !0;
            this.next = new g.r({
                W: "button",
                d$: ["ytp-button", "ytp-next"],
                Z: {
                    "aria-label": "Show more suggested videos"
                },
                J: [g.ZI()]
            });
            g.b(this, this.X);
            w = w.N();
            this.api.D("embeds_web_enable_pause_overlay_rounding") && g.io(this.element, "ytp-error-overlay-round-corners");
            this.V = w.X;
            g.b(this, this.title);
            this.title.XK(this.element);
            this.suggestions = new g.r({
                W: "div",
                T: "ytp-suggestions"
            });
            g.b(this, this.suggestions);
            this.suggestions.XK(this.element);
            g.b(this, this.previous);
            this.previous.XK(this.element);
            this.previous.listen("click", this.u2, this);
            g.b(this, this.S);
            for (var P = {
                    BG: 0
                }; P.BG < 16; P = {
                    BG: P.BG
                }, P.BG++) {
                var u = new g.r({
                    W: "a",
                    T: "ytp-suggestion-link",
                    Z: {
                        href: "{{link}}",
                        target: w.S,
                        "aria-label": "{{aria_label}}"
                    },
                    J: [{
                        W: "div",
                        T: "ytp-suggestion-image",
                        J: [{
                            W: "div",
                            Z: {
                                "data-is-live": "{{is_live}}"
                            },
                            T: "ytp-suggestion-duration",
                            pu: "{{duration}}"
                        }]
                    }, {
                        W: "div",
                        T: "ytp-suggestion-title",
                        Z: {
                            title: "{{hover_title}}"
                        },
                        pu: "{{title}}"
                    }, {
                        W: "div",
                        T: "ytp-suggestion-author",
                        pu: "{{views_or_author}}"
                    }]
                });
                g.b(this, u);
                u.XK(this.suggestions.element);
                var X = u.RI("ytp-suggestion-link");
                g.A1(X, "transitionDelay", P.BG / 20 + "s");
                this.X.Y(X, "click", function(U) {
                    return function(f) {
                        var h = U.BG,
                            c = M.suggestionData[h],
                            Z = c.sessionData;
                        g.K7(M.api.N()) && M.api.D("web_player_log_click_before_generating_ve_conversion_params") ? (M.api.logClick(M.B[h].element), h = c.eA(), c = {}, g.vV(M.api, c), h = g.p5(h, c), g.HH(h, M.api, f)) : g.SZ(f, M.api, M.V, Z || void 0) && M.api.Hx(c.videoId, Z, c.playlistId)
                    }
                }(P));
                this.B.push(u)
            }
            g.b(this, this.next);
            this.next.XK(this.element);
            this.next.listen("click", this.Tu, this);
            this.X.Y(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.oI().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        SQA = function(w, M) {
            if (w.api.N().D("web_player_log_click_before_generating_ve_conversion_params"))
                for (var P = Math.floor(-w.scrollPosition / (w.C + w.L)), u = Math.min(P + w.columns, w.suggestionData.length) - 1; P <= u; P++) w.api.logVisibility(w.B[P].element, M)
        },
        H5h = function(w) {
            w.next.element.style.bottom =
                w.K + "px";
            w.previous.element.style.bottom = w.K + "px";
            var M = w.scrollPosition,
                P = w.containerWidth - w.suggestionData.length * (w.C + w.L);
            g.X6(w.element, "ytp-scroll-min", M >= 0);
            g.X6(w.element, "ytp-scroll-max", M <= P)
        },
        pYa = function(w) {
            for (var M = 0; M < w.suggestionData.length; M++) {
                var P = w.suggestionData[M],
                    u = w.B[M],
                    X = P.shortViewCount ? P.shortViewCount : P.author,
                    U = P.eA(),
                    f = w.api.N();
                if (g.K7(f) && !f.D("web_player_log_click_before_generating_ve_conversion_params")) {
                    var h = {};
                    g.Nl(w.api, "addEmbedsConversionTrackingParams", [h]);
                    U = g.p5(U, h)
                }
                u.element.style.display = "";
                h = u.RI("ytp-suggestion-title");
                g.h_.test(P.title) ? h.dir = "rtl" : g.Tdt.test(P.title) && (h.dir = "ltr");
                h = u.RI("ytp-suggestion-author");
                g.h_.test(X) ? h.dir = "rtl" : g.Tdt.test(X) && (h.dir = "ltr");
                u.update({
                    views_or_author: X,
                    duration: P.isLivePlayback ? "Live" : P.lengthSeconds ? g.N9(P.lengthSeconds) : "",
                    link: U,
                    hover_title: P.title,
                    title: P.title,
                    aria_label: P.ariaLabel || null,
                    is_live: P.isLivePlayback
                });
                X = P.Md();
                u.RI("ytp-suggestion-image").style.backgroundImage = X ? "url(" + X + ")" : "";
                f.D("web_player_log_click_before_generating_ve_conversion_params") && (w.api.createServerVe(u.element, u), (P = (P = P.sessionData) && P.itct) && w.api.setTrackingParams(u.element, P))
            }
            for (; M < w.B.length; M++) w.B[M].element.style.display = "none";
            H5h(w)
        },
        aO = function(w) {
            g.I5.call(this, w);
            var M = this;
            this.B = null;
            var P = w.N(),
                u = {
                    target: P.S
                },
                X = ["ytp-small-redirect"];
            if (P.C) X.push("no-link");
            else {
                var U = g.FD(P);
                u.href = U;
                u["aria-label"] = "Visit YouTube to search for more videos"
            }
            var f = new g.r({
                W: "a",
                d$: X,
                Z: u,
                J: [{
                    W: "svg",
                    Z: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    J: [{
                        W: "path",
                        Z: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        W: "path",
                        Z: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            f.XK(this.element);
            w.createClientVe(f.element, this, 178053);
            this.Y(f.element, "click", function(h) {
                FRj(M, h, f.element)
            });
            g.b(this, f);
            P.C || P.disableOrganicUi || (this.B = new Z5$(w), this.B.XK(this.element), g.b(this, this.B));
            this.Y(w, "videodatachange", function() {
                M.show()
            });
            this.resize(this.api.oI().getPlayerSize())
        },
        FRj = function(w, M, P) {
            M.preventDefault();
            w.api.logClick(P);
            M = P.getAttribute("href");
            P = {};
            g.Nl(w.api, "addEmbedsConversionTrackingParams", [P]);
            M = g.SF(P) ? M : g.p5(M, P);
            g.Fj(window, M)
        },
        EJA = function(w, M) {
            w.RI("ytp-error-content").style.paddingTop = "0px";
            var P = w.RI("ytp-error-content"),
                u = P.clientHeight;
            w.B && w.B.resize(M, M.height - u);
            P.style.paddingTop = (M.height - (w.B ? w.B.element.clientHeight : 0)) / 2 - u / 2 + "px"
        },
        mN3 = function(w, M) {
            var P = w.api.N(),
                u;
            M.reason && (NeV(M.reason) ? u = g.Wz(M.reason) : u = g.AI(g.ff(M.reason)), w.iB(u, "content"));
            var X;
            M.subreason && (NeV(M.subreason) ? X = g.Wz(M.subreason) : X = g.AI(g.ff(M.subreason)), w.iB(X, "subreason"));
            if (M.proceedButton && M.proceedButton.buttonRenderer) {
                u = w.RI("ytp-error-content-wrap-subreason");
                M = M.proceedButton.buttonRenderer;
                var U = g.HS("A");
                if (M.text && M.text.simpleText && (X = M.text.simpleText, U.textContent = X, !Vc4(u, X) && (!P.C || P.embedsErrorLinks))) {
                    var f;
                    P = (f = g.A(M == null ? void 0 : M.navigationEndpoint, g.lu)) == null ?
                        void 0 : f.url;
                    var h;
                    f = (h = g.A(M == null ? void 0 : M.navigationEndpoint, g.lu)) == null ? void 0 : h.target;
                    P && (U.setAttribute("href", P), w.api.createClientVe(U, w, 178424), w.Y(U, "click", function(c) {
                        FRj(w, c, U)
                    }));
                    f && U.setAttribute("target", f);
                    h = g.HS("DIV");
                    h.appendChild(U);
                    u.appendChild(h)
                }
            }
        },
        NeV = function(w) {
            if (w.runs)
                for (var M = 0; M < w.runs.length; M++)
                    if (w.runs[M].navigationEndpoint) return !0;
            return !1
        },
        Vc4 = function(w, M) {
            w = g.XU("A", w);
            for (var P = 0; P < w.length; P++)
                if (w[P].textContent === M) return !0;
            return !1
        },
        oJp = function(w, M) {
            g.r.call(this, {
                W: "a",
                d$: ["ytp-impression-link"],
                Z: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                J: [{
                    W: "div",
                    T: "ytp-impression-link-content",
                    Z: {
                        "aria-hidden": "true"
                    },
                    J: [{
                        W: "div",
                        T: "ytp-impression-link-text",
                        pu: "Watch on"
                    }, {
                        W: "div",
                        T: "ytp-impression-link-logo",
                        pu: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = w;
            this.B = M;
            this.updateValue("target", w.N().S);
            this.Y(w, "videodatachange", this.onVideoDataChange);
            this.Y(this.api, "presentingplayerstatechange", this.S1);
            this.Y(this.api, "videoplayerreset", this.K_);
            this.Y(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.K_()
        },
        G_3 = function(w) {
            var M = {};
            g.Nl(w.api, "addEmbedsConversionTrackingParams", [M]);
            w = w.api.getVideoUrl();
            return w = g.p5(w, M)
        },
        wP = function(w) {
            g.r.call(this, {
                W: "div",
                d$: ["ytp-mobile-a11y-hidden-seek-button"],
                J: [{
                    W: "button",
                    d$: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    Z: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    W: "button",
                    d$: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    Z: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = w;
            this.B = this.RI("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.RI("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.B, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.Y(this.api, "presentingplayerstatechange", this.S1);
            this.Y(this.B, "click", this.L);
            this.Y(this.forwardButton, "click", this.C);
            this.S1()
        },
        iI = function(w) {
            g.r.call(this, {
                W: "div",
                T: "ytp-muted-autoplay-endscreen-overlay",
                J: [{
                    W: "div",
                    T: "ytp-muted-autoplay-end-panel",
                    J: [{
                        W: "button",
                        d$: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        pu: "{{text}}"
                    }]
                }]
            });
            this.api = w;
            this.X = this.RI("ytp-muted-autoplay-end-panel");
            this.L = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.Y(this.api, "presentingplayerstatechange", this.C);
            this.Y(w, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        M7 = function(w) {
            var M = w.N();
            g.r.call(this, {
                W: "a",
                d$: ["ytp-watermark", "yt-uix-sessionlink"],
                Z: {
                    target: M.S,
                    href: "{{url}}",
                    "aria-label": g.iM("Watch on $WEBSITE", {
                        WEBSITE: g.P0(M)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                pu: "{{logoSvg}}"
            });
            this.api = w;
            this.B = null;
            this.L = !1;
            this.state = w.getPlayerStateObject();
            this.Y(w, "videodatachange", this.onVideoDataChange);
            this.Y(w, "presentingplayerstatechange", this.onStateChange);
            this.Y(w, "appresize", this.o9);
            this.onVideoDataChange();
            this.g7(this.state);
            this.o9(w.oI().getPlayerSize())
        },
        yat = function(w) {
            var M = w.api.getVideoData(),
                P = w.api.N();
            P = P.Ob && !g.C(w.state, 2) && !g.f$(w.api.getVideoData(1)) && !(P.D("embeds_enable_emc3ds_woyt_counterfactual") && w.api.getPlayerStateObject().isCued());
            M.mutedAutoplay || w.AD(P);
            w.api.logVisibility(w.element, P)
        },
        YQt = function(w) {
            g.r.call(this, {
                W: "div",
                T: "ytp-muted-autoplay-overlay",
                J: [{
                    W: "div",
                    T: "ytp-muted-autoplay-bottom-buttons",
                    J: [{
                        W: "button",
                        d$: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        Z: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        J: [{
                            W: "div",
                            d$: ["ytp-muted-autoplay-equalizer-icon"],
                            J: [{
                                W: "svg",
                                Z: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                J: [{
                                    W: "g",
                                    Z: {
                                        fill: "#fff"
                                    },
                                    J: [{
                                            W: "rect",
                                            T: "ytp-equalizer-bar-left",
                                            Z: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            W: "rect",
                                            T: "ytp-equalizer-bar-middle",
                                            Z: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            W: "rect",
                                            T: "ytp-equalizer-bar-right",
                                            Z: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var M = this;
            this.api = w;
            this.bottomButtons = this.RI("ytp-muted-autoplay-bottom-buttons");
            this.C = new g.gV(this.Sl, 4E3, this);
            this.L = !1;
            w.createClientVe(this.element, this, 39306);
            this.Y(w, "presentingplayerstatechange", this.Lw);
            this.Y(w, "onMutedAutoplayStarts", function() {
                DN4(M);
                M.Lw();
                qQt(M);
                M.L = !1
            });
            this.Y(w, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.Y(w, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            w.isMutedByEmbedsMutedAutoplay() && (DN4(this), this.Lw(), qQt(this));
            g.b(this, this.C)
        },
        qQt = function(w) {
            w.J9 && w.B && (w.B.show(), w.C.start())
        },
        DN4 = function(w) {
            w.watermark || (w.watermark = new M7(w.api), g.b(w, w.watermark), w.watermark.XK(w.bottomButtons, 0), g.X6(w.watermark.element, "ytp-muted-autoplay-watermark", !0), w.B = new g.Cf(w.watermark, 0, !0, 100), g.b(w,
                w.B))
        },
        Pq = function(w) {
            g.r.call(this, {
                W: "div",
                T: "ytp-pause-overlay",
                Z: {
                    tabIndex: "-1"
                }
            });
            var M = this;
            this.api = w;
            this.C = new g.V2(this);
            this.fade = new g.Cf(this, 1E3, !1, 100, function() {
                M.B.L = !1
            }, function() {
                M.B.L = !0
            });
            this.L = !1;
            this.expandButton = new g.r({
                W: "button",
                d$: ["ytp-button", "ytp-expand"],
                pu: this.api.isEmbedsShortsMode() ? "More shorts" : "More videos"
            });
            w.N().controlsType === "0" && g.io(w.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.api.D("embeds_web_enable_pause_overlay_rounding") && g.io(this.element, "ytp-pause-overlay-round-corners");
            g.b(this, this.C);
            g.b(this, this.fade);
            var P = new g.r({
                W: "button",
                d$: ["ytp-button", "ytp-collapse"],
                Z: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more shorts" : "Hide more videos"
                },
                J: [{
                    W: "div",
                    T: "ytp-collapse-icon",
                    J: [g.yA()]
                }]
            });
            g.b(this, P);
            P.XK(this.element);
            P.listen("click", this.X, this);
            g.b(this, this.expandButton);
            this.expandButton.XK(this.element);
            this.expandButton.listen("click", this.K, this);
            this.B = new g.Pw(w);
            g.b(this, this.B);
            this.B.L = !1;
            this.B.XK(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.C.Y(this.api, "presentingplayerstatechange", this.g$);
            this.C.Y(this.api, "videodatachange",
                this.g$);
            this.hide()
        },
        uI = function(w) {
            g.r.call(this, {
                W: "div",
                d$: ["ytp-player-content", "ytp-iv-player-content"],
                J: [{
                    W: "div",
                    T: "ytp-countdown-timer",
                    J: [{
                        W: "svg",
                        Z: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        J: [{
                            W: "circle",
                            T: "ytp-svg-countdown-timer-ring",
                            Z: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            W: "circle",
                            T: "ytp-svg-countdown-timer-background",
                            Z: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        W: "span",
                        T: "ytp-countdown-timer-time",
                        pu: "{{duration}}"
                    }]
                }]
            });
            this.api = w;
            this.j = this.RI("ytp-svg-countdown-timer-ring");
            this.B = null;
            this.X = this.C = 0;
            this.L = !1;
            this.K = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        Tec = function(w) {
            w.B || (w.C = 5E3, w.X = (0, g.G$)(), w.B = new g.AK(function() {
                zZt(w)
            }, null), zZt(w))
        },
        zZt = function(w) {
            if (!w.L) {
                var M = Math.min((0, g.G$)() - w.X, w.C);
                var P = w.C - M;
                M = w.C === 0 ? 0 : Math.max(P / w.C, 0);
                P = Math.round(P / 1E3);
                w.j.setAttribute("stroke-dashoffset", "" + -211 * (M + 1));
                w.updateValue("duration", P);
                M <= 0 && w.B ? w.stopTimer() : w.B && w.B.start()
            }
        },
        ltc = function(w) {
            g.D0.call(this, w);
            this.U = w;
            this.B = new g.V2(this);
            this.L = null;
            this.j = !1;
            this.countdownTimer = null;
            this.S = !1;
            dNE(this);
            g.b(this, this.B);
            this.load()
        },
        eZC = function(w) {
            var M = g.kpj(w.U);
            M !== w.S && (w.S = M, w.G && (w.G.dispose(), w.G = null), w.C && (w.C.dispose(), w.C = null), w.X && (w.X.dispose(), w.X = null), w.L && (w.L.stop(), w.L.dispose(), w.L = null), M && (M = g.y1(w.U), w.U.isEmbedsShortsMode() && (w.X = new g.r({
                W: "div",
                T: "ytp-pause-overlay-backdrop",
                Z: {
                    tabIndex: "-1"
                }
            }), g.b(w, w.X), g.bD(w.U, w.X.element, 4), w.L = new g.Cf(w.X, 1E3, !1, 100), g.b(w, w.L), w.X.hide()), w.G = new g.r({
                W: "div",
                T: "ytp-pause-overlay-container",
                Z: {
                    tabIndex: "-1"
                }
            }), g.b(w, w.G), w.C = new Pq(w.U, M), g.b(w, w.C), w.C.XK(w.G.element), g.bD(w.U, w.G.element,
                4), LRV(w, w.U.getPlayerStateObject())))
        },
        LRV = function(w, M) {
            w.L && (!g.C(M, 4) && !g.C(M, 2) || g.C(M, 1024) ? w.L.hide() : w.L.show())
        },
        dNE = function(w) {
            var M = w.U;
            w = !!M.isEmbedsShortsMode();
            g.X6(M.getRootNode(), "ytp-shorts-mode", w);
            if (M = M.getVideoData()) M.Bu = w
        },
        $U = function(w, M) {
            var P = w.U.N();
            w = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: w.U.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : w.U.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.bj4(w.U.N().loaderUrl),
                eventType: M,
                youtubeHost: g.f5(w.U.N().GJ) || ""
            };
            w.embeddedPlayerMode = P.ys;
            g.ub("embedsAdEvent", w)
        };
    g.V(Z5$, g.r);
    g.N = Z5$.prototype;
    g.N.hide = function() {
        this.j = !0;
        g.r.prototype.hide.call(this);
        SQA(this, !1)
    };
    g.N.show = function() {
        this.j = !1;
        g.r.prototype.show.call(this);
        SQA(this, !0)
    };
    g.N.isHidden = function() {
        return this.j
    };
    g.N.Tu = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.N.u2 = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.N.resize = function(w, M) {
        var P = this.api.N(),
            u = 16 / 9,
            X = w.width >= 650,
            U = w.width < 480 || w.height < 290,
            f = Math.min(this.suggestionData.length, this.B.length);
        if (Math.min(w.width, w.height) <= 150 || f === 0 || !P.DX) this.hide();
        else {
            var h;
            if (X) {
                var c = h = 28;
                this.L = 16
            } else this.L = c = h = 8;
            if (U) {
                var Z = 6;
                X = 14;
                var S = 12;
                U = 24;
                P = 12
            } else Z = 8, X = 18, S = 16, U = 36, P = 16;
            w = w.width - (48 + h + c);
            h = Math.ceil(w / 150);
            h = Math.min(3, h);
            c = w / h - this.L;
            var H = Math.floor(c / u);
            M && H + 100 > M && c > 50 && (H = Math.max(M, 50 / u), h = Math.ceil(w / (u * (H - 100) + this.L)), c = w / h - this.L,
                H = Math.floor(c / u));
            c < 50 || g.n$(this.api) ? this.hide() : this.show();
            for (M = 0; M < f; M++) {
                u = this.B[M];
                var p = u.RI("ytp-suggestion-image");
                p.style.width = c + "px";
                p.style.height = H + "px";
                u.RI("ytp-suggestion-title").style.width = c + "px";
                u.RI("ytp-suggestion-author").style.width = c + "px";
                u = u.RI("ytp-suggestion-duration");
                u.style.display = u && c < 100 ? "none" : ""
            }
            f = X + Z + S + 4;
            this.K = f + P + (H - U) / 2;
            this.suggestions.element.style.height = H + f + "px";
            this.C = c;
            this.containerWidth = w;
            this.columns = h;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            H5h(this)
        }
    };
    g.N.onVideoDataChange = function() {
        var w = this.api.getVideoData(),
            M = this.api.N();
        this.V = w.Ym ? !1 : M.X;
        w.suggestions ? this.suggestionData = g.DP(w.suggestions, function(P) {
            return P && !P.playlistId
        }) : this.suggestionData.length = 0;
        pYa(this);
        w.Ym ? this.title.update({
            title: g.iM("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: w.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.N.scrollTo = function(w) {
        w = g.bi(w, this.containerWidth - this.suggestionData.length * (this.C + this.L), 0);
        this.S.start(this.scrollPosition, w, 1E3);
        this.scrollPosition = w;
        H5h(this);
        SQA(this, !0)
    };
    g.V(aO, g.I5);
    aO.prototype.show = function() {
        g.I5.prototype.show.call(this);
        EJA(this, this.api.oI().getPlayerSize())
    };
    aO.prototype.resize = function(w) {
        g.I5.prototype.resize.call(this, w);
        this.B && (EJA(this, w), g.X6(this.element, "related-on-error-overlay-visible", !this.B.isHidden()))
    };
    aO.prototype.L = function(w) {
        g.I5.prototype.L.call(this, w);
        var M = this.api.getVideoData();
        if (M.Bg || M.playerErrorMessageRenderer)(w = M.Bg) ? mN3(this, w) : M.playerErrorMessageRenderer && mN3(this, M.playerErrorMessageRenderer);
        else {
            var P;
            w.GL && (M.eY ? NeV(M.eY) ? P = g.Wz(M.eY) : P = g.AI(g.ff(M.eY)) : P = g.AI(w.GL), this.iB(P, "subreason"))
        }
    };
    g.V(oJp, g.r);
    g.N = oJp.prototype;
    g.N.onVideoDataChange = function() {
        var w = this.api.getVideoData(),
            M = hZ3(),
            P = 96714;
        g.h$(w) ? (M = caC(), P = 216165, g.io(this.element, "ytp-music-impression-link")) : g.PI(this.element, "ytp-music-impression-link");
        this.api.N().D("embeds_enable_emc3ds_woyt_counterfactual") && g.io(this.element, "ytp-woyt-emc3ds-cf");
        this.updateValue("logoSvg", M);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, P)
    };
    g.N.S1 = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.N.K_ = function() {
        var w = this.api.getVideoData(),
            M = this.api.N(),
            P = this.api.getVideoData().Ym,
            u = M.Ob && !M.D("embeds_enable_emc3ds_woyt_counterfactual"),
            X = !M.DX,
            U = this.B.Jx() && !M.D("embeds_enable_emc3ds_woyt_counterfactual");
        M = M.C;
        u || U || P || X || M || this.api.isEmbedsShortsMode() || !w.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (w = G_3(this), this.updateValue("url", w), this.show())
    };
    g.N.onClick = function(w) {
        this.api.D("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var M = G_3(this);
        g.HH(M, this.api, w);
        this.api.D("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.N.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.r.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.V(wP, g.r);
    wP.prototype.S1 = function() {
        var w = this.api.getPlayerStateObject();
        !this.api.q8() || g.C(w, 2) && g.Q1(this.api) || g.C(w, 64) ? (this.api.logVisibility(this.B, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.B, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    wP.prototype.L = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.B)
    };
    wP.prototype.C = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.V(iI, g.r);
    iI.prototype.C = function() {
        var w = this.api.getPlayerStateObject(),
            M = this.api.getVideoData();
        g.X6(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !M.mutedAutoplay || M.limitedPlaybackDurationInSeconds === 0 && M.endSeconds === 0 && M.mutedAutoplayDurationMode === 2 || (g.C(w, 2) && !this.J9 ? (this.show(), this.B || (this.B = new g.Ko(this.api), g.b(this, this.B), this.B.XK(this.X, 0), this.B.show()), w = this.api.getVideoData(), this.updateValue("text", w.bY), g.X6(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element,
            this.J9), this.api.z5("onMutedAutoplayEnds")) : this.hide())
    };
    iI.prototype.onClick = function() {
        if (!this.L) {
            this.B && (this.B.v3(), this.B = null);
            g.X6(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var w = this.api.getVideoData(),
                M = this.api.getCurrentTime();
            WRh(w);
            this.api.loadVideoById(w.videoId, M);
            this.api.aF();
            this.api.logClick(this.element);
            this.hide();
            this.L = !0
        }
    };
    iI.prototype.onMutedAutoplayStarts = function() {
        this.L = !1;
        this.B && (this.B.v3(), this.B = null)
    };
    g.V(M7, g.r);
    g.N = M7.prototype;
    g.N.onStateChange = function(w) {
        this.g7(w.state)
    };
    g.N.g7 = function(w) {
        this.state !== w && (this.state = w);
        yat(this)
    };
    g.N.onVideoDataChange = function() {
        var w = this.api.N();
        w.C && g.io(this.element, "ytp-no-hover");
        var M = this.api.getVideoData();
        M.videoId && !w.C ? (w = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", w), this.B || (this.B = this.listen("click", this.onClick))) : this.B && (this.updateValue("url", null), this.Mt(this.B), this.B = null);
        w = hZ3();
        var P = 76758;
        g.h$(M) && (w = caC(), P = 216164);
        this.updateValue("logoSvg", w);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            P);
        yat(this)
    };
    g.N.onClick = function(w) {
        this.api.D("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var M = this.api.getVideoUrl(!g.VP(w), !1, !0, !0);
        if (this.api.D("web_player_log_click_before_generating_ve_conversion_params")) {
            var P = {};
            g.Nl(this.api, "addEmbedsConversionTrackingParams", [P]);
            M = g.p5(M, P)
        }
        g.HH(M, this.api, w);
        this.api.D("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.N.o9 = function(w) {
        if ((w = w.width < 480) && !this.L || !w && this.L) {
            var M = new g.r(hZ3()),
                P = this.RI("ytp-watermark");
            g.X6(P, "ytp-watermark-small", w);
            g.ES(P);
            M.XK(P);
            this.L = w
        }
    };
    g.V(YQt, g.r);
    g.N = YQt.prototype;
    g.N.Lw = function() {
        var w = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.C(w, 2) ? this.hide() : this.J9 || (g.r.prototype.show.call(this), this.api.logVisibility(this.element, this.J9))
    };
    g.N.Sl = function() {
        this.B && this.B.hide()
    };
    g.N.onAutoplayBlocked = function() {
        this.hide();
        WRh(this.api.getVideoData())
    };
    g.N.onClick = function() {
        if (!this.L) {
            g.X6(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var w = this.api.getVideoData(),
                M = this.api.getCurrentTime();
            WRh(w);
            this.api.loadVideoById(w.videoId, M);
            this.api.aF();
            this.api.logClick(this.element);
            this.api.z5("onMutedAutoplayEnds");
            this.L = !0
        }
    };
    g.N.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.v3(), this.watermark = null)
    };
    g.V(Pq, g.r);
    Pq.prototype.hide = function() {
        g.PI(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.r.prototype.hide.call(this)
    };
    Pq.prototype.X = function() {
        this.L = !0;
        g.PI(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    Pq.prototype.K = function() {
        this.L = !1;
        g.io(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    Pq.prototype.g$ = function() {
        var w = this.api.getPlayerStateObject();
        g.C(w, 1) || g.C(w, 16) || g.C(w, 32) || (!g.C(w, 4) || g.C(w, 2) || g.C(w, 1024) ? (this.L || this.api.logVisibility(this.element, !1), this.fade.hide()) : this.B.hasSuggestions() && (this.L || (g.io(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.u9(this.B), this.B.show(), this.api.logVisibility(this.element, !0)), this.fade.show()))
    };
    g.V(uI, g.r);
    uI.prototype.show = function() {
        g.r.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    uI.prototype.stopTimer = function() {
        this.B && (this.B.dispose(), this.B = null, this.L = !1)
    };
    uI.prototype.v3 = function() {
        this.stopTimer();
        g.r.prototype.v3.call(this)
    };
    g.V(ltc, g.D0);
    g.N = ltc.prototype;
    g.N.Yo = function() {
        return !1
    };
    g.N.create = function() {
        var w = this.U.N(),
            M = g.y1(this.U),
            P, u = (P = this.U.getVideoData()) == null ? void 0 : P.clientPlaybackNonce;
        u && g.Db({
            clientPlaybackNonce: u
        });
        w.jL && !w.disableOrganicUi && eZC(this);
        var X;
        (X = w.getWebPlayerContextConfig()) != null && X.embedsEnableEmc3ds || (this.V = new YQt(this.U), g.b(this, this.V), g.bD(this.U, this.V.element, 4), this.Lu = new iI(this.U), g.b(this, this.Lu), g.bD(this.U, this.Lu.element, 4));
        w.Ob && (this.watermark = new M7(this.U), g.b(this, this.watermark), g.bD(this.U, this.watermark.element, 8));
        M && !w.disableOrganicUi && (this.K = new oJp(this.U, M), g.b(this, this.K), g.bD(this.U, this.K.element, 8), this.U.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.K.hide()));
        w.L && !w.disableOrganicUi && (this.B3 = new wP(this.U), g.b(this, this.B3), g.bD(this.U, this.B3.element, 4));
        this.B.Y(this.U, "appresize", this.o9);
        this.B.Y(this.U, "presentingplayerstatechange", this.S1);
        this.B.Y(this.U, "videodatachange", this.onVideoDataChange);
        this.B.Y(this.U, "videoplayerreset", this.onReset);
        this.B.Y(this.U, "onMutedAutoplayStarts",
            this.onMutedAutoplayStarts);
        this.B.Y(this.U, "onAdStart", this.onAdStart);
        this.B.Y(this.U, "onAdComplete", this.onAdComplete);
        this.B.Y(this.U, "onAdSkip", this.onAdSkip);
        this.B.Y(this.U, "onAdStateChange", this.onAdStateChange);
        if (this.j = g.$F(g.tu(w))) this.countdownTimer = new uI(this.U), g.b(this, this.countdownTimer), g.bD(this.U, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.B.Y(this.U, g.AP("embeds"), this.onCueRangeEnter), this.B.Y(this.U, g.gL("embeds"), this.onCueRangeExit);
        this.Pk(this.U.getPlayerStateObject());
        this.player.LV("embed");
        var U, f;
        ((U = this.U.N().getWebPlayerContextConfig()) == null ? 0 : (f = U.embedsHostFlags) == null ? 0 : f.allowOverridingVisitorDataPlayerVars) && (w = g.AR("IDENTITY_MEMENTO")) && this.U.OE("onMementoChange", w)
    };
    g.N.onCueRangeEnter = function(w) {
        w.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), Tec(this.countdownTimer))
    };
    g.N.onCueRangeExit = function(w) {
        w.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.stopTimer(), this.countdownTimer.hide())
    };
    g.N.o9 = function() {
        var w = this.U.oI().getPlayerSize();
        this.G0 && this.G0.resize(w)
    };
    g.N.onReset = function() {
        dNE(this)
    };
    g.N.S1 = function(w) {
        this.Pk(w.state)
    };
    g.N.Pk = function(w) {
        g.C(w, 128) ? (this.G0 || (this.G0 = new aO(this.U), g.b(this, this.G0), g.bD(this.U, this.G0.element, 4)), this.G0.L(w.tV), this.G0.show(), g.io(this.U.getRootNode(), "ytp-embed-error")) : this.G0 && (this.G0.dispose(), this.G0 = null, g.PI(this.U.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.B)
            if (g.C(w, 64)) this.countdownTimer.hide(), this.countdownTimer.stopTimer();
            else if (w.isPaused()) {
            var M = this.countdownTimer;
            M.L || (M.L = !0, M.K = (0, g.G$)())
        } else w.isPlaying() && this.countdownTimer.L &&
            (M = this.countdownTimer, M.L && (M.X += (0, g.G$)() - M.K, M.L = !1, zZt(M)));
        LRV(this, w)
    };
    g.N.onMutedAutoplayStarts = function() {
        this.U.getVideoData().mutedAutoplay && this.V && g.X6(this.U.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.N.onVideoDataChange = function(w, M) {
        var P = this.dM !== M.videoId;
        w = !P && w === "dataloaded";
        var u = {
            isShortsModeEnabled: !!this.U.isEmbedsShortsMode()
        };
        g.ub("embedsVideoDataDidChange", {
            clientPlaybackNonce: M.clientPlaybackNonce,
            isReload: w,
            runtimeEnabledFeatures: u
        });
        P && (this.dM = M.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.j && (this.U.dB("embeds"), M.isAd() || M.limitedPlaybackDurationInSeconds < 5 || g.n$(this.U) || (M = Math.max((M.startSeconds + M.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), M = new g.bg(M, M + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.U.qf([M]))), this.U.N().jL && !this.U.N().disableOrganicUi && (dNE(this), eZC(this)));
        this.U.N().C && this.C && this.C.detach()
    };
    g.N.onAdStart = function() {
        $U(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.N.onAdComplete = function() {
        $U(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.N.onAdSkip = function() {
        $U(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.N.onAdStateChange = function(w) {
        w === 2 && $U(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.yT("embed", ltc);
})(_yt_player);